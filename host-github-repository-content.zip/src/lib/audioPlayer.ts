/**
 * Streams raw 16-bit little-endian PCM chunks (as returned by the Gemini Live API,
 * 24kHz) through the Web Audio API with gapless, sequential scheduling.
 */
export class PcmStreamPlayer {
  private ctx: AudioContext | null = null;
  private nextStartTime = 0;
  private sources = new Set<AudioBufferSourceNode>();
  private analyser: AnalyserNode | null = null;
  private onStateChange?: (playing: boolean) => void;
  private playing = false;
  private checkTimer: number | null = null;
  /** True when audio chunks are being actively streamed from the server turn. */
  private receivingStream = false;
  /** Decoding/scheduling work started before a server turn completed. */
  private pendingEnqueues = 0;

  constructor(private sampleRate = 24000) {}

  setReceivingStream(active: boolean) {
    this.receivingStream = active;
    if (active) {
      this.setPlaying(true);
    } else {
      this.updatePlaying();
    }
  }

  setStateListener(cb: (playing: boolean) => void) {
    this.onStateChange = cb;
  }

  /** Must be called from a user gesture at least once so the AudioContext can start. */
  async ensureContext(): Promise<AudioContext> {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)({
        sampleRate: this.sampleRate,
      });
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 256;
      this.analyser.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      await this.ctx.resume();
    }
    return this.ctx;
  }

  getAnalyser() {
    return this.analyser;
  }

  isPlaying() {
    return this.playing;
  }

  /** Enqueue a base64-encoded PCM16 chunk. */
  async enqueueBase64(b64: string, mimeType?: string) {
    // Increment before the first await. The server can send turnComplete while
    // an async AudioContext resume/decode is still in progress.
    this.pendingEnqueues++;
    this.setPlaying(true);
    try {
      const ctx = await this.ensureContext();
      const rate = parseRate(mimeType) ?? this.sampleRate;

      const bytes = base64ToBytes(b64);
      const sampleCount = Math.floor(bytes.byteLength / 2);
      if (sampleCount === 0) return;

      const view = new DataView(bytes.buffer, bytes.byteOffset, sampleCount * 2);
      const float = new Float32Array(sampleCount);
      for (let i = 0; i < sampleCount; i++) {
        float[i] = view.getInt16(i * 2, true) / 32768;
      }

      const buffer = ctx.createBuffer(1, sampleCount, rate);
      buffer.copyToChannel(float, 0);

      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.connect(this.analyser ?? ctx.destination);

      const now = ctx.currentTime;
      // small lead-in so the first chunk doesn't start in the past
      const startAt = Math.max(now + 0.02, this.nextStartTime);
      source.start(startAt);
      this.nextStartTime = startAt + buffer.duration;

      this.sources.add(source);
      source.onended = () => {
        this.sources.delete(source);
        this.updatePlaying();
      };
    } finally {
      this.pendingEnqueues = Math.max(0, this.pendingEnqueues - 1);
      this.updatePlaying();
    }
  }

  /** Stop playback immediately and clear the queue (e.g. on interruption). */
  stop() {
    this.receivingStream = false;
    this.pendingEnqueues = 0;
    for (const s of this.sources) {
      try {
        s.onended = null;
        s.stop();
      } catch {
        /* already stopped */
      }
    }
    this.sources.clear();
    this.nextStartTime = 0;
    this.setPlaying(false);
  }

  private updatePlaying() {
    // If we're still actively receiving audio chunks from the server, we are not done yet!
    if (this.sources.size === 0 && this.pendingEnqueues === 0 && !this.receivingStream) {
      // Add a tiny buffer (80ms) to prevent micro-flicker between scheduled chunks
      if (this.checkTimer) window.clearTimeout(this.checkTimer);
      this.checkTimer = window.setTimeout(() => {
        if (this.sources.size === 0 && this.pendingEnqueues === 0 && !this.receivingStream) {
          this.setPlaying(false);
        }
        this.checkTimer = null;
      }, 100);
    }
  }

  private setPlaying(v: boolean) {
    if (this.playing !== v) {
      this.playing = v;
      this.onStateChange?.(v);
    }
    if (this.checkTimer) {
      window.clearTimeout(this.checkTimer);
      this.checkTimer = null;
    }
  }

  async close() {
    this.stop();
    if (this.ctx) {
      await this.ctx.close();
      this.ctx = null;
      this.analyser = null;
    }
  }
}

function parseRate(mimeType?: string): number | undefined {
  if (!mimeType) return undefined;
  const m = /rate=(\d+)/.exec(mimeType);
  return m ? Number(m[1]) : undefined;
}

function base64ToBytes(b64: string): Uint8Array {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

/**
 * Captures microphone audio, downsamples/converts to 16-bit PCM little-endian at 16kHz,
 * and emits base64 chunks for the Gemini Live WebSocket.
 */
export class PcmRecorder {
  private mediaStream: MediaStream | null = null;
  private audioCtx: AudioContext | null = null;
  private processor: ScriptProcessorNode | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  private recording = false;

  constructor(private onChunk: (b64: string) => void) {}

  async start(): Promise<void> {
    if (this.recording) return;
    this.mediaStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        channelCount: 1,
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      },
    });

    this.audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({
      sampleRate: 16000,
    });
    if (this.audioCtx.state === 'suspended') {
      await this.audioCtx.resume();
    }

    this.source = this.audioCtx.createMediaStreamSource(this.mediaStream);
    // Buffer size 2048 gives ~128ms chunks at 16kHz
    this.processor = this.audioCtx.createScriptProcessor(2048, 1, 1);

    this.processor.onaudioprocess = (e) => {
      if (!this.recording) return;
      const input = e.inputBuffer.getChannelData(0);
      const pcm16 = new Int16Array(input.length);
      for (let i = 0; i < input.length; i++) {
        const s = Math.max(-1, Math.min(1, input[i]));
        pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
      }
      const bytes = new Uint8Array(pcm16.buffer, pcm16.byteOffset, pcm16.byteLength);
      const b64 = bytesToBase64(bytes);
      this.onChunk(b64);
    };

    this.source.connect(this.processor);
    this.processor.connect(this.audioCtx.destination);
    this.recording = true;
  }

  stop() {
    this.recording = false;
    if (this.processor) {
      this.processor.disconnect();
      this.processor.onaudioprocess = null;
      this.processor = null;
    }
    if (this.source) {
      this.source.disconnect();
      this.source = null;
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((t) => t.stop());
      this.mediaStream = null;
    }
    if (this.audioCtx) {
      void this.audioCtx.close();
      this.audioCtx = null;
    }
  }

  isRecording() {
    return this.recording;
  }
}
