/**
 * Minimal raw-WebSocket client for the Gemini Live API.
 * Protocol reference: https://ai.google.dev/gemini-api/docs/live-api/get-started-websocket
 */

import { buildSystemInstruction } from './prompts';
import { SUBJECT_PROFILES, type SubjectId } from './dataset';
import type { LiveFunctionCall, LiveFunctionResponse } from './liveTools';

export const LIVE_MODEL = 'gemini-3.8-live';

export const AVAILABLE_LIVE_MODELS: ReadonlyArray<{ id: string; label: string }> = [
  { id: 'gemini-3.8-live', label: 'gemini-3.8-live (par défaut)' },
  { id: 'gemini-2.5-flash-native-audio-preview-09-2025', label: 'gemini-2.5-flash-native-audio (preview)' },
  { id: 'gemini-live-2.5-flash-preview', label: 'gemini-live-2.5-flash (preview)' },
  { id: 'gemini-2.0-flash-live-001', label: 'gemini-2.0-flash-live-001' },
];

const WS_BASE =
  'wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent';

export type InteractionStatus = 'IDLE' | 'IN_PROGRESS';

export const VOICES = ['Puck', 'Charon', 'Kore', 'Fenrir', 'Aoede', 'Leda', 'Orus', 'Zephyr'] as const;
export type VoiceName = (typeof VOICES)[number];

export interface LiveClientOptions {
  apiKey: string;
  model?: string;
  subject?: SubjectId;
  voice?: VoiceName;
  systemInstruction?: string;
  /** Live API `tools` array (function declarations). */
  tools?: unknown[];
}

/**
 * The exact setup envelope sent as the first WebSocket message.
 * Native audio Live models expose their text as outputAudioTranscription;
 * written content (board, QCM) arrives through function calls.
 */
export function buildLiveSetupPayload(options: LiveClientOptions) {
  const subject = options.subject ?? 'mathematiques';
  const profile = SUBJECT_PROFILES[subject];

  return {
    setup: {
      model: `models/${options.model ?? LIVE_MODEL}`,
      generationConfig: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {
              voiceName: options.voice ?? profile.voiceName,
            },
          },
        },
      },
      systemInstruction: {
        parts: [{ text: options.systemInstruction ?? buildSystemInstruction(subject) }],
      },
      ...(options.tools && options.tools.length ? { tools: options.tools } : {}),
      // Captions of the Darija audio (teacher) and of the student's microphone.
      outputAudioTranscription: {},
      inputAudioTranscription: {},
    },
  };
}

export interface LiveClientEvents {
  onOpen?: () => void;
  onSetupComplete?: () => void;
  onAudioChunk?: (base64: string, mimeType: string) => void;
  onOutputTranscription?: (text: string) => void;
  onInputTranscription?: (text: string) => void;
  onModelText?: (text: string) => void;
  onThought?: (text: string) => void;
  onTurnComplete?: () => void;
  onInterrupted?: () => void;
  onInteractionStatus?: (status: InteractionStatus) => void;
  onToolCall?: (calls: LiveFunctionCall[]) => void;
  onToolCallCancellation?: (ids: string[]) => void;
  onGoAway?: (timeLeft?: string) => void;
  onError?: (message: string) => void;
  onClose?: (code: number, reason: string) => void;
  onRaw?: (msg: unknown) => void;
}

export class GeminiLiveClient {
  private ws: WebSocket | null = null;
  private ready = false;

  constructor(
    private options: LiveClientOptions,
    private events: LiveClientEvents,
  ) {}

  get isReady() {
    return this.ready && this.ws?.readyState === WebSocket.OPEN;
  }

  get isConnected() {
    return this.ws?.readyState === WebSocket.OPEN;
  }

  connect() {
    if (this.ws) this.disconnect();

    const url = `${WS_BASE}?key=${encodeURIComponent(this.options.apiKey)}`;
    const ws = new WebSocket(url);
    this.ws = ws;

    ws.onopen = () => {
      this.events.onOpen?.();
      ws.send(JSON.stringify(buildLiveSetupPayload(this.options)));
    };

    ws.onmessage = async (event: MessageEvent) => {
      let raw: string;
      if (typeof event.data === 'string') {
        raw = event.data;
      } else if (event.data instanceof Blob) {
        raw = await event.data.text();
      } else {
        raw = new TextDecoder().decode(event.data as ArrayBuffer);
      }

      let msg: any;
      try {
        msg = JSON.parse(raw);
      } catch {
        return;
      }
      this.handleMessage(msg);
    };

    ws.onerror = () => {
      this.events.onError?.('WebSocket error — check your API key and network connection.');
    };

    ws.onclose = (ev: CloseEvent) => {
      this.ready = false;
      this.events.onClose?.(ev.code, ev.reason);
      if (this.ws === ws) this.ws = null;
    };
  }

  private handleMessage(msg: any) {
    this.events.onRaw?.(msg);

    if (msg.setupComplete !== undefined) {
      this.ready = true;
      this.events.onSetupComplete?.();
    }

    if (msg.error) {
      this.events.onError?.(msg.error.message ?? JSON.stringify(msg.error));
    }

    // interactionStatus may be top-level or nested in serverContent (thinking model).
    const status: InteractionStatus | undefined = msg.interactionStatus ?? msg.serverContent?.interactionStatus;
    if (status) this.events.onInteractionStatus?.(status);

    const sc = msg.serverContent;
    if (sc) {
      if (sc.interrupted) this.events.onInterrupted?.();

      if (sc.modelTurn?.parts) {
        for (const part of sc.modelTurn.parts) {
          if (part.inlineData?.data) {
            this.events.onAudioChunk?.(part.inlineData.data, part.inlineData.mimeType ?? 'audio/pcm;rate=24000');
          }
          if (typeof part.text === 'string' && part.text.length > 0) {
            if (part.thought) this.events.onThought?.(part.text);
            else this.events.onModelText?.(part.text);
          }
        }
      }

      if (sc.outputTranscription?.text) this.events.onOutputTranscription?.(sc.outputTranscription.text);
      if (sc.inputTranscription?.text) this.events.onInputTranscription?.(sc.inputTranscription.text);
      if (sc.turnComplete) this.events.onTurnComplete?.();
    }

    if (msg.goAway) this.events.onGoAway?.(msg.goAway.timeLeft);

    if (msg.toolCall) {
      const calls = (msg.toolCall.functionCalls ?? []) as LiveFunctionCall[];
      if (calls.length) {
        if (this.events.onToolCall) {
          this.events.onToolCall(calls);
        } else {
          // No handler: answer gracefully so the session doesn't stall.
          this.sendToolResponse(
            calls.map((fc) => ({ id: fc.id, name: fc.name, response: { error: 'No tools are available in this client.' } })),
          );
        }
      }
    }

    if (msg.toolCallCancellation) {
      this.events.onToolCallCancellation?.(msg.toolCallCancellation.ids ?? []);
    }
  }

  /** Send a text message as realtime input (per the WebSocket getting-started guide). */
  sendText(text: string) {
    if (!this.isReady) {
      this.events.onError?.('Session is not ready yet.');
      return false;
    }
    this.send({ realtimeInput: { text } });
    return true;
  }

  /** Send a 16 kHz PCM16 microphone chunk as realtime input. */
  sendAudioChunk(base64: string, mimeType = 'audio/pcm;rate=16000') {
    if (!this.isReady) return false;
    this.send({ realtimeInput: { audio: { data: base64, mimeType } } });
    return true;
  }

  /** Tell the server the microphone stream paused (flushes the last utterance). */
  sendAudioStreamEnd() {
    if (this.isReady) this.send({ realtimeInput: { audioStreamEnd: true } });
  }

  /** Answer one or more function calls. */
  sendToolResponse(functionResponses: LiveFunctionResponse[]) {
    if (!functionResponses.length) return;
    this.send({ toolResponse: { functionResponses } });
  }

  private send(payload: unknown) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(payload));
    }
  }

  disconnect() {
    this.ready = false;
    if (this.ws) {
      const ws = this.ws;
      this.ws = null;
      ws.onopen = null;
      ws.onmessage = null;
      ws.onerror = null;
      ws.onclose = null;
      try {
        ws.close(1000, 'client closed');
      } catch {
        /* noop */
      }
    }
  }
}
