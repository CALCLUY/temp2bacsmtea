import { useCallback, useEffect, useRef, useState } from 'react';
import type { BoardLine, BoardMark } from '../components/Blackboard';
import { containsArabic, QCM_LETTERS, stripOptionPrefix, type BoardAnnotation, type BoardDrawingItem, type BoardDrawElement, type ParsedBoardAction, type ParsedQcm } from './interaction';
import { chalkWritingMs } from './chalkTiming';

let idSequence = 0;

interface QueuedLine {
  text?: string;
  kind?: BoardLine['kind'];
  qcmId?: string;
  optionIndex?: number;
  annotation?: BoardAnnotation;
  drawing?: BoardDrawElement;
  clear: boolean;
  done?: () => void;
}

function animationMs(text: string, kind: BoardLine['kind'] = 'text'): number {
  return chalkWritingMs(text) + (kind === 'title' ? 160 : 100);
}

function drawingMs(element: BoardDrawElement): number {
  const points = element.type === 'line'
    ? [[element.x1, element.y1], [element.x2, element.y2]] as const
    : element.type === 'circle'
      ? [[element.cx, element.cy], [element.cx + element.r, element.cy]] as const
      : element.type === 'curve'
        ? element.points
        : element.type === 'arrow'
          ? [element.from, element.to]
          : [[0, 0], [18, 0]] as const;
  const distance = points.slice(1).reduce((sum, point, index) => {
    const prev = points[index];
    return sum + Math.hypot(point[0] - prev[0], point[1] - prev[1]);
  }, 0);
  return Math.max(420, Math.min(1800, 360 + distance * 10));
}

/** Legacy blocks are decomposed into the exact same one-line work queue. */
function expand(action: ParsedBoardAction): Array<Omit<QueuedLine, 'done'>> {
  if (action.action === 'blackboard_annotate') {
    return action.annotation ? [{ clear: false, annotation: action.annotation }] : [];
  }
  if (action.action === 'blackboard_draw') {
    return (action.drawings ?? []).map((drawing) => ({ clear: false, drawing }));
  }
  if (action.action === 'blackboard_clear') return [{ clear: true }];
  if (action.action === 'blackboard_write_line') {
    return action.line?.trim() && !containsArabic(action.line) ? [{ clear: !!action.clear, text: action.line.trim(), kind: 'text' }] : [];
  }

  const rows: Array<{ text: string; kind: BoardLine['kind'] }> = [];
  if (action.title?.trim() && !containsArabic(action.title)) rows.push({ text: action.title.trim(), kind: 'title' });
  for (const raw of action.content ?? []) {
    for (const part of raw.replace(/\r\n?/g, '\n').split('\n')) {
      if (part.trim() && !containsArabic(part)) rows.push({ text: part.trim(), kind: 'text' });
    }
  }
  return rows.map((row, index) => ({ ...row, clear: !!action.clear && index === 0 }));
}

/**
 * One line is mounted and allowed to finish animating before the next starts.
 * dispatchAsync resolves only after all expanded lines are visibly complete.
 */
export function useBlackboard() {
  const [lines, setLines] = useState<BoardLine[]>([]);
  const [annotations, setAnnotations] = useState<BoardMark[]>([]);
  const [drawings, setDrawings] = useState<BoardDrawingItem[]>([]);
  const [wiping, setWiping] = useState(false);
  const queue = useRef<QueuedLine[]>([]);
  const working = useRef(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const activeDone = useRef<(() => void) | undefined>(undefined);
  const generation = useRef(0);
  const pumpRef = useRef<() => void>(() => undefined);

  const finishAfter = useCallback((ms: number, version: number, item: QueuedLine) => {
    timer.current = setTimeout(() => {
      if (generation.current !== version) return;
      timer.current = null;
      working.current = false;
      activeDone.current = undefined;
      item.done?.();
      pumpRef.current();
    }, ms);
  }, []);

  const pump = useCallback(() => {
    if (working.current) return;
    const item = queue.current.shift();
    if (!item) return;
    working.current = true;
    activeDone.current = item.done;
    const version = generation.current;

    const write = () => {
      if (item.annotation) {
        setAnnotations((old) => [...old, { ...item.annotation!, id: `mark-${++idSequence}` }]);
        finishAfter(950, version, item);
        return;
      }
      if (item.drawing) {
        setDrawings((old) => [...old, { id: `draw-${++idSequence}`, element: item.drawing! }]);
        finishAfter(drawingMs(item.drawing), version, item);
        return;
      }
      if (!item.text) {
        working.current = false;
        activeDone.current = undefined;
        item.done?.();
        pumpRef.current();
        return;
      }
      const line: BoardLine = {
        id: `chalk-${++idSequence}`,
        text: item.text,
        kind: item.kind ?? 'text',
        qcmId: item.qcmId,
        optionIndex: item.optionIndex,
        delayMs: 0,
      };
      setLines((old) => item.clear ? [line] : [...old, line]);
      finishAfter(animationMs(item.text, item.kind), version, item);
    };

    if (item.clear) {
      setWiping(true);
      timer.current = setTimeout(() => {
        if (generation.current !== version) return;
        setWiping(false);
        setAnnotations([]);
        setDrawings([]);
        if (!item.text) setLines([]);
        write();
      }, 650);
    } else write();
  }, [finishAfter]);
  pumpRef.current = pump;

  const enqueueItems = useCallback((items: Array<Omit<QueuedLine, 'done'>>, resolve?: () => void) => {
    if (!items.length) {
      resolve?.();
      return;
    }
    queue.current.push(...items.map((item, index) => ({
      ...item,
      done: index === items.length - 1 ? resolve : undefined,
    })));
    pumpRef.current();
  }, []);

  const dispatch = useCallback((action: ParsedBoardAction) => enqueueItems(expand(action)), [enqueueItems]);
  const dispatchAsync = useCallback((action: ParsedBoardAction): Promise<void> =>
    new Promise((resolve) => enqueueItems(expand(action), resolve)), [enqueueItems]);

  /** The question and EACH selectable option finish writing before this resolves. */
  const showQcm = useCallback((qcm: ParsedQcm, qcmId: string): Promise<void> => {
    const items: Array<Omit<QueuedLine, 'done'>> = [
      { clear: false, text: qcm.question && !containsArabic(qcm.question) ? qcm.question : 'Choisissez la bonne réponse', kind: 'qcm-question', qcmId },
      ...qcm.options.map((option, index) => ({
        clear: false,
        text: `${QCM_LETTERS[index]}. ${containsArabic(option) ? 'Réponse proposée' : stripOptionPrefix(option)}`,
        kind: 'qcm-option' as const,
        optionIndex: index,
        qcmId,
      })),
    ];
    return new Promise((resolve) => enqueueItems(items, resolve));
  }, [enqueueItems]);

  const reset = useCallback(() => {
    generation.current++;
    activeDone.current?.();
    activeDone.current = undefined;
    for (const item of queue.current) item.done?.();
    queue.current = [];
    working.current = false;
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
    setWiping(false);
    setLines([]);
    setAnnotations([]);
    setDrawings([]);
  }, []);

  useEffect(() => () => {
    generation.current++;
    activeDone.current?.();
    for (const item of queue.current) item.done?.();
    if (timer.current) clearTimeout(timer.current);
  }, []);

  return { lines, annotations, drawings, wiping, dispatch, dispatchAsync, showQcm, reset };
}