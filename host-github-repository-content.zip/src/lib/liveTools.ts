/**
 * Function declarations exposed to the Gemini Live session.
 *
 * - get_examen_national / list_examens_nationaux: grounded retrieval from
 *   ./2bac-data-sma/{subject}/examens-nationaux/ (works for voice requests too).
 * - blackboard_write_line / blackboard_clear / blackboard_annotate / blackboard_draw: synchronized JSON
 *   commands to the sole visual teaching surface. Each tool response is held
 *   until the handwriting animation completes, providing pacing backpressure.
 * - ask_qcm: a blocking call; A–D options are clickable handwritten lines
 *   on the board. Its function response is withheld until a student clicks.
 */
import { boardActionFromParts, containsArabic, type BoardDrawElement, type ParsedBoardAction, type ParsedQcm, type ParsedTerm } from './interaction';

export interface LiveFunctionCall {
  id?: string;
  name: string;
  args?: Record<string, unknown>;
}

export interface LiveFunctionResponse {
  id?: string;
  name: string;
  response: Record<string, unknown>;
}

const SUBJECT_PARAM = {
  type: 'STRING',
  enum: ['mathematiques', 'physique-chimie', 'svt'],
  description: 'Subject folder. Default: the active subject of the session.',
};

export const LIVE_TOOL_DECLARATIONS = [
  {
    functionDeclarations: [
      {
        name: 'get_examen_national',
        description:
          "Retrieve the exact official statement (sujet) and correction (corrigé) of a Moroccan Examen National exercise from CALCLUY/data-2bac-sma. The application writes the original statement to the 2:1 chalkboard in French and LaTeX — never to a chat card. Call whenever the student asks for a specific exam/exercise or you need a real example.",
        parameters: {
          type: 'OBJECT',
          properties: {
            subject: SUBJECT_PARAM,
            year: { type: 'INTEGER', description: 'Exam year, e.g. 2018.' },
            session: {
              type: 'STRING',
              enum: ['normale', 'rattrapage'],
              description: 'normale = Session Normale = الدورة العادية ; rattrapage = Session de Contrôle = الدورة الاستدراكية.',
            },
            exercise: { type: 'INTEGER', description: 'Exercise number named by the student (1, 2, 3…). Omit if unknown.' },
            topic: {
              type: 'STRING',
              description: 'Topic named by the student, e.g. "nombres complexes", "arithmétique", "probabilités", "dipôle RC". Omit if none.',
            },
          },
          required: ['year'],
        },
      },
      {
        name: 'list_examens_nationaux',
        description:
          'List the Examen National years and sessions available in the dataset for a subject. With a topic, also list the exam exercises detected for that topic.',
        parameters: {
          type: 'OBJECT',
          properties: {
            subject: SUBJECT_PARAM,
            topic: { type: 'STRING', description: 'Optional topic, e.g. "nombres complexes".' },
          },
        },
      },
      {
        name: 'blackboard_write_line',
        description:
          'MANDATORY synchronized visual action. Immediately AFTER speaking exactly ONE short sentence or equation, call this tool with the matching single visual line. The frontend queues it, animates its chalk handwriting, and withholds the tool response until writing is complete. Do NOT speak the next sentence until the response says animation_complete:true. Never batch two sentences or equations into one line.',
        parameters: {
          type: 'OBJECT',
          properties: {
            clear: { type: 'BOOLEAN', description: 'true only for the first line of a genuinely new step/exercise; it wipes before writing. Otherwise false.' },
            line: { type: 'STRING', description: 'Exactly ONE short French sentence OR ONE LaTeX equation matching the line just spoken. No newline characters and no array.' },
          },
          required: ['line'],
        },
      },
      {
        name: 'blackboard_clear',
        description:
          'Wipe the virtual blackboard before a new step. WAIT for animation_complete:true before speaking or sending blackboard_write_line.',
        parameters: {
          type: 'OBJECT',
          properties: {},
        },
      },
      {
        name: 'blackboard_annotate',
        description:
          'Add ONE hand-drawn chalk mark AFTER the target line has finished writing. Use type underline, arrow or curved_arrow and the exact visible target text/variable (preferred). Alternatively provide both from and to as [x,y] pairs in 0..100 percentages of the 2:1 board surface. Wait for animation_complete before speaking the next line. Do not annotate non-existent targets.',
        parameters: {
          type: 'OBJECT',
          properties: {
            type: { type: 'STRING', enum: ['underline', 'arrow', 'curved_arrow'], description: 'Chalk stroke type.' },
            target: { type: 'STRING', description: 'Exact visible word, variable or equation segment to point at or underline.' },
            from: { type: 'ARRAY', items: { type: 'NUMBER' }, description: 'Optional starting [x,y], each 0..100 percent of canvas.' },
            to: { type: 'ARRAY', items: { type: 'NUMBER' }, description: 'Optional ending [x,y], each 0..100 percent of canvas. Supply with from.' },
          },
          required: ['type'],
        },
      },
      {
        name: 'blackboard_draw',
        description:
          'Draw technical vector geometry directly on the 2:1 chalkboard with normalized 0–100 percentage coordinates. Supports a line, circle, arrow with optional LaTeX label, curve through 2–32 points, or underline of an exact already-written French/LaTeX target. For audio sync, send ONE drawing element per call after narrating it; the tool response waits until the animated chalk stroke is visible. x increases left-to-right; y increases top-to-bottom. Never draw Arabic labels.',
        parameters: {
          type: 'OBJECT',
          properties: {
            elements: {
              type: 'ARRAY',
              description: 'Use a single vector element for one synchronized visual step.',
              items: {
                type: 'OBJECT',
                properties: {
                  type: { type: 'STRING', enum: ['line', 'circle', 'arrow', 'curve', 'underline'] },
                  x1: { type: 'NUMBER' }, y1: { type: 'NUMBER' }, x2: { type: 'NUMBER' }, y2: { type: 'NUMBER' },
                  cx: { type: 'NUMBER' }, cy: { type: 'NUMBER' }, r: { type: 'NUMBER' },
                  from: { type: 'ARRAY', items: { type: 'NUMBER' }, description: '[x,y] pair, percentages 0–100.' },
                  to: { type: 'ARRAY', items: { type: 'NUMBER' }, description: '[x,y] pair, percentages 0–100.' },
                  points: { type: 'ARRAY', items: { type: 'ARRAY', items: { type: 'NUMBER' } }, description: 'Ordered [x,y] pairs, 2–32 points.' },
                  label: { type: 'STRING', description: 'Optional academic French / LaTeX vector label, e.g. "$\\vec{v}$".' },
                  target: { type: 'STRING', description: 'Exact visible French/LaTeX text segment for underline.' },
                },
                required: ['type'],
              },
            },
          },
          required: ['elements'],
        },
      },
      {
        name: 'ask_qcm',
        behavior: 'BLOCKING',
        description:
          'STOP after speaking the complete QCM question in Moroccan Darija. Give this tool the semantically equivalent formal French/LaTeX board question and French/LaTeX options (never Arabic). The frontend writes each as chalk and makes option lines clickable ON the board. This BLOCKING call receives NO function response until a student clicks. Remain entirely silent and do not teach, call another tool, or continue while waiting. The eventual tool response contains the selected answer and correctness; THEN acknowledge briefly in Darija audio, explain why, and resume the lesson.',
        parameters: {
          type: 'OBJECT',
          properties: {
            question: { type: 'STRING', description: 'Formal French/LaTeX equivalent of the spoken Darija question. No Arabic characters.' },
            options: { type: 'ARRAY', items: { type: 'STRING' }, description: '2 to 4 formal French and/or LaTeX options, without "A)" prefixes and with no Arabic characters.' },
            correctIndex: { type: 'INTEGER', description: '0-based index of the correct option.' },
          },
          required: ['question', 'options', 'correctIndex'],
        },
      },
    ],
  },
];

/** Validate ask_qcm arguments (same rules as the JSON QCM block). */
export function qcmFromToolArgs(args: Record<string, unknown>): ParsedQcm | null {
  const question = typeof args.question === 'string' ? args.question.trim() : '';
  const options = Array.isArray(args.options)
    ? args.options.filter((o): o is string => typeof o === 'string' && o.trim().length > 0).map((o) => o.trim().replace(/\s*[\r\n]+\s*/g, ' '))
    : [];
  const ci = typeof args.correctIndex === 'number' ? args.correctIndex : Number(args.correctIndex);
  if (!question || containsArabic(question) || options.some(containsArabic) || options.length < 2 || options.length > 4) return null;
  if (!Number.isInteger(ci) || ci < 0 || ci >= options.length) return null;
  return { question, options, correctIndex: ci };
}

const str = (v: unknown) => (typeof v === 'string' ? v.trim() : '');

/** Validate synchronized and legacy board tool arguments. */
export function boardActionFromToolArgs(name: string, args: Record<string, unknown>): ParsedBoardAction | null {
  const title = str(args.title) || undefined;
  if (name === 'blackboard_clear') return { action: 'blackboard_clear', title };
  if (name === 'blackboard_annotate') return boardActionFromParts(name, args);
  if (name === 'blackboard_draw') {
    if (!Array.isArray(args.elements) || !args.elements.length || args.elements.length > 48) return null;
    const parsed = args.elements.map((entry) => boardActionFromParts('blackboard_draw', { elements: [entry] }));
    if (parsed.some((action) => !action?.drawings?.length)) return null;
    return { action: 'blackboard_draw', drawings: parsed.flatMap((action) => action?.drawings ?? []) as BoardDrawElement[] };
  }
  if (name === 'blackboard_write_line') {
    const line = str(args.line);
    if (!line || line.length > 320 || /[\r\n]/.test(line) || containsArabic(line)) return null;
    return { action: 'blackboard_write_line', clear: args.clear === true, line };
  }
  if (name === 'blackboard_write') {
    const rows = Array.isArray(args.content)
      ? args.content.filter((x): x is string => typeof x === 'string' && x.trim().length > 0).map((x) => x.trim())
      : typeof args.content === 'string' && args.content.trim()
        ? [args.content.trim()]
        : [];
    if (!rows.length) return null;
    return { action: 'blackboard_write', clear: args.clear === true, title, content: rows };
  }
  if (name === 'write_on_board') {
    const content = str(args.content);
    if (!content) return null;
    // Legacy tool: one definition block, always written on a wiped board.
    return { action: 'blackboard_write', clear: true, title, content: [content] };
  }
  return null;
}

/** Validate introduce_term arguments (accepts both naming conventions). */
export function termFromToolArgs(args: Record<string, unknown>): ParsedTerm | null {
  const term = str(args.term);
  const meaning = str(args.meaning_darija) || str(args.meaning);
  const analogy = str(args.analogy_darija) || str(args.analogy);
  if (!term || !meaning) return null;
  return { term, meaning, analogy: analogy || undefined };
}
