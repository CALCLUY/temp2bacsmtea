import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AVAILABLE_LIVE_MODELS, GeminiLiveClient, LIVE_MODEL, type InteractionStatus, type VoiceName } from './lib/geminiLive';
import { isSubjectId, SUBJECT_PROFILES, type SubjectId } from './lib/dataset';
import { buildSystemInstruction, STARTER_PROMPTS } from './lib/prompts';
import { persistGeminiApiKey, readStoredGeminiApiKey } from './lib/arenaIntegration';
import { loadChapterContext, systemInstructionWithChapterContext, type LoadedChapterContext } from './lib/chapterContext';
import { listChapters, STATIC_CHAPTERS, type ChapterDef } from './lib/curriculum';
import { blobUrl, loadRepoIndex, peekRepoIndex } from './lib/dataRepo';
import {
  buildExamContextText,
  examRequestSentence,
  examToolResponse,
  listExamsForTool,
  parseExamRequest,
  requestFromToolArgs,
  retrieveExam,
  statementOf,
  type ExamRequest,
  type ExamRetrieval,
  type RelatedExam,
} from './lib/examRetrieval';
import {
  LIVE_TOOL_DECLARATIONS,
  boardActionFromToolArgs,
  qcmFromToolArgs,
  termFromToolArgs,
  type LiveFunctionCall,
  type LiveFunctionResponse,
} from './lib/liveTools';
import {
  buildQcmAnswerSignal,
  looksLikeYesNoQuestion,
  NOT_UNDERSTOOD_SIGNAL,
  QCM_LETTERS,
  stripOptionPrefix,
  UNDERSTOOD_SIGNAL,
  withDarijaReminder,
  type ParsedBoardAction,
  type ParsedQcm,
} from './lib/interaction';
import { VisualJsonStream, type VisualEvent } from './lib/visualStream';
import { useBlackboard } from './lib/useBlackboard';
import { PcmRecorder, PcmStreamPlayer } from './lib/audioPlayer';
import Blackboard from './components/Blackboard';
import VoiceVisualizer from './components/VoiceVisualizer';
import ExamLookupPanel from './components/ExamLookupPanel';
import ChapterPanel, { type ChapterStatus } from './components/ChapterPanel';
import { cn } from './utils/cn';

type Connection = 'disconnected' | 'connecting' | 'ready' | 'error';
interface CurrentQcm { id: string; data: ParsedQcm }
interface PendingQcmTool {
  client: GeminiLiveClient;
  call: LiveFunctionCall;
  priorResponses: LiveFunctionResponse[];
  skippedCalls: LiveFunctionCall[];
}

const uid = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
const announceExam = (r: ExamRetrieval) =>
  `Examen National ${r.request.year} — ${r.sessionLabel}${r.selected ? ` — Exercice ${r.selected.number}` : ''}`;

/** The SAME structured action is used for app-fetched exams and Gemini JSON. */
function examOnBoard(r: ExamRetrieval): ParsedBoardAction {
  if (!r.ok) {
    return {
      action: 'blackboard_write',
      clear: true,
      title: announceExam(r),
      content: [r.error ?? 'Examen introuvable dans le dataset.', r.availableYears.length
        ? `Années disponibles : ${r.availableYears.join(' · ')}` : ''],
    };
  }
  // Preserve the actual wording and LaTeX of the repository statement.
  const rows = statementOf(r).split(/\r?\n/).filter((row) => row.trim());
  return { action: 'blackboard_write', clear: true, title: announceExam(r), content: rows };
}

const START_ACTIONS = [
  { label: "La suite →", wire: "Bravo, wasel b l'part li jija." },
  { label: 'ما فهمتش', wire: NOT_UNDERSTOOD_SIGNAL },
  { label: 'مثال من الحياة', wire: "عطيني مثال آخر من الحياة اليومية باش نفهم هاد l'notion." },
];

export default function App() {
  const [apiKey, setApiKey] = useState(() => readStoredGeminiApiKey());
  const [rememberKey, setRememberKey] = useState(() => !!readStoredGeminiApiKey());
  const [showKey, setShowKey] = useState(false);
  const [subject, setSubject] = useState<SubjectId>('mathematiques');
  const [chapterKey, setChapterKey] = useState(STATIC_CHAPTERS.mathematiques[0].key);
  const [repoIndex, setRepoIndex] = useState<string[] | null>(() => peekRepoIndex());
  const [chapterCtx, setChapterCtx] = useState<LoadedChapterContext | null>(null);
  const [chapterStatus, setChapterStatus] = useState<ChapterStatus>('loading');
  const [chapterProgress, setChapterProgress] = useState({ done: 0, total: 0 });
  const [chapterError, setChapterError] = useState<string | null>(null);
  const [voice, setVoice] = useState<VoiceName>(SUBJECT_PROFILES.mathematiques.voiceName);
  const [model, setModel] = useState(LIVE_MODEL);
  const [baseInstruction, setBaseInstruction] = useState(() => buildSystemInstruction('mathematiques'));
  const [showPrompt, setShowPrompt] = useState(false);

  const [conn, setConn] = useState<Connection>('disconnected');
  const [interaction, setInteraction] = useState<InteractionStatus>('IDLE');
  const [speaking, setSpeaking] = useState(false);
  const [muted, setMuted] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState('Le cours s’écrit uniquement sur le tableau.');
  const [exam, setExam] = useState<ExamRetrieval | null>(null);
  const [examSent, setExamSent] = useState(false);
  const [examBusy, setExamBusy] = useState(false);
  const [qcm, setQcm] = useState<CurrentQcm | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showCheck, setShowCheck] = useState(false);
  const [input, setInput] = useState('');
  const [showInput, setShowInput] = useState(false);

  const board = useBlackboard();
  const player = useMemo(() => {
    const p = new PcmStreamPlayer(24000);
    p.setStateListener(setSpeaking);
    return p;
  }, []);
  const clientRef = useRef<GeminiLiveClient | null>(null);
  const recorderRef = useRef<PcmRecorder | null>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const mutedRef = useRef(false);
  const subjectRef = useRef(subject);
  const examRef = useRef<ExamRetrieval | null>(null);
  const qcmRef = useRef<CurrentQcm | null>(null);
  const qcmPausedRef = useRef(false);
  const qcmIssuingRef = useRef(false);
  const qcmIssuingCallIdRef = useRef<string | undefined>(undefined);
  const qcmAnsweredRef = useRef(false);
  const pendingQcmToolRef = useRef<PendingQcmTool | null>(null);
  const deferredQcmCallsRef = useRef<LiveFunctionCall[]>([]);
  const qcmGenerationRef = useRef(0);
  const parserRef = useRef(new VisualJsonStream());
  const transcriptRef = useRef('');
  const boardActionsThisTurn = useRef(0);
  const visualRepairAttempts = useRef(0);
  const pendingReconnectRef = useRef(false);
  const connectRef = useRef<() => Promise<void>>(async () => undefined);
  const eventHandlerRef = useRef<(event: VisualEvent) => void>(() => undefined);
  const toolHandlerRef = useRef<(calls: LiveFunctionCall[]) => Promise<void>>(async () => undefined);
  const stopMicRef = useRef<() => void>(() => undefined);
  subjectRef.current = subject;
  mutedRef.current = muted;
  examRef.current = exam;
  qcmRef.current = qcm;

  const chapters = useMemo(() => listChapters(subject, repoIndex), [subject, repoIndex]);
  const chapter: ChapterDef = chapters.find((c) => c.key === chapterKey) ?? chapters[0];
  const ready = conn === 'ready';

  useEffect(() => {
    let alive = true;
    void loadRepoIndex().then((index) => {
      if (alive && index) setRepoIndex(index);
    });
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    if (muted) player.stop();
  }, [muted, player]);

  /* Load exactly the selected chapter files. The board stays blank until a
     structured lesson command or an explicitly requested exam arrives. */
  useEffect(() => {
    let cancelled = false;
    setChapterCtx(null);
    setChapterError(null);
    setChapterStatus('loading');
    setChapterProgress({ done: 0, total: 0 });
    void loadChapterContext(subject, chapterKey, (done, total) => {
      if (!cancelled) setChapterProgress({ done, total });
    }).then((ctx) => {
      if (cancelled) return;
      setChapterCtx(ctx);
      setChapterStatus(ctx.files.length ? 'ready' : 'error');
      if (!ctx.files.length) setChapterError('Fichiers indisponibles : le verrou de chapitre reste actif.');
      setStatus(`🔒 ${ctx.chapter.number} — ${ctx.chapter.title} · ${ctx.files.length} fichier(s) chargé(s)`);
    }).catch((err: unknown) => {
      if (cancelled) return;
      setChapterStatus('error');
      setChapterError(err instanceof Error ? err.message : String(err));
    });
    return () => { cancelled = true; };
  }, [subject, chapterKey]);

  /* JSON-stream events and Live tool calls converge here. Only structured
     board actions are rendered; raw model text and audio captions stay hidden. */
  const handleVisualEvent = useCallback((event: VisualEvent) => {
    if (qcmPausedRef.current) return;
    // A response after the click replaces the completed QCM even when the
    // teacher's next check is audio-only (no intervening board line).
    if (qcmAnsweredRef.current) {
      qcmAnsweredRef.current = false;
      qcmRef.current = null;
      setQcm(null);
    }
    if (event.kind === 'board') {
      boardActionsThisTurn.current++;
      board.dispatch(event.action);
      return;
    }
    if (event.kind === 'term') {
      boardActionsThisTurn.current++;
      const term = event.term;
      // The spoken channel contains the Darija definition; on-board lettering
      // remains academic French only.
      void board.dispatchAsync({
        action: 'blackboard_write',
        clear: false,
        content: [`Terme : ${term.term}`],
      });
      return;
    }
    if (event.kind === 'qcm') {
      qcmPausedRef.current = true;
      qcmAnsweredRef.current = false;
      const generation = ++qcmGenerationRef.current;
      player.stop();
      stopMicRef.current();
      boardActionsThisTurn.current++;
      const next = { id: uid(), data: event.qcm };
      void board.showQcm(event.qcm, next.id).then(() => {
        if (!qcmPausedRef.current || qcmGenerationRef.current !== generation) return;
        qcmRef.current = next;
        setQcm(next);
        setSelectedAnswer(null);
        setShowCheck(false);
        setStatus('Choisis une réponse directement sur le tableau.');
      });
      return;
    }
    setShowCheck(true);
  }, [board.dispatch, board.showQcm, player]);
  eventHandlerRef.current = handleVisualEvent;

  const stopMic = useCallback(() => {
    recorderRef.current?.stop();
    recorderRef.current = null;
    setIsRecording(false);
  }, []);
  stopMicRef.current = stopMic;

  const disconnect = useCallback(() => {
    pendingReconnectRef.current = false;
    stopMic();
    qcmGenerationRef.current++;
    qcmPausedRef.current = false;
    qcmIssuingRef.current = false;
    qcmIssuingCallIdRef.current = undefined;
    pendingQcmToolRef.current = null;
    deferredQcmCallsRef.current = [];
    qcmRef.current = null;
    setQcm(null);
    setSelectedAnswer(null);
    clientRef.current?.disconnect();
    clientRef.current = null;
    parserRef.current.reset();
    player.stop();
    setConn('disconnected');
    setInteraction('IDLE');
    setStatus('Déconnecté. Le tableau reste disponible.');
  }, [player, stopMic]);

  const suspendForChapter = useCallback(() => {
    pendingReconnectRef.current = true;
    stopMic();
    qcmGenerationRef.current++;
    qcmPausedRef.current = false;
    qcmIssuingRef.current = false;
    qcmIssuingCallIdRef.current = undefined;
    pendingQcmToolRef.current = null;
    deferredQcmCallsRef.current = [];
    clientRef.current?.disconnect();
    clientRef.current = null;
    parserRef.current.reset();
    board.reset();
    setExam(null);
    setQcm(null);
    qcmRef.current = null;
    setShowCheck(false);
    player.stop();
    setConn('connecting');
    setInteraction('IDLE');
    setStatus('Chargement du nouveau chapitre…');
  }, [board.reset, player, stopMic]);

  const selectSubject = useCallback((next: SubjectId) => {
    if (next === subject) return;
    if (conn === 'ready' || conn === 'connecting') suspendForChapter();
    else {
      board.reset();
      setExam(null);
      setQcm(null);
      qcmRef.current = null;
      setShowCheck(false);
    }
    setSubject(next);
    setChapterKey(STATIC_CHAPTERS[next][0].key);
    setVoice(SUBJECT_PROFILES[next].voiceName);
    setBaseInstruction(buildSystemInstruction(next));
    setError(null);
  }, [subject, conn, board.reset, suspendForChapter]);

  const selectChapter = useCallback((next: string) => {
    if (next === chapterKey) return;
    if (conn === 'ready' || conn === 'connecting') suspendForChapter();
    else {
      board.reset();
      setExam(null);
      setQcm(null);
      qcmRef.current = null;
      setShowCheck(false);
    }
    setChapterKey(next);
    setError(null);
  }, [chapterKey, conn, board.reset, suspendForChapter]);

  const connect = useCallback(async () => {
    const key = apiKey.trim();
    if (!key) {
      setError('Entre ta clé API Gemini pour commencer.');
      return;
    }
    setError(null);
    persistGeminiApiKey(key, rememberKey);
    try { await player.ensureContext(); } catch { /* next gesture can unlock audio */ }
    clientRef.current?.disconnect();
    qcmGenerationRef.current++;
    qcmPausedRef.current = false;
    qcmIssuingRef.current = false;
    qcmIssuingCallIdRef.current = undefined;
    pendingQcmToolRef.current = null;
    deferredQcmCallsRef.current = [];
    parserRef.current.reset();
    transcriptRef.current = '';
    boardActionsThisTurn.current = 0;
    visualRepairAttempts.current = 0;
    setConn('connecting');
    setInteraction('IDLE');
    setStatus('Connexion au professeur…');

    // Native-audio Live models cannot emit an independent ordinary text channel.
    // Function calls carry structured JSON arguments, and modelTurn.parts[].text
    // is parsed as an additional JSON-stream fallback where available.
    const instruction = systemInstructionWithChapterContext(baseInstruction, subject, chapter, chapterCtx);
    const client = new GeminiLiveClient(
      { apiKey: key, model, subject, voice, systemInstruction: instruction, tools: LIVE_TOOL_DECLARATIONS },
      {
        onSetupComplete: () => {
          if (clientRef.current !== client) return;
          setConn('ready');
          setStatus(`Prêt · ${chapter.number} — ${chapter.title} · voix ${voice}`);
        },
        onAudioChunk: (data, mime) => {
          if (qcmPausedRef.current) return;
          player.setReceivingStream(true);
          if (!mutedRef.current) void player.enqueueBase64(data, mime);
        },
        onOutputTranscription: (text) => {
          // A caption of the Darija VOICE, not a visual board instruction.
          // Never display it in a chat box or write it to the board.
          transcriptRef.current += text;
        },
        onInputTranscription: () => { /* student captions are not rendered */ },
        onModelText: (chunk) => {
          if (qcmPausedRef.current) return;
          for (const event of parserRef.current.push(chunk)) {
            if (qcmPausedRef.current) break;
            eventHandlerRef.current(event);
          }
        },
        onInteractionStatus: setInteraction,
        onToolCall: (calls) => {
          if (qcmPausedRef.current) {
            deferredQcmCallsRef.current.push(...calls);
            return;
          }
          if (calls.some((call) => call.name === 'ask_qcm')) {
            qcmPausedRef.current = true;
            player.stop();
            stopMicRef.current();
            setShowCheck(false);
          }
          void toolHandlerRef.current(calls);
        },
        onToolCallCancellation: (ids) => {
          const pending = pendingQcmToolRef.current;
          const cancelled = (pending?.client === client && pending.call.id && ids.includes(pending.call.id)) ||
            (qcmIssuingCallIdRef.current && ids.includes(qcmIssuingCallIdRef.current));
          if (cancelled) {
            pendingQcmToolRef.current = null;
            deferredQcmCallsRef.current = [];
            qcmPausedRef.current = false;
            qcmIssuingRef.current = false;
            qcmIssuingCallIdRef.current = undefined;
            qcmGenerationRef.current++;
            qcmRef.current = null;
            setQcm(null);
            setStatus('Question annulée. Pose une nouvelle question.');
          }
        },
        onTurnComplete: () => {
          player.setReceivingStream(false);
          parserRef.current.reset();
          setInteraction('IDLE');
          const spoken = transcriptRef.current;
          transcriptRef.current = '';
          if (qcmPausedRef.current) return;
          if (qcmAnsweredRef.current && looksLikeYesNoQuestion(spoken)) {
            qcmAnsweredRef.current = false;
            qcmRef.current = null;
            setQcm(null);
          }
          if (!qcmRef.current && looksLikeYesNoQuestion(spoken)) setShowCheck(true);
          if (boardActionsThisTurn.current === 0 && spoken.trim().length > 25 && visualRepairAttempts.current < 1) {
            visualRepairAttempts.current++;
            client.sendText('[VISUAL REPAIR] You spoke, but the board received no structured visual action. Without repeating the audio, call blackboard_write_line exactly once with ONE short matching French/LaTeX line, then wait for animation_complete. No free-form text.');
          }
        },
        onInterrupted: () => {
          player.stop();
          parserRef.current.reset();
        },
        onError: (message) => {
          setError(message);
          setConn((old) => old === 'connecting' ? 'error' : old);
        },
        onGoAway: () => setStatus('La session se termine bientôt.'),
        onClose: (code, reason) => {
          if (clientRef.current !== client) return;
          clientRef.current = null;
          qcmGenerationRef.current++;
          qcmPausedRef.current = false;
          qcmIssuingRef.current = false;
          qcmIssuingCallIdRef.current = undefined;
          pendingQcmToolRef.current = null;
          deferredQcmCallsRef.current = [];
          qcmRef.current = null;
          setQcm(null);
          setSelectedAnswer(null);
          player.stop();
          setInteraction('IDLE');
          stopMic();
          if (code !== 1000) {
            setConn('error');
            setError(reason || `Connexion fermée (${code}). Vérifie la clé API et l’accès au modèle Live.`);
          } else {
            setConn('disconnected');
            setStatus('Session terminée.');
          }
        },
      },
    );
    clientRef.current = client;
    client.connect();
  }, [apiKey, rememberKey, player, baseInstruction, subject, chapter, chapterCtx, model, voice, stopMic]);
  connectRef.current = connect;

  // Reconnect only AFTER the exact files for the selected chapter are loaded.
  useEffect(() => {
    if (!pendingReconnectRef.current || chapterStatus === 'loading') return;
    if (chapterStatus === 'ready' && (chapterCtx?.subject !== subject || chapterCtx.chapter.key !== chapterKey)) return;
    pendingReconnectRef.current = false;
    void connectRef.current();
  }, [chapterStatus, chapterCtx, subject, chapterKey]);

  useEffect(() => () => {
    recorderRef.current?.stop();
    clientRef.current?.disconnect();
    void player.close();
  }, [player]);

  /** Send text to Gemini but do not create a text bubble. */
  const sendWire = useCallback((text: string, keepChoice = false): boolean => {
    const client = clientRef.current;
    if (!client?.isReady) return false;
    if (qcmPausedRef.current) {
      setStatus('Choisis d’abord une réponse directement sur le tableau.');
      return false;
    }
    parserRef.current.reset();
    transcriptRef.current = '';
    boardActionsThisTurn.current = 0;
    visualRepairAttempts.current = 0;
    if (!keepChoice) {
      qcmRef.current = null;
      setQcm(null);
      setSelectedAnswer(null);
    }
    setShowCheck(false);
    player.stop();
    setInteraction('IN_PROGRESS');
    client.sendText(withDarijaReminder(text));
    return true;
  }, [player]);

  const openExam = useCallback(async (request: ExamRequest, studentText?: string) => {
    if (qcmPausedRef.current) {
      setStatus('Réponds au QCM sur le tableau avant de changer d’exercice.');
      return;
    }
    setExamBusy(true);
    setError(null);
    try {
      const retrieved = await retrieveExam(request);
      setExam(retrieved);
      examRef.current = retrieved;
      board.dispatch(examOnBoard(retrieved));
      setStatus(retrieved.ok ? `Sujet chargé depuis le dataset · ${announceExam(retrieved)}` : 'Sujet indisponible : voir le tableau.');
      const sentence = studentText ?? examRequestSentence(request);
      const sent = sendWire(`${sentence}\n\n${buildExamContextText(retrieved)}`);
      setExamSent(sent);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setExamBusy(false);
    }
  }, [board.dispatch, sendWire]);

  const openRelated = useCallback((item: RelatedExam) => {
    void openExam({ subject, year: item.year, session: item.session, sessionExplicit: true, exercise: item.exercise });
  }, [subject, openExam]);

  const send = useCallback(async () => {
    const text = input.trim();
    if (!text || !ready || qcmPausedRef.current) return;
    setInput('');
    const request = parseExamRequest(text, subject);
    if (request) {
      await openExam(request, text);
      return;
    }
    sendWire(text);
  }, [input, ready, subject, openExam, sendWire]);

  const answerQcm = useCallback((index: number) => {
    const current = qcmRef.current;
    const client = clientRef.current;
    if (!current || !client?.isReady || qcmAnsweredRef.current || selectedAnswer !== null || index >= current.data.options.length) return;
    qcmAnsweredRef.current = true;
    setSelectedAnswer(index);
    const { signal } = buildQcmAnswerSignal(current.data, index);
    const correct = index === current.data.correctIndex;
    const pending = pendingQcmToolRef.current;
    pendingQcmToolRef.current = null;
    qcmPausedRef.current = false;
    qcmIssuingRef.current = false;
    qcmIssuingCallIdRef.current = undefined;
    player.stop();
    parserRef.current.reset();
    transcriptRef.current = '';
    boardActionsThisTurn.current = 0;
    visualRepairAttempts.current = 0;
    setInteraction('IN_PROGRESS');
    setStatus('Réponse envoyée. Écoute la correction du professeur.');

    if (pending?.client === client) {
      const deferred = [...pending.skippedCalls, ...deferredQcmCallsRef.current];
      deferredQcmCallsRef.current = [];
      client.sendToolResponse([
        ...pending.priorResponses,
        {
          id: pending.call.id,
          name: pending.call.name,
          response: {
            student_answer: { index, letter: QCM_LETTERS[index], option: stripOptionPrefix(current.data.options[index]) },
            correct,
            correct_letter: QCM_LETTERS[current.data.correctIndex],
            instruction: 'NOW briefly acknowledge correctness in Darija audio, explain WHY, then resume the lesson. If wrong, re-teach the same concept with a different analogy before a NEW QCM.',
            signal,
          },
        },
        ...deferred.map((call) => ({
          id: call.id, name: call.name,
          response: { skipped: true, reason: 'QCM paused until the student answered; issue this action again if needed.' },
        })),
      ]);
    } else {
      const deferred = deferredQcmCallsRef.current;
      deferredQcmCallsRef.current = [];
      if (deferred.length) client.sendToolResponse(deferred.map((call) => ({
        id: call.id, name: call.name,
        response: { skipped: true, reason: 'The student was answering an on-board QCM; request this action again if needed.' },
      })));
      // JSON-stream fallback has no outstanding tool call to release.
      sendWire(signal, true);
    }
  }, [player, selectedAnswer, sendWire]);

  const toggleMic = useCallback(async () => {
    if (recorderRef.current) {
      stopMic();
      clientRef.current?.sendAudioStreamEnd();
      return;
    }
    if (!clientRef.current?.isReady) {
      setError('Connecte-toi pour parler au professeur.');
      return;
    }
    if (qcmPausedRef.current) {
      setStatus('Clique une réponse sur le tableau avant de reparler.');
      return;
    }
    try {
      await player.ensureContext();
      const rec = new PcmRecorder((b64) => { clientRef.current?.sendAudioChunk(b64); });
      await rec.start();
      recorderRef.current = rec;
      setIsRecording(true);
      setError(null);
    } catch (err) {
      setError(`Micro indisponible : ${err instanceof Error ? err.message : String(err)}`);
    }
  }, [player, stopMic]);

  const handleToolCalls = useCallback(async (calls: LiveFunctionCall[]) => {
    const client = clientRef.current;
    if (!client) return;
    if (qcmIssuingRef.current || pendingQcmToolRef.current) {
      deferredQcmCallsRef.current.push(...calls);
      return;
    }
    const upcomingQcm = calls.find((call) => call.name === 'ask_qcm');
    if (upcomingQcm) {
      qcmIssuingRef.current = true;
      qcmIssuingCallIdRef.current = upcomingQcm.id;
    }
    const responses: LiveFunctionResponse[] = [];
    for (const [position, call] of calls.entries()) {
      const args = call.args ?? {};
      try {
        if (call.name === 'blackboard_draw' || call.name === 'blackboard_annotate' || call.name === 'blackboard_write_line' || call.name === 'blackboard_write' || call.name === 'blackboard_clear' || call.name === 'write_on_board') {
          const action = boardActionFromToolArgs(call.name, args);
          if (action) {
            if (qcmAnsweredRef.current) {
              qcmAnsweredRef.current = false;
              qcmRef.current = null;
              setQcm(null);
            }
            boardActionsThisTurn.current++;
            // Deliberate backpressure: Gemini receives no function response
            // until the eraser/writing/annotation animation is complete.
            await board.dispatchAsync(action);
          }
          responses.push({ id: call.id, name: call.name, response: action
            ? {
                displayed: true,
                animation_complete: true,
                instruction: 'Now, and only now, you may speak the next sentence and then call blackboard_write_line for that one line.',
              }
            : { displayed: false, error: 'Use one short blackboard_write_line, one blackboard_draw element, or a valid blackboard_annotate target/vector.' } });
        } else if (call.name === 'ask_qcm') {
          if (!qcmPausedRef.current && !qcmIssuingRef.current) {
            responses.push({ id: call.id, name: call.name, response: { cancelled: true } });
            continue;
          }
          const parsed = qcmFromToolArgs(args);
          if (!parsed) {
            qcmPausedRef.current = false;
            qcmIssuingRef.current = false;
            qcmIssuingCallIdRef.current = undefined;
            responses.push({ id: call.id, name: call.name, response: { displayed: false, error: 'QCM requires a question, 2–4 options, and a valid correctIndex.' } });
            continue;
          }
          qcmPausedRef.current = true;
          qcmAnsweredRef.current = false;
          qcmIssuingCallIdRef.current = call.id;
          const generation = ++qcmGenerationRef.current;
          const next = { id: uid(), data: parsed };
          boardActionsThisTurn.current++;
          await board.showQcm(parsed, next.id);
          if (clientRef.current !== client || generation !== qcmGenerationRef.current) return;
          qcmRef.current = next;
          setQcm(next);
          setSelectedAnswer(null);
          setShowCheck(false);
          setStatus('Question en pause : clique une réponse sur le tableau.');
          pendingQcmToolRef.current = {
            client,
            call,
            priorResponses: responses,
            skippedCalls: calls.slice(position + 1),
          };
          qcmIssuingRef.current = false;
          qcmIssuingCallIdRef.current = undefined;
          // BLOCKING function call: do not send ask_qcm's response until a click.
          return;
        } else if (call.name === 'introduce_term') {
          const term = termFromToolArgs(args);
          if (term) {
            boardActionsThisTurn.current++;
            await board.dispatchAsync({
              action: 'blackboard_write',
              clear: false,
              content: [`Terme : ${term.term}`],
            });
          }
          responses.push({ id: call.id, name: call.name, response: {
            displayed: !!term,
            animation_complete: !!term,
            reminder: 'The term lines are complete. Continue speaking only now.',
          } });
        } else if (call.name === 'get_examen_national') {
          const request = requestFromToolArgs(args, subjectRef.current);
          if (!request) {
            responses.push({ id: call.id, name: call.name, response: { found: false, error: 'Invalid year.' } });
            continue;
          }
          setExamBusy(true);
          let retrieved: ExamRetrieval;
          try { retrieved = await retrieveExam(request); }
          finally { setExamBusy(false); }
          if (clientRef.current !== client) break;
          const previous = examRef.current;
          const same = previous?.request.year === request.year && previous.request.session === request.session &&
            previous.request.subject === request.subject && previous.selected?.number === retrieved.selected?.number;
          if (!same) {
            setExam(retrieved);
            examRef.current = retrieved;
            board.dispatch(examOnBoard(retrieved));
          }
          setExamSent(true);
          responses.push({ id: call.id, name: call.name, response: examToolResponse(retrieved) });
        } else if (call.name === 'list_examens_nationaux') {
          const requestedSubject = isSubjectId(args.subject) ? args.subject : subjectRef.current;
          responses.push({ id: call.id, name: call.name,
            response: await listExamsForTool(requestedSubject, typeof args.topic === 'string' ? args.topic : undefined) });
        } else {
          responses.push({ id: call.id, name: call.name, response: { error: `Unknown tool: ${call.name}` } });
        }
      } catch (err) {
        if (call.name === 'ask_qcm') {
          qcmPausedRef.current = false;
          qcmIssuingRef.current = false;
          qcmIssuingCallIdRef.current = undefined;
        }
        responses.push({ id: call.id, name: call.name, response: { error: err instanceof Error ? err.message : String(err) } });
      }
    }
    if (client && clientRef.current === client) client.sendToolResponse(responses);
  }, [board.dispatch, board.dispatchAsync, board.showQcm]);
  toolHandlerRef.current = handleToolCalls;

  const starterPrompts = useMemo(() => [
    `بدا معايا «${chapter.title}» من الصفر`,
    `شرح ليا ${chapter.title} بمثال بسيط من الحياة`,
    ...STARTER_PROMPTS[subject].slice(0, 1),
  ], [chapter.title, subject]);

  const onInputKeyDown = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      void send();
    }
  };

  return (
    <div className="flex min-h-screen flex-col bg-zinc-950 text-zinc-100 lg:h-screen lg:overflow-hidden">
      <header className="shrink-0 border-b border-zinc-800 bg-zinc-950 px-4 py-3">
        <div className="mx-auto flex max-w-7xl items-center gap-3">
          <div className="flex size-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-sky-500 text-white"><SparkIcon className="size-5" /></div>
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-sm font-semibold sm:text-base">Gemini Live · أستاذ 2ème BAC SM</h1>
            <p className="truncate text-[11px] text-zinc-500">Voix en Darija · leçon uniquement sur le tableau · {chapter.number} {chapter.title}</p>
          </div>
          <StatusPill conn={conn} interaction={interaction} speaking={speaking} waitingForAnswer={qcmPausedRef.current} />
        </div>
      </header>

      <main className="mx-auto flex w-full max-w-7xl flex-1 flex-col gap-4 overflow-y-auto px-3 py-4 lg:flex-row lg:overflow-hidden lg:px-4">
        <aside className="order-2 w-full shrink-0 space-y-4 lg:order-1 lg:w-[20rem] lg:overflow-y-auto lg:pb-4 lg:pr-1">
          <section className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-4">
            <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-zinc-400">Session</h2>
            <p className="mb-2 text-xs text-zinc-500">Matière / professeur</p>
            <div className="grid grid-cols-3 gap-2">
              {(Object.values(SUBJECT_PROFILES) as Array<(typeof SUBJECT_PROFILES)[SubjectId]>).map((p) => (
                <button key={p.id} type="button" onClick={() => selectSubject(p.id)}
                  className={cn('rounded-lg border px-2 py-2 text-left transition-colors', subject === p.id
                    ? 'border-violet-500 bg-violet-950/40 text-white'
                    : 'border-zinc-700 bg-zinc-950 text-zinc-400 hover:border-zinc-500 hover:text-white')}>
                  <span className="block text-xs font-semibold">{p.shortLabel}</span>
                  <span className="block truncate text-[10px] text-zinc-500">{p.voiceName}</span>
                </button>
              ))}
            </div>
            <ChapterPanel
              chapters={chapters} chapterKey={chapter.key} onSelect={selectChapter}
              status={chapterStatus} progress={chapterProgress} ctx={chapterCtx}
              error={chapterError} live={ready || conn === 'connecting'} onOpenExam={openRelated}
            />

            <label className="mt-4 block text-xs text-zinc-400" htmlFor="api-key">Clé API Gemini</label>
            <div className="relative mt-1">
              <input id="api-key" type={showKey ? 'text' : 'password'} value={apiKey}
                onChange={(e) => setApiKey(e.target.value)} disabled={ready || conn === 'connecting'}
                placeholder="AIza..." autoComplete="off" spellCheck={false}
                className="w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 pr-16 font-mono text-sm outline-none focus:border-violet-500 disabled:opacity-60" />
              <button type="button" onClick={() => setShowKey((v) => !v)}
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded px-2 py-0.5 text-[11px] text-zinc-400 hover:bg-zinc-800">
                {showKey ? 'Hide' : 'Show'}
              </button>
            </div>
            <label className="mt-2 flex cursor-pointer items-center gap-2 text-xs text-zinc-400">
              <input type="checkbox" checked={rememberKey} onChange={(e) => setRememberKey(e.target.checked)} className="size-3.5 accent-violet-500" />
              Mémoriser dans ce navigateur
            </label>
            <p className="mt-1 text-[11px] text-zinc-500">Créer une clé sur <a href="https://aistudio.google.com/apikey" target="_blank" rel="noreferrer" className="text-violet-400 hover:underline">Google AI Studio ↗</a></p>
            <label className="mt-4 block text-xs text-zinc-400" htmlFor="model">Modèle Live</label>
            <select id="model" value={model} onChange={(e) => setModel(e.target.value)} disabled={ready || conn === 'connecting'}
              className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-2 py-2 font-mono text-xs outline-none focus:border-violet-500 disabled:opacity-60">
              {AVAILABLE_LIVE_MODELS.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}
            </select>
            <p className="mt-2 text-[11px] leading-relaxed text-zinc-500">Les outils JSON Live sont toujours actifs : le modèle audio ne possède pas de canal texte visuel indépendant.</p>

            <div className="mt-4 rounded-lg border border-zinc-800 bg-zinc-950/60">
              <button type="button" onClick={() => setShowPrompt((v) => !v)}
                className="flex w-full items-center justify-between px-3 py-2 text-left text-xs text-zinc-300">
                <span>🇲🇦 Prompt système · affichage tableau uniquement</span><span className="text-zinc-500">{showPrompt ? 'Masquer' : 'Modifier'}</span>
              </button>
              {showPrompt && <div className="space-y-2 border-t border-zinc-800 p-3">
                <p className="text-[11px] text-zinc-500">Le verrou du chapitre et les extraits de cours sont ajoutés automatiquement à la connexion.</p>
                <textarea value={baseInstruction} onChange={(e) => setBaseInstruction(e.target.value)}
                  disabled={ready || conn === 'connecting'} spellCheck={false}
                  className="h-48 w-full resize-y rounded-lg border border-zinc-700 bg-zinc-950 p-2 font-mono text-[11px] leading-relaxed text-zinc-300 outline-none focus:border-violet-500 disabled:opacity-60" />
                <button type="button" onClick={() => setBaseInstruction(buildSystemInstruction(subject))}
                  disabled={ready || conn === 'connecting'} className="rounded-md border border-zinc-700 px-2 py-1 text-[11px] text-zinc-300 disabled:opacity-50">Réinitialiser</button>
              </div>}
            </div>

            <div className="mt-4 flex gap-2">
              {ready || conn === 'connecting' ?
                <button type="button" onClick={disconnect} className="flex-1 rounded-lg border border-zinc-700 bg-zinc-800 px-3 py-2 text-sm hover:bg-zinc-700">Déconnecter</button> :
                <button type="button" onClick={() => void connect()} disabled={!apiKey.trim() || chapterStatus === 'loading'}
                  className="flex-1 rounded-lg bg-gradient-to-r from-violet-600 to-sky-500 px-3 py-2 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:opacity-50">Connecter</button>}
              <button type="button" onClick={() => setMuted((v) => !v)} title={muted ? 'Réactiver la voix' : 'Couper la voix'}
                className="rounded-lg border border-zinc-700 bg-zinc-800 p-2 hover:bg-zinc-700">
                {muted ? <MuteIcon className="size-4" /> : <SpeakerIcon className="size-4" />}
              </button>
            </div>
            {error && <p role="alert" className="mt-3 rounded-lg border border-rose-900/60 bg-rose-950/40 p-2 text-xs text-rose-200">{error}</p>}
          </section>
          <ExamLookupPanel subject={subject} chapters={chapters} busy={examBusy || qcmPausedRef.current} onOpen={(request) => void openExam(request)} />
          <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-3">
            <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Voix de l’enseignant</p>
            <VoiceVisualizer analyser={player.getAnalyser()} active={speaking && !muted} className="h-14 w-full" />
          </div>
        </aside>

        <section className="order-1 flex min-w-0 flex-1 flex-col gap-4 lg:order-2 lg:min-h-0 lg:overflow-y-auto lg:pb-4">
          {/* No chat response pane, transcript bubble, exam card or board chrome. */}
            <Blackboard
            lines={board.lines}
            annotations={board.annotations}
            drawings={board.drawings}
            activeQcmId={qcm?.id}
            selectedAnswer={selectedAnswer}
            canAnswer={ready && qcmPausedRef.current && !qcmAnsweredRef.current}
            onAnswer={answerQcm}
            wiping={board.wiping}
            className="mx-auto shrink-0"
          />
          <div className="mx-auto w-full max-w-[900px] space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 px-0.5 text-[11px] text-zinc-500">
              <span role="status" aria-live="polite">{status}</span>
              {exam?.sujetPath && <a href={blobUrl(exam.sujetPath)} target="_blank" rel="noreferrer" className="text-zinc-400 hover:text-white">Source du sujet ↗</a>}
            </div>

            {exam && <div className="flex flex-wrap items-center gap-2 rounded-xl border border-zinc-800 bg-zinc-900/55 p-2">
              <span className="mr-1 text-[11px] text-zinc-400">{announceExam(exam)}</span>
              {exam.exercises.map((item) =>
                <button type="button" key={item.number}
                  disabled={qcmPausedRef.current}
                  onClick={() => void openExam({ ...exam.request, exercise: item.number, topicKey: undefined, wantsProblem: false })}
                  className={cn('rounded-md border px-2 py-1 text-[11px] disabled:cursor-not-allowed disabled:opacity-40', exam.selected?.number === item.number
                    ? 'border-sky-500 bg-sky-950/50 text-sky-100'
                    : 'border-zinc-700 text-zinc-300 hover:border-sky-500')}>
                  Ex {item.number}
                </button>)}
              {!examSent && ready && <button type="button" onClick={() => {
                if (sendWire(`${examRequestSentence(exam.request)}\n\n${buildExamContextText(exam)}`)) setExamSent(true);
              }} className="rounded-md border border-violet-700 px-2 py-1 text-[11px] text-violet-200">Étudier avec le prof</button>}
              {exam.correction && <button type="button" disabled={qcmPausedRef.current} onClick={() => board.dispatch({
                action: 'blackboard_write', clear: true,
                title: `Corrigé officiel · ${exam.request.year} · Exercice ${exam.selected?.number ?? '—'}`,
                content: exam.correction!.split(/\r?\n/).filter((row) => row.trim()),
              })} className="rounded-md border border-emerald-800 px-2 py-1 text-[11px] text-emerald-200 hover:border-emerald-500 disabled:cursor-not-allowed disabled:opacity-40">Voir le corrigé au tableau</button>}
            </div>}

            {qcm && <p role="status" className="text-center text-xs text-zinc-400">
              {selectedAnswer === null
                ? 'Choisis directement une réponse manuscrite sur le tableau.'
                : 'Réponse reçue. Écoute l’explication avant de continuer.'}
            </p>}
            {showCheck && !qcm && ready && <div className="grid grid-cols-2 gap-2 rounded-xl border border-zinc-800 bg-zinc-900/55 p-3">
              <button type="button" onClick={() => { setShowCheck(false); sendWire(UNDERSTOOD_SIGNAL); }}
                className="flex items-center justify-center gap-2 rounded-lg bg-emerald-600 px-3 py-2 text-sm font-semibold text-white hover:bg-emerald-500">
                <CheckIcon className="size-5" /> صحيح / فهمت
              </button>
              <button type="button" onClick={() => { setShowCheck(false); sendWire(NOT_UNDERSTOOD_SIGNAL); }}
                className="flex items-center justify-center gap-2 rounded-lg bg-rose-600 px-3 py-2 text-sm font-semibold text-white hover:bg-rose-500">
                <CrossIcon className="size-5" /> خطأ / مافهمتش
              </button>
            </div>}

            <div className="flex flex-wrap items-center gap-2">
              <button type="button" onClick={() => void toggleMic()} disabled={(!ready && !isRecording) || (qcmPausedRef.current && !isRecording)}
                title={isRecording ? 'Couper le micro' : 'Parler au prof'}
                className={cn('flex items-center gap-2 rounded-full border px-3 py-2 text-xs font-semibold disabled:cursor-not-allowed disabled:opacity-40',
                  isRecording ? 'border-rose-500 bg-rose-600 text-white' : 'border-zinc-700 bg-zinc-800 text-zinc-200 hover:border-sky-500')}>
                <MicIcon className="size-4" /> {isRecording ? 'Micro ON · هضر' : 'Parler'}
              </button>
              {ready && START_ACTIONS.map((action) => <button key={action.label} type="button"
                disabled={qcmPausedRef.current}
                onClick={() => sendWire(action.wire)}
                className="rounded-full border border-zinc-700 bg-zinc-800/70 px-3 py-2 text-xs text-zinc-300 hover:border-violet-500 hover:text-white disabled:cursor-not-allowed disabled:opacity-40">
                {action.label}
              </button>)}
            </div>

            {ready && board.lines.length === 0 && <div className="flex flex-wrap gap-2">
              {starterPrompts.map((prompt) => <button key={prompt} type="button" dir="auto"
                onClick={() => { const request = parseExamRequest(prompt, subject); if (request) void openExam(request, prompt); else sendWire(prompt); }}
                className="rounded-full border border-zinc-700/70 px-3 py-1.5 text-xs text-zinc-400 hover:border-violet-500 hover:text-white">
                {prompt}
              </button>)}
            </div>}

            <div className="relative pb-4 pr-14">
              {showInput ? <div className="flex gap-2 rounded-xl border border-zinc-700 bg-zinc-900 p-2 focus-within:border-violet-500">
                <textarea ref={inputRef} rows={1} dir="auto" value={input} onChange={(e) => setInput(e.target.value)}
                  onKeyDown={onInputKeyDown} disabled={!ready || qcmPausedRef.current}
                  placeholder={ready ? 'كتب سؤالك هنا… (Enter للإرسال)' : 'Connecte-toi d’abord pour écrire'}
                  className="min-h-10 flex-1 resize-none bg-transparent px-2 py-2 text-sm outline-none placeholder:text-zinc-600 disabled:opacity-50" />
                <button type="button" onClick={() => void send()} disabled={!ready || !input.trim() || qcmPausedRef.current}
                  title="Envoyer" className="rounded-lg bg-violet-600 p-2 text-white disabled:cursor-not-allowed disabled:opacity-40">
                  <SendIcon className="size-5" />
                </button>
              </div> : <p className="py-2 text-[11px] text-zinc-600">Pas de chat texte : les réponses sont vocales et les contenus apparaissent uniquement au tableau.</p>}
              <button type="button" aria-label={showInput ? 'Masquer la saisie' : 'Ouvrir la saisie'}
                title={showInput ? 'Masquer la saisie' : 'Écrire une question'}
                onClick={() => setShowInput((old) => { if (!old) setTimeout(() => inputRef.current?.focus(), 50); return !old; })}
                className={cn('absolute right-0 top-0 flex size-11 items-center justify-center rounded-full border text-xl',
                  showInput ? 'border-violet-500 bg-violet-600' : 'border-zinc-700 bg-zinc-800 hover:border-violet-500')}>
                {showInput ? '💬' : '⌨️'}
              </button>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

function StatusPill({ conn, interaction, speaking, waitingForAnswer }: { conn: Connection; interaction: InteractionStatus; speaking: boolean; waitingForAnswer: boolean }) {
  const active = conn === 'ready';
  const label = conn === 'connecting' ? 'Connexion…' : conn === 'error' ? 'Erreur'
    : !active ? 'Déconnecté' : waitingForAnswer ? 'Attend ta réponse' : speaking ? 'Parle' : interaction === 'IN_PROGRESS' ? 'Réfléchit' : 'Prêt';
  return <span className="flex items-center gap-2 rounded-full border border-zinc-800 bg-zinc-900 px-3 py-1 text-xs text-zinc-300">
    <span className={cn('size-2 rounded-full', conn === 'error' ? 'bg-rose-500' : !active ? 'bg-zinc-500' : waitingForAnswer ? 'bg-amber-400' : speaking ? 'animate-pulse bg-sky-400' : 'bg-emerald-400')} />
    {label}
  </span>;
}
function SparkIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M12 2c.6 4.9 4.1 8.4 10 10-5.9 1.6-9.4 5.1-10 10-.6-4.9-4.1-8.4-10-10 5.9-1.6 9.4-5.1 10-10z" /></svg>;
}
function SpeakerIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 5 6 9H2v6h4l5 4z" /><path d="M15.5 8.5a5 5 0 0 1 0 7" /><path d="M19 5a9 9 0 0 1 0 14" /></svg>;
}
function MuteIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 5 6 9H2v6h4l5 4z" /><path d="m23 9-6 6" /><path d="m17 9 6 6" /></svg>;
}
function MicIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="2" width="6" height="12" rx="3" /><path d="M5 10a7 7 0 0 0 14 0" /><path d="M12 17v5" /></svg>;
}
function SendIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 2 11 13" /><path d="M22 2 15 22l-4-9-9-4z" /></svg>;
}
function CheckIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="m20 6-11 11-5-5" /></svg>;
}
function CrossIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18M6 6l12 12" /></svg>;
}
