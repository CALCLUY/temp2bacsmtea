import { memo, useEffect, useMemo, useRef, type ReactNode } from 'react';
import { containsArabic, type BoardAnnotation, type BoardDrawingItem } from '../lib/interaction';
import { chalkWritingMs } from '../lib/chalkTiming';
import { renderMath, tokenizeMath } from './MathText';
import BoardAnnotations from './BoardAnnotations';
import { cn } from '../utils/cn';

export interface BoardLine {
  id: string;
  text: string;
  kind?: 'title' | 'text' | 'qcm-question' | 'qcm-option';
  qcmId?: string;
  optionIndex?: number;
  delayMs?: number;
}

export interface BoardMark extends BoardAnnotation {
  id: string;
}

interface BlackboardProps {
  lines: BoardLine[];
  annotations: BoardMark[];
  drawings: BoardDrawingItem[];
  activeQcmId?: string;
  selectedAnswer: number | null;
  canAnswer: boolean;
  onAnswer: (index: number) => void;
  wiping?: boolean;
  className?: string;
}

function escapeHtml(text: string): string {
  return text.replace(/[&<>"']/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[char] ?? char);
}

/** Sample JSON may supply either $...$ or a bare LaTeX expression. */
function readyForMath(line: string): string {
  const text = line.trim().replace(/^#{1,5}\s+/, '').replace(/\*\*/g, '');
  if (/\$|\\\(|\\\[/.test(text)) return text;
  if (/^(?:\\(?:lim|frac|sqrt|int|sum|prod|sin|cos|tan|ln|exp|vec|overrightarrow|mathbb|begin)|[a-zA-Z]\s*(?:\(|_\{|\^\{|\s*=))/.test(text) &&
      (/[=^_{}]|\\/.test(text))) return `$${text}$`;
  return text;
}

const ChalkLine = memo(function ChalkLine({ line, activeQcmId, selectedAnswer, canAnswer, onAnswer }: {
  line: BoardLine;
  activeQcmId?: string;
  selectedAnswer: number | null;
  canAnswer: boolean;
  onAnswer: (index: number) => void;
}) {
  const isOption = line.kind === 'qcm-option' && line.optionIndex !== undefined;
  // Defensive visual guard: all displayed lettering must be academic French/LaTeX.
  if (containsArabic(line.text)) return null;
  const text = useMemo(() => readyForMath(isOption ? line.text.replace(/^[A-D]\.\s*/, '') : line.text), [isOption, line.text]);
  const tokens = useMemo(() => tokenizeMath(text), [text]);
  const hasMath = tokens.some((token) => token.t === 'math');
  const active = isOption && line.qcmId === activeQcmId;
  const selected = active && selectedAnswer === line.optionIndex;
  const enabled = active && canAnswer && selectedAnswer === null;
  const delay = line.delayMs ?? 0;
  const classes = cn(
    'bb-line',
    line.kind === 'title' && 'bb-line-title',
    line.kind === 'qcm-question' && 'bb-qcm-question',
    isOption && 'bb-option',
    selected && 'bb-option-selected',
  );

  let content: ReactNode;
  if (hasMath) {
    const html = tokens.map((token) => token.t === 'math'
      ? renderMath(token.v, token.d) : escapeHtml(token.v)).join('');
    const steps = Math.max(12, Math.min(100, [...text].length));
    content = <span
      data-board-content
      className="bb-math-writing"
      style={{ animationDelay: `${delay}ms`, animationDuration: `${chalkWritingMs(text)}ms`, ['--chalk-steps' as string]: String(steps) }}
      dangerouslySetInnerHTML={{ __html: html }}
    />;
  } else {
    const letters = [...text];
    const interval = Math.max(14, Math.min(31, Math.floor(1600 / Math.max(letters.length, 1))));
    content = <span data-board-content>
      {letters.map((letter, i) => <span
        key={i}
        className="bb-letter"
        style={{ animationDelay: `${delay + i * interval}ms` }}
      >{letter === ' ' ? '\u00a0' : letter}</span>)}
    </span>;
  }

  if (isOption) return <button
    type="button"
    className={classes}
    dir="ltr"
    lang="fr"
    data-board-line={line.id}
    data-board-raw={line.text}
    aria-label={`Choisir ${line.text}`}
    aria-pressed={selected}
    disabled={!enabled}
    onClick={() => onAnswer(line.optionIndex!)}
  >
    <span className="bb-option-letter" aria-hidden="true">{String.fromCharCode(65 + line.optionIndex!)}.</span>
    <bdi dir="auto" className="bb-option-body">{content}</bdi>
  </button>;

  return <div className={classes} dir="ltr" lang="fr" data-board-line={line.id} data-board-raw={line.text}>{content}</div>;
});

/** Clean 2:1 slate: the chalk options themselves are keyboard and pointer accessible. */
function Blackboard({ lines, annotations, drawings, activeQcmId, selectedAnswer, canAnswer, onAnswer, wiping = false, className }: BlackboardProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLDivElement>(null);
  const previousCount = useRef(0);

  useEffect(() => {
    const surface = scrollRef.current;
    if (!surface) return;
    const wasCleared = lines.length < previousCount.current;
    previousCount.current = lines.length;
    if (wasCleared) surface.scrollTop = 0;
    else if (lines.length > 0 && (lines.length < 16 || lines.at(-1)?.kind?.startsWith('qcm-'))) {
      // A new question must be visible even after a long exercise or chapter.
      surface.scrollTop = surface.scrollHeight;
    }
  }, [lines]);

  useEffect(() => {
    if (activeQcmId && canAnswer) {
      scrollRef.current?.querySelector<HTMLButtonElement>('.bb-option:not(:disabled)')?.focus({ preventScroll: true });
    }
  }, [activeQcmId, canAnswer]);

  return <div className={cn('bb-surface', wiping && 'bb-wiping', className)} aria-label="Tableau virtuel" role="region">
    <div className="bb-dust" aria-hidden="true" />
    <div className="bb-writing" ref={scrollRef}>
      <div className="bb-canvas-content" ref={canvasRef}>
        <div className="bb-lines">
          {lines.map((line) => <ChalkLine
            key={line.id}
            line={line}
            activeQcmId={activeQcmId}
            selectedAnswer={selectedAnswer}
            canAnswer={canAnswer}
            onAnswer={onAnswer}
          />)}
        </div>
        <BoardAnnotations marks={annotations} drawings={drawings} lines={lines} canvasRef={canvasRef} />
      </div>
    </div>
    {wiping && <div className="bb-eraser-sweep" aria-hidden="true" />}
  </div>;
}

export default memo(Blackboard);