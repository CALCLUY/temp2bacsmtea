import { useCallback, useLayoutEffect, useState, type RefObject } from 'react';
import type { BoardLine, BoardMark } from './Blackboard';
import type { BoardDrawingItem, BoardDrawElement, BoardPoint } from '../lib/interaction';
import MathText from './MathText';

interface ChalkPath {
  id: string;
  type: BoardMark['type'] | BoardDrawElement['type'];
  d: string;
  arrowhead?: string;
  label?: string;
  labelX?: number;
  labelY?: number;
}

function segmentIndex(text: string, target: string): number {
  const haystack = text.toLocaleLowerCase();
  const needle = target.toLocaleLowerCase();
  let index = haystack.indexOf(needle);
  const shortVariable = [...needle].length <= 2 && /^[\p{L}\p{N}]+$/u.test(needle);
  while (index >= 0) {
    const before = haystack[index - 1] ?? '';
    const after = haystack[index + needle.length] ?? '';
    if (!shortVariable || (!/[\p{L}\p{N}]/u.test(before) && !/[\p{L}\p{N}]/u.test(after))) return index;
    index = haystack.indexOf(needle, index + 1);
  }
  return -1;
}

function visibleTextRect(element: HTMLElement, target: string): DOMRect | null {
  const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      const parent = node.parentElement;
      return parent?.closest('.katex-mathml') || !node.textContent
        ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT;
    },
  });
  const nodes: Array<{ node: Text; start: number; end: number }> = [];
  let text = '';
  while (walker.nextNode()) {
    const node = walker.currentNode as Text;
    const start = text.length;
    text += node.data.replace(/\u00a0/g, ' ');
    nodes.push({ node, start, end: text.length });
  }
  const index = segmentIndex(text, target);
  if (index < 0) return null;
  const start = nodes.find((n) => n.end > index);
  const end = nodes.find((n) => n.end >= index + target.length);
  if (!start || !end) return null;
  const range = document.createRange();
  range.setStart(start.node, index - start.start);
  range.setEnd(end.node, index + target.length - end.start);
  const rect = range.getBoundingClientRect();
  return rect.width > 0 ? rect : null;
}

function targetRect(canvas: HTMLDivElement, target: string): DOMRect | null {
  const segments = Array.from(canvas.querySelectorAll<HTMLElement>('[data-board-line]')).reverse();
  const normalized = target.trim().replace(/^\$+|\$+$/g, '').toLocaleLowerCase();
  for (const segment of segments) {
    const raw = segment.dataset.boardRaw ?? '';
    const rendered = segment.textContent ?? '';
    if (segmentIndex(raw, normalized) < 0 && segmentIndex(rendered, normalized) < 0) continue;
    const content = segment.querySelector<HTMLElement>('[data-board-content]') ?? segment;
    // A LaTeX source fragment may differ from rendered KaTeX; in that case
    // target the displayed equation rather than an invisible MathML node.
    return visibleTextRect(content, target) ?? content.getBoundingClientRect();
  }
  return null;
}

function buildPath(mark: BoardMark, canvas: HTMLDivElement): ChalkPath | null {
  const bounds = canvas.getBoundingClientRect();
  const w = canvas.clientWidth;
  const h = canvas.clientHeight;
  if (!w || !h) return null;
  const rect = mark.target ? targetRect(canvas, mark.target) : null;
  if (mark.target && !rect && !(mark.from && mark.to)) return null;

  const point = (p: [number, number]) => ({ x: p[0] * w / 100, y: p[1] * h / 100 });
  const anchor = rect && {
    left: rect.left - bounds.left,
    right: rect.right - bounds.left,
    top: rect.top - bounds.top,
    bottom: rect.bottom - bounds.top,
  };

  if (mark.type === 'underline') {
    const a = mark.from && mark.to ? point(mark.from) : { x: anchor?.left ?? 0, y: (anchor?.bottom ?? 0) + 2 };
    const b = mark.from && mark.to ? point(mark.to) : { x: anchor?.right ?? 0, y: (anchor?.bottom ?? 0) + 2 };
    const span = Math.max(12, b.x - a.x);
    return {
      id: mark.id,
      type: mark.type,
      d: `M ${a.x} ${a.y} Q ${a.x + span * .25} ${a.y - 2} ${a.x + span * .5} ${a.y + 1} T ${b.x} ${b.y}`,
    };
  }

  const from = mark.from && mark.to
    ? point(mark.from)
    : { x: Math.max(9, (anchor?.left ?? 46) - 36), y: Math.max(14, (anchor?.top ?? 46) - 18) };
  const to = mark.from && mark.to
    ? point(mark.to)
    : { x: (anchor!.left + anchor!.right) / 2, y: anchor!.top + 6 };
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const control = { x: (from.x + to.x) / 2, y: (from.y + to.y) / 2 - Math.max(16, Math.abs(dx) * .25) };
  const curved = mark.type === 'curved_arrow';
  const tangentX = curved ? to.x - control.x : dx;
  const tangentY = curved ? to.y - control.y : dy;
  const angle = Math.atan2(tangentY, tangentX);
  const length = 12;
  const wing = .54;
  const tip1 = { x: to.x - Math.cos(angle - wing) * length, y: to.y - Math.sin(angle - wing) * length };
  const tip2 = { x: to.x - Math.cos(angle + wing) * length, y: to.y - Math.sin(angle + wing) * length };
  return {
    id: mark.id,
    type: mark.type,
    d: curved
      ? `M ${from.x} ${from.y} Q ${control.x} ${control.y} ${to.x} ${to.y}`
      : `M ${from.x} ${from.y} L ${to.x} ${to.y}`,
    arrowhead: `M ${tip1.x} ${tip1.y} L ${to.x} ${to.y} L ${tip2.x} ${tip2.y}`,
  };
}

function percentPoint([x, y]: BoardPoint, width: number, height: number) {
  return { x: x * width / 100, y: y * height / 100 };
}

function arrowHead(from: { x: number; y: number }, to: { x: number; y: number }): string {
  const angle = Math.atan2(to.y - from.y, to.x - from.x);
  const length = 11;
  const wing = .55;
  const p1 = { x: to.x - Math.cos(angle - wing) * length, y: to.y - Math.sin(angle - wing) * length };
  const p2 = { x: to.x - Math.cos(angle + wing) * length, y: to.y - Math.sin(angle + wing) * length };
  return `M ${p1.x} ${p1.y} L ${to.x} ${to.y} L ${p2.x} ${p2.y}`;
}

function smoothCurve(points: BoardPoint[], width: number, height: number): string {
  const p = points.map((point) => percentPoint(point, width, height));
  if (p.length < 2) return '';
  let d = `M ${p[0].x} ${p[0].y}`;
  for (let i = 0; i < p.length - 1; i++) {
    const p0 = p[Math.max(0, i - 1)];
    const p1 = p[i];
    const p2 = p[i + 1];
    const p3 = p[Math.min(p.length - 1, i + 2)];
    const c1 = { x: p1.x + (p2.x - p0.x) / 6, y: p1.y + (p2.y - p0.y) / 6 };
    const c2 = { x: p2.x - (p3.x - p1.x) / 6, y: p2.y - (p3.y - p1.y) / 6 };
    d += ` C ${c1.x} ${c1.y}, ${c2.x} ${c2.y}, ${p2.x} ${p2.y}`;
  }
  return d;
}

function buildDrawing(element: BoardDrawElement, id: string, canvas: HTMLDivElement): ChalkPath | null {
  const width = canvas.clientWidth;
  const height = canvas.clientHeight;
  if (!width || !height) return null;
  if (element.type === 'underline') {
    return buildPath({ id, type: 'underline', target: element.target }, canvas);
  }
  if (element.type === 'line') {
    const a = percentPoint([element.x1, element.y1], width, height);
    const b = percentPoint([element.x2, element.y2], width, height);
    return { id, type: 'line', d: `M ${a.x} ${a.y} L ${b.x} ${b.y}` };
  }
  if (element.type === 'circle') {
    const c = percentPoint([element.cx, element.cy], width, height);
    const radius = element.r * Math.min(width, height) / 100;
    const x = c.x - radius;
    return { id, type: 'circle', d: `M ${x} ${c.y} a ${radius} ${radius} 0 1 0 ${radius * 2} 0 a ${radius} ${radius} 0 1 0 ${-radius * 2} 0` };
  }
  if (element.type === 'curve') {
    return { id, type: 'curve', d: smoothCurve(element.points, width, height) };
  }
  const from = percentPoint(element.from, width, height);
  const to = percentPoint(element.to, width, height);
  return {
    id,
    type: 'arrow',
    d: `M ${from.x} ${from.y} L ${to.x} ${to.y}`,
    arrowhead: arrowHead(from, to),
    label: element.label,
    labelX: (from.x + to.x) / 2 + 6,
    labelY: (from.y + to.y) / 2 - 20,
  };
}

/** SVG overlay inside the scrollable writing surface; follows its text. */
export default function BoardAnnotations({ marks, drawings, lines, canvasRef }: {
  marks: BoardMark[];
  drawings: BoardDrawingItem[];
  lines: BoardLine[];
  canvasRef: RefObject<HTMLDivElement | null>;
}) {
  const [size, setSize] = useState({ w: 1, h: 1 });
  const [paths, setPaths] = useState<ChalkPath[]>([]);

  const measure = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setSize({ w: canvas.clientWidth || 1, h: canvas.clientHeight || 1 });
    setPaths([
      ...marks.flatMap((m) => {
      const path = buildPath(m, canvas);
      return path ? [path] : [];
      }),
      ...drawings.flatMap((item) => {
        const path = buildDrawing(item.element, item.id, canvas);
        return path ? [path] : [];
      }),
    ]);
  }, [canvasRef, drawings, marks]);

  useLayoutEffect(() => {
    measure();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const observer = new ResizeObserver(measure);
    observer.observe(canvas);
    const text = canvas.querySelector('.bb-lines');
    if (text) observer.observe(text);
    void document.fonts?.ready.then(measure);
    return () => observer.disconnect();
  }, [canvasRef, lines, measure]);

  return (
    <svg className="bb-annotation-layer" viewBox={`0 0 ${size.w} ${size.h}`} preserveAspectRatio="none" aria-hidden="true">
      <defs>
        {/* Small dry-chalk edge irregularity; deliberately no luminous/glow filter. */}
        <filter id="chalk-stroke-grain" x="-4%" y="-10%" width="108%" height="120%">
          <feTurbulence type="fractalNoise" baseFrequency=".8" numOctaves="1" seed="11" result="chalkNoise" />
          <feDisplacementMap in="SourceGraphic" in2="chalkNoise" scale=".65" xChannelSelector="R" yChannelSelector="G" />
        </filter>
      </defs>
      {paths.map((path) => (
        <g key={path.id}>
          <path className="bb-annotation-stroke" pathLength="1" d={path.d} />
          {path.arrowhead && <path className="bb-annotation-head" d={path.arrowhead} />}
          {path.label && path.labelX !== undefined && path.labelY !== undefined && <foreignObject
            className="bb-drawing-label-box"
            x={path.labelX}
            y={path.labelY}
            width="150"
            height="44"
          >
            <div className="bb-drawing-label" dir="ltr">
              <MathText text={path.label} inline dir="ltr" />
            </div>
          </foreignObject>}
        </g>
      ))}
    </svg>
  );
}