/**
 * On-demand Examen National retrieval for ./2bac-data-sma/{subject}/examens-nationaux/.
 *
 *  parseExamRequest()  "أستاذ، خدم معايا التمرين الثاني ديال Nombres Complexes فـ Examen National 2018 Session Normale"
 *                      → { year: 2018, session: 'normale', exercise: 2, topicKey: '06' }
 *  retrieveExam()      fetches {année}-{session}-sujet.txt + -corrige.txt, splits them by exercise,
 *                      detects each exercise topic and resolves the requested one.
 *  buildExamContextText() / examToolResponse()
 *                      grounded block given to Gemini (tool response or injected message).
 */
import { isSubjectId, SUBJECT_PROFILES, type SubjectId } from './dataset';
import { findChapter, matchChapterByAlias, normalizeForMatch, scoreChapters, type ChapterDef } from './curriculum';
import { fetchDataFile, loadRepoIndex, mapLimit, parseFrontMatter } from './dataRepo';

export type ExamSession = 'normale' | 'rattrapage';

export const SESSION_LABEL: Record<ExamSession, string> = {
  normale: 'Session Normale',
  rattrapage: 'Session de Rattrapage',
};

export const SESSION_LABEL_AR: Record<ExamSession, string> = {
  normale: 'الدورة العادية',
  rattrapage: 'الدورة الاستدراكية',
};

export interface ExamRequest {
  subject: SubjectId;
  year: number;
  session: ExamSession;
  sessionExplicit: boolean;
  exercise?: number;
  topicKey?: string;
  topicText?: string;
  wantsProblem?: boolean;
}

export interface ExerciseTopic {
  key: string;
  label: string;
  score: number;
}

export interface ExamExercise {
  number: number;
  heading: string;
  points?: string;
  body: string;
  topics: ExerciseTopic[];
}

export type CorrectionKind = 'detailed' | 'bareme' | 'unknown' | 'none';

export interface ExamRetrieval {
  ok: boolean;
  request: ExamRequest;
  subjectLabel: string;
  sessionLabel: string;
  sessionLabelAr: string;
  sujetPath?: string;
  corrigePath?: string;
  preamble: string;
  exercises: ExamExercise[];
  selected?: ExamExercise;
  correction?: string;
  correctionScope: 'exercise' | 'full' | 'none';
  correctionKind: CorrectionKind;
  notes: string[];
  error?: string;
  availableYears: number[];
  availableSessions: ExamSession[];
}

export interface ExamFileRef {
  year: number;
  session: ExamSession;
  kind: 'sujet' | 'corrige';
  path: string;
}

export interface ExamAvailability {
  year: number;
  sessions: Partial<Record<ExamSession, { sujet?: string; corrige?: string }>>;
}

export interface RelatedExam {
  year: number;
  session: ExamSession;
  exercise: number;
  heading: string;
  path: string;
  score: number;
}

/* ------------------------------------------------------------------ */
/* Static fallback for mathematics (from RAPPORT.md of the dataset)    */
/* ------------------------------------------------------------------ */
type Kinds = Array<'sujet' | 'corrige'>;
const FULL: Partial<Record<ExamSession, Kinds>> = { normale: ['sujet', 'corrige'], rattrapage: ['sujet', 'corrige'] };
const MATH_STATIC: Record<number, Partial<Record<ExamSession, Kinds>>> = {
  2010: FULL, 2011: FULL, 2012: FULL, 2013: FULL,
  2014: { normale: ['sujet'] },
  2015: FULL, 2016: FULL, 2017: FULL, 2018: FULL,
  2020: FULL,
  2022: FULL, 2023: FULL, 2024: FULL,
  2025: { normale: ['sujet'] },
};
const MATH_DETAILED_CORRECTIONS = new Set(['2018-normale', '2024-normale']);
const MATH_MISSING_REASON: Record<number, string> = {
  2019: 'les PDF officiels de 2019 sont des scans sans couche texte (non extraits dans le dataset)',
  2021: 'les PDF officiels de 2021 sont des scans sans couche texte (non extraits dans le dataset)',
};

/* ------------------------------------------------------------------ */
/* File discovery                                                      */
/* ------------------------------------------------------------------ */
function sessionFromName(name: string): ExamSession | null {
  const n = name.toLowerCase();
  if (/rattrapage|controle|contr[oô]le/.test(n)) return 'rattrapage';
  if (/normale?/.test(n)) return 'normale';
  return null;
}

function kindFromName(name: string): 'sujet' | 'corrige' | null {
  const n = name.toLowerCase();
  if (/corrig/.test(n)) return 'corrige';
  if (/sujet|enonce|énoncé/.test(n)) return 'sujet';
  return null;
}

export async function listExamFiles(subject: SubjectId): Promise<ExamFileRef[]> {
  const dir = `${SUBJECT_PROFILES[subject].dir}/examens-nationaux/`;
  const index = await loadRepoIndex();
  if (index) {
    const out: ExamFileRef[] = [];
    for (const p of index) {
      if (!p.startsWith(dir)) continue;
      const m = /^(\d{4})\/([^/]+\.txt)$/.exec(p.slice(dir.length));
      if (!m) continue;
      const session = sessionFromName(m[2]);
      const kind = kindFromName(m[2]);
      if (session && kind) out.push({ year: Number(m[1]), session, kind, path: p });
    }
    return out;
  }
  if (subject !== 'mathematiques') return [];
  const out: ExamFileRef[] = [];
  for (const [y, sessions] of Object.entries(MATH_STATIC)) {
    for (const [s, kinds] of Object.entries(sessions) as Array<[ExamSession, Kinds]>) {
      for (const kind of kinds) out.push({ year: Number(y), session: s, kind, path: `${dir}${y}/${y}-${s}-${kind}.txt` });
    }
  }
  return out;
}

export async function examAvailability(subject: SubjectId): Promise<ExamAvailability[]> {
  const files = await listExamFiles(subject);
  const byYear = new Map<number, ExamAvailability>();
  for (const f of files) {
    const entry = byYear.get(f.year) ?? { year: f.year, sessions: {} };
    const slot = entry.sessions[f.session] ?? {};
    slot[f.kind] = f.path;
    entry.sessions[f.session] = slot;
    byYear.set(f.year, entry);
  }
  return [...byYear.values()].sort((a, b) => a.year - b.year);
}

/* ------------------------------------------------------------------ */
/* Splitting a sujet / corrigé into exercises                          */
/* ------------------------------------------------------------------ */
interface Heading {
  start: number;
  number: number | null;
  isProblem: boolean;
  line: string;
}

const HEAD_RE = /^(?:corrig[ée]s?\s+(?:de\s+)?(?:l['’]\s*)?)?(exercice|exercise|probl[èe]me)\s*(?:n\s*[°o]\s*|num[ée]ro\s*)?(\d+)?/i;

function findHeadings(text: string): Heading[] {
  const heads: Heading[] = [];
  let pos = 0;
  for (const rawLine of text.split('\n')) {
    const start = pos;
    pos += rawLine.length + 1;
    const line = rawLine.trim();
    if (!line || line.length > 110) continue;
    const marked = /^(?:#{1,6}\s|\*\*)/.test(line);
    const clean = line.replace(/^#{1,6}\s*/, '').replace(/\*\*/g, '').replace(/^[-–—•\s]+/, '').trim();
    const m = HEAD_RE.exec(clean);
    if (!m) continue;
    const titleLike = clean === clean.toUpperCase() || /^(?:exercice|probl[èe]me)\s*\d*\s*(?:[:.(\-–]|$)/i.test(clean);
    if (!marked && !titleLike) continue;
    heads.push({ start, number: m[2] ? Number(m[2]) : null, isProblem: /^probl/i.test(m[1]), line: clean });
  }
  return heads;
}

export function splitExercises(text: string): { preamble: string; exercises: Array<Omit<ExamExercise, 'topics'>> } {
  const heads = findHeadings(text);
  const accepted: Array<Heading & { number: number }> = [];
  let last = 0;
  for (const h of heads) {
    const n = h.number ?? last + 1;
    if (n <= last) continue; // repeated heading or restart → stays inside the current section
    accepted.push({ ...h, number: n });
    last = n;
  }
  if (!accepted.length) return { preamble: text.trim(), exercises: [] };
  const exercises = accepted.map((h, i) => {
    const end = i + 1 < accepted.length ? accepted[i + 1].start : text.length;
    const pts = /(\d+(?:[.,]\d+)?)\s*(?:points?|pts?)\b/i.exec(h.line);
    return {
      number: h.number,
      heading: h.line.replace(/\s*:\s*$/, ''),
      points: pts ? `${pts[1]} points` : undefined,
      body: text.slice(h.start, end).trim(),
    };
  });
  return { preamble: text.slice(0, accepted[0].start).trim(), exercises };
}

function classify(subject: SubjectId, body: string): ExerciseTopic[] {
  return scoreChapters(subject, body)
    .slice(0, 3)
    .map(({ chapter, score }) => ({ key: chapter.key, label: chapter.title, score: Math.round(score * 10) / 10 }));
}

function pointsOf(e: ExamExercise): number {
  return e.points ? Number(e.points.replace(',', '.').replace(/[^\d.]/g, '')) || 0 : 0;
}

/* ------------------------------------------------------------------ */
/* Request parsing (Darija / Arabic / French)                          */
/* ------------------------------------------------------------------ */
const NUM_WORDS: Record<string, number> = {
  un: 1, une: 1, premier: 1, premiere: 1,
  deux: 2, deuxieme: 2, second: 2, seconde: 2,
  trois: 3, troisieme: 3,
  quatre: 4, quatrieme: 4,
  cinq: 5, cinquieme: 5,
  six: 6, sixieme: 6,
  'الاول': 1, 'اللول': 1, 'لول': 1, 'اول': 1, 'الاولي': 1, 'واحد': 1,
  'الثاني': 2, 'التاني': 2, 'ثاني': 2, 'تاني': 2, 'الثانيه': 2, 'التانيه': 2, 'جوج': 2, 'زوج': 2, 'اثنين': 2,
  'الثالث': 3, 'التالت': 3, 'ثالث': 3, 'تالت': 3, 'الثالثه': 3, 'تلاته': 3, 'ثلاثه': 3,
  'الرابع': 4, 'رابع': 4, 'الرابعه': 4, 'ربعه': 4, 'اربعه': 4,
  'الخامس': 5, 'خامس': 5, 'الخامسه': 5, 'خمسه': 5,
  'السادس': 6, 'سادس': 6, 'سته': 6,
};

const EXERCISE_WORDS = new Set(['exercice', 'exercices', 'exo', 'exos', 'ex', 'exercise', 'تمرين', 'التمرين', 'لتمرين', 'فالتمرين', 'تمارين', 'التمارين']);
const FILLER_WORDS = new Set(['رقم', 'n', 'no', 'numero', 'num', 'nr', 'ديال', 'dyal', 'de', 'du', 'le', 'la']);
const EXAM_INTENT = /examen|exam\b|national|وطني|امتحان|\bbac\b|باك|sujet|session|دوره|تمرين|exercice|\bexo\b|\bex\b/;

function numberFromToken(tok: string): number | undefined {
  if (/^\d{1,2}$/.test(tok)) {
    const n = Number(tok);
    return n >= 1 && n <= 12 ? n : undefined;
  }
  const m = /^(\d)(?:er|ere|re|eme|e|nd|nde)$/.exec(tok);
  if (m) return Number(m[1]);
  return NUM_WORDS[tok];
}

function parseExerciseNumber(tokens: string[]): number | undefined {
  for (let i = 0; i < tokens.length; i++) {
    const tok = tokens[i];
    const glued = /^(?:ex|exo|exercice|تمرين)(\d{1,2})$/.exec(tok);
    if (glued) return Number(glued[1]);
    if (!EXERCISE_WORDS.has(tok)) continue;
    for (let j = i + 1; j < Math.min(tokens.length, i + 4); j++) {
      const n = numberFromToken(tokens[j]);
      if (n) return n;
      if (!FILLER_WORDS.has(tokens[j])) break;
    }
    for (let j = i - 1; j >= Math.max(0, i - 2); j--) {
      if (/^\d+$/.test(tokens[j])) continue;
      const n = numberFromToken(tokens[j]);
      if (n) return n;
    }
  }
  return undefined;
}

function detectSubject(norm: string): SubjectId | undefined {
  if (/physique|chimie|فيزياء|الفيزياء|فيزيك|كيمياء|الكيمياء/.test(norm)) return 'physique-chimie';
  if (/\bsvt\b|علوم الحياه|الحياه والارض/.test(norm)) return 'svt';
  if (/\bmaths?\b|mathematiques|رياضيات|الرياضيات/.test(norm)) return 'mathematiques';
  return undefined;
}

/** Returns null when the text is not an Examen National request (needs a year + an exam/exercise word). */
export function parseExamRequest(text: string, currentSubject: SubjectId): ExamRequest | null {
  const norm = normalizeForMatch(text).replace(/n\s*[°º]\s*/g, ' ');
  const ym = /(?:^|\D)(20[0-3]\d)(?!\d)/.exec(norm);
  if (!ym) return null;
  const year = Number(ym[1]);
  if (year < 2008 || year > 2030 || !EXAM_INTENT.test(norm)) return null;

  const subject = detectSubject(norm) ?? currentSubject;
  const rattrapage = /rattrap|controle|استدراك|juillet/.test(norm);
  const normale = /normale?\b|عادي|juin|ordinaire/.test(norm);
  const tokens = norm.split(/[^\p{L}\p{N}]+/u).filter(Boolean);
  return {
    subject,
    year,
    session: rattrapage && !normale ? 'rattrapage' : 'normale',
    sessionExplicit: rattrapage || normale,
    exercise: parseExerciseNumber(tokens),
    topicKey: matchChapterByAlias(subject, norm)?.key,
    wantsProblem: /\bprobleme\b|المساله|مساله/.test(norm),
  };
}

/** Arguments of the get_examen_national tool → request. */
export function requestFromToolArgs(args: Record<string, unknown>, fallbackSubject: SubjectId): ExamRequest | null {
  const year = Number(args.year);
  if (!Number.isInteger(year) || year < 2000 || year > 2035) return null;
  const subject = isSubjectId(args.subject) ? args.subject : fallbackSubject;
  const sessionRaw = typeof args.session === 'string' ? normalizeForMatch(args.session) : '';
  const exercise = Number(args.exercise);
  const topicText = typeof args.topic === 'string' && args.topic.trim() ? args.topic.trim() : undefined;
  return {
    subject,
    year,
    session: /rattrap|control|استدراك/.test(sessionRaw) ? 'rattrapage' : 'normale',
    sessionExplicit: sessionRaw.length > 0,
    exercise: Number.isInteger(exercise) && exercise > 0 ? exercise : undefined,
    topicKey: topicText ? matchChapterByAlias(subject, topicText)?.key : undefined,
    topicText,
    wantsProblem: topicText ? /probl|مسال/.test(normalizeForMatch(topicText)) : false,
  };
}

/** Darija sentence used when the request comes from a button instead of the student's words. */
export function examRequestSentence(req: ExamRequest): string {
  const topic = req.topicKey ? findChapter(req.subject, req.topicKey)?.title : undefined;
  const what = req.exercise ? `التمرين ${req.exercise}` : topic ? `التمرين ديال ${topic}` : 'هاد الامتحان';
  return `أستاذ، خدم معايا ${what} فـ Examen National ${req.year} ${SESSION_LABEL_AR[req.session]} (${SUBJECT_PROFILES[req.subject].label}).`;
}

/* ------------------------------------------------------------------ */
/* Retrieval                                                           */
/* ------------------------------------------------------------------ */
function resolveSelection(exercises: ExamExercise[], req: ExamRequest, notes: string[]): ExamExercise | undefined {
  const byNumber = req.exercise ? exercises.find((e) => e.number === req.exercise) : undefined;
  if (req.exercise && !byNumber) notes.push(`Ce sujet contient ${exercises.length} exercice(s) : l'Exercice ${req.exercise} n'existe pas.`);

  if (req.topicKey) {
    const topicDef: ChapterDef | undefined = findChapter(req.subject, req.topicKey);
    const ranked = exercises
      .map((e) => ({ e, s: e.topics.find((t) => t.key === req.topicKey)?.score ?? 0 }))
      .filter((x) => x.s > 0)
      .sort((a, b) => b.s - a.s);
    const byTopic = ranked[0]?.e;
    if (!byTopic && topicDef) notes.push(`Aucun exercice de ce sujet n'est clairement consacré à « ${topicDef.title} ».`);
    if (byNumber && byTopic && byNumber !== byTopic) {
      const sNum = byNumber.topics.find((t) => t.key === req.topicKey)?.score ?? 0;
      if (sNum >= ranked[0].s * 0.5) return byNumber;
      notes.push(
        `L'Exercice ${byNumber.number} de ce sujet porte sur ${byNumber.topics[0]?.label ?? 'un autre thème'} ; l'exercice consacré à « ${topicDef?.title ?? req.topicKey} » est l'Exercice ${byTopic.number} — c'est lui qui est affiché (boutons ci-dessous pour changer).`,
      );
      return byTopic;
    }
    if (!byNumber && byTopic) return byTopic;
  }

  if (req.wantsProblem && !byNumber) {
    return exercises.find((e) => /probl/i.test(e.heading)) ?? [...exercises].sort((a, b) => pointsOf(b) - pointsOf(a))[0];
  }
  return byNumber;
}

export async function retrieveExam(req: ExamRequest): Promise<ExamRetrieval> {
  const subjectLabel = SUBJECT_PROFILES[req.subject].label;
  const base: ExamRetrieval = {
    ok: false,
    request: req,
    subjectLabel,
    sessionLabel: SESSION_LABEL[req.session],
    sessionLabelAr: SESSION_LABEL_AR[req.session],
    preamble: '',
    exercises: [],
    correctionScope: 'none',
    correctionKind: 'none',
    notes: [],
    availableYears: [],
    availableSessions: [],
  };

  const files = await listExamFiles(req.subject);
  base.availableYears = [...new Set(files.filter((f) => f.kind === 'sujet').map((f) => f.year))].sort((a, b) => a - b);
  const yearFiles = files.filter((f) => f.year === req.year);
  base.availableSessions = [...new Set(yearFiles.filter((f) => f.kind === 'sujet').map((f) => f.session))];

  let sujetPath = yearFiles.find((f) => f.kind === 'sujet' && f.session === req.session)?.path;
  let corrigePath = yearFiles.find((f) => f.kind === 'corrige' && f.session === req.session)?.path;
  if (!sujetPath && files.length === 0) {
    // No index for this subject: try the canonical file names directly.
    const stem = `${SUBJECT_PROFILES[req.subject].dir}/examens-nationaux/${req.year}/${req.year}-${req.session}`;
    sujetPath = `${stem}-sujet.txt`;
    corrigePath = `${stem}-corrige.txt`;
  }

  if (!sujetPath) {
    const reason = req.subject === 'mathematiques' ? MATH_MISSING_REASON[req.year] : undefined;
    base.error = !base.availableYears.includes(req.year)
      ? `L'Examen National ${req.year} (${subjectLabel}) n'est pas disponible dans le dataset${reason ? ` : ${reason}` : ''}.`
      : `La ${SESSION_LABEL[req.session]} ${req.year} n'est pas disponible dans le dataset. Session(s) disponible(s) en ${req.year} : ${
          base.availableSessions.map((s) => SESSION_LABEL[s]).join(', ') || 'aucune'
        }.`;
    return base;
  }

  let sujetRaw: string;
  try {
    sujetRaw = await fetchDataFile(sujetPath);
  } catch (err) {
    base.error = `Sujet introuvable : ${sujetPath} (${err instanceof Error ? err.message : String(err)}).`;
    return base;
  }

  const split = splitExercises(parseFrontMatter(sujetRaw).body);
  const exercises: ExamExercise[] = split.exercises.map((ex) => ({ ...ex, topics: classify(req.subject, ex.body) }));
  const notes: string[] = [];
  if (!req.sessionExplicit) notes.push('Session non précisée : la Session Normale est utilisée par défaut.');
  if (!exercises.length) notes.push("Le découpage automatique en exercices n'a pas été possible : le sujet complet est affiché.");
  const selected = exercises.length ? resolveSelection(exercises, req, notes) : undefined;

  let correction: string | undefined;
  let correctionScope: ExamRetrieval['correctionScope'] = 'none';
  let correctionKind: CorrectionKind = 'none';
  if (corrigePath) {
    try {
      const corr = parseFrontMatter(await fetchDataFile(corrigePath)).body;
      const section = selected ? splitExercises(corr).exercises.find((e) => e.number === selected.number)?.body : undefined;
      correction = section ?? corr.trim();
      correctionScope = section ? 'exercise' : 'full';
      correctionKind =
        req.subject === 'mathematiques' ? (MATH_DETAILED_CORRECTIONS.has(`${req.year}-${req.session}`) ? 'detailed' : 'bareme') : 'unknown';
    } catch {
      corrigePath = undefined;
    }
  }
  if (!corrigePath) notes.push("Aucun corrigé officiel n'est disponible dans le dataset pour cette session.");

  return {
    ...base,
    ok: true,
    sujetPath,
    corrigePath,
    preamble: split.preamble,
    exercises,
    selected,
    correction,
    correctionScope,
    correctionKind,
    notes,
  };
}

/* ------------------------------------------------------------------ */
/* Exam index → related exercises for a chapter                        */
/* ------------------------------------------------------------------ */
interface IndexedExercise {
  year: number;
  session: ExamSession;
  path: string;
  number: number;
  heading: string;
  body: string;
}

const examIndexCache = new Map<SubjectId, Promise<IndexedExercise[]>>();

export function buildExamIndex(subject: SubjectId): Promise<IndexedExercise[]> {
  const hit = examIndexCache.get(subject);
  if (hit) return hit;
  const p = (async () => {
    const sujets = (await listExamFiles(subject)).filter((f) => f.kind === 'sujet');
    const rows = await mapLimit(sujets, 6, async (f) => {
      try {
        const body = parseFrontMatter(await fetchDataFile(f.path)).body;
        return splitExercises(body).exercises.map((ex) => ({
          year: f.year,
          session: f.session,
          path: f.path,
          number: ex.number,
          heading: ex.heading,
          body: ex.body,
        }));
      } catch {
        return [] as IndexedExercise[];
      }
    });
    return rows.flat();
  })();
  examIndexCache.set(subject, p);
  p.catch(() => examIndexCache.delete(subject));
  return p;
}

/** Real exam exercises whose main topic is this chapter (rank 0 first, then most recent). */
export async function findRelatedExams(subject: SubjectId, chapter: ChapterDef, limit = 8): Promise<RelatedExam[]> {
  if (!chapter.signals.length) return [];
  const index = await buildExamIndex(subject);
  const scored = index
    .map((ex) => {
      const ranking = scoreChapters(subject, ex.body);
      const rank = ranking.findIndex((r) => r.chapter.key === chapter.key);
      return { ex, rank, score: rank >= 0 ? ranking[rank].score : 0 };
    })
    .filter((x) => x.rank >= 0 && x.rank <= 1 && x.score >= 3)
    .sort((a, b) => a.rank - b.rank || b.ex.year - a.ex.year || a.ex.number - b.ex.number);
  return scored.slice(0, limit).map(({ ex, score }) => ({
    year: ex.year,
    session: ex.session,
    exercise: ex.number,
    heading: ex.heading,
    path: ex.path,
    score: Math.round(score * 10) / 10,
  }));
}

export async function listExamsForTool(subject: SubjectId, topicText?: string): Promise<Record<string, unknown>> {
  const avail = await examAvailability(subject);
  const result: Record<string, unknown> = {
    subject,
    available: avail.map((a) => ({ year: a.year, sessions: Object.keys(a.sessions) })),
  };
  if (subject === 'mathematiques') {
    result.missing_years = Object.entries(MATH_MISSING_REASON).map(([y, reason]) => ({ year: Number(y), reason }));
  }
  if (topicText) {
    const def = matchChapterByAlias(subject, topicText);
    if (def) {
      result.topic = def.title;
      result.matching_exercises = (await findRelatedExams(subject, def, 12)).map((r) => ({
        year: r.year,
        session: r.session,
        exercise: r.exercise,
        heading: r.heading,
      }));
    } else {
      result.topic_not_recognized = topicText;
    }
  }
  return result;
}

/* ------------------------------------------------------------------ */
/* Grounded text for Gemini                                            */
/* ------------------------------------------------------------------ */
const TEXT_LIMIT = 9000;
const clip = (s: string, n = TEXT_LIMIT) => (s.length > n ? `${s.slice(0, n)}\n[… tronqué …]` : s);

export function statementOf(r: ExamRetrieval): string {
  if (r.selected) return r.selected.body;
  if (r.exercises.length) {
    return r.exercises
      .map((e) => `- Exercice ${e.number}${e.points ? ` (${e.points})` : ''} — ${e.topics[0]?.label ?? e.heading}`)
      .join('\n');
  }
  return r.preamble;
}

function correctionKindLabel(k: CorrectionKind): string {
  switch (k) {
    case 'detailed':
      return 'solution officielle détaillée';
    case 'bareme':
      return 'barème / éléments de réponse (pas une solution rédigée)';
    case 'unknown':
      return 'corrigé officiel (nature non vérifiée)';
    default:
      return 'aucun corrigé officiel';
  }
}

function protocolLines(r: ExamRetrieval): string[] {
  const n = r.selected?.number;
  const topic = r.selected?.topics[0]?.label;
  const ack = n
    ? `مزيان! غادي نجبدو التمرين ${n}${topic ? ` ديال ${topic}` : ''} من امتحان ${r.request.year} ${r.sessionLabelAr}...`
    : `مزيان! جبدنا امتحان ${r.request.year} ${r.sessionLabelAr}...`;
  return [
    `1. Acknowledge the exact exam in Darija first, e.g. "${ack}"${r.notes.some((x) => x.startsWith("L'Exercice")) ? ' and explain the exercise-number/topic mismatch described in the notes.' : ''}`,
    "2. The official statement is ALREADY written on the 2:1 virtual BLACKBOARD (not a chat card), in formal French with LaTeX. Do not repeat or read all of it aloud: explain in Darija what the exercise is about, then read only the first question.",
    "2bis. TERMS FIRST (French-first law): say the official FRENCH term of the current question, ask «شنو هو …؟», then explain in plain Darija what it is with an everyday analogy. Never replace the term with an Arabic synonym. After speaking each short line, call blackboard_write_line and wait for animation_complete. Never dump a glossary.",
    n
      ? '3. Work ONLY on this exercise: one sub-question per turn. For each visual reasoning line: speak it, call blackboard_write_line, and wait for animation_complete before continuing. Never batch lines or emit chat text.'
      : '3. No exercise was specified: ask in Darija which numbered exercise to start; use ask_qcm for clickable choices written on the BLACKBOARD.',
    r.correctionKind === 'detailed' || r.correctionKind === 'unknown'
      ? '4. Use the official correction below as reference; follow it one step at a time without contradicting it.'
      : r.correctionKind === 'bareme'
        ? '4. The correction is only a barème: build the reasoning yourself, label it "solution proposée, conforme au barème officiel".'
        : '4. No official correction exists: label your reasoning "solution proposée (non officielle)".',
    '5. Mention barème points and examiner traps (domain, units, signs, justification, conclusion).',
    '6. All written steps belong ONLY on the board via synchronized blackboard_write_line calls; all explanations belong ONLY in Darija AUDIO. No visible assistant chat.',
  ];
}

/** Block injected into the Live session (client-side retrieval) — also used inside the tool response. */
export function buildExamContextText(r: ExamRetrieval): string {
  const head = "[EXAMEN NATIONAL — RÉCUPÉRÉ PAR L'APPLICATION DEPUIS LE DATASET CALCLUY/data-2bac-sma]";
  const ask = `${r.subjectLabel} · ${r.request.year} · ${r.sessionLabel}${r.request.exercise ? ` · Exercice ${r.request.exercise}` : ''}${
    r.request.topicKey ? ` · thème ${findChapter(r.request.subject, r.request.topicKey)?.title ?? r.request.topicKey}` : ''
  }`;
  if (!r.ok) {
    return [
      head,
      `Demande : ${ask}`,
      `RÉSULTAT : INTROUVABLE — ${r.error ?? ''}`,
      r.availableYears.length ? `Années disponibles (${r.subjectLabel}) : ${r.availableYears.join(', ')}` : '',
      r.availableSessions.length ? `Sessions disponibles en ${r.request.year} : ${r.availableSessions.map((s) => SESSION_LABEL[s]).join(', ')}` : '',
      '=== PROTOCOL ===',
      '1. Tell the student in Darija, kindly, that this exam is not in the dataset and why.',
      '2. Propose the available years/sessions (a QCM is welcome). Never invent the statement.',
    ]
      .filter(Boolean)
      .join('\n');
  }
  return [
    head,
    `Demande : ${ask}`,
    `Examen : Examen National ${r.request.year} — ${r.sessionLabel} — ${r.subjectLabel}`,
    `Source sujet : ${r.sujetPath}`,
    `Source corrigé : ${r.corrigePath ?? 'absent'} (${correctionKindLabel(r.correctionKind)})`,
    r.exercises.length
      ? `Exercices du sujet : ${r.exercises.map((e) => `Ex ${e.number}${e.topics[0] ? ` (${e.topics[0].label})` : ''}`).join(' · ')}`
      : '',
    r.selected
      ? `Exercice sélectionné : ${r.selected.number} — ${r.selected.heading}${r.selected.topics.length ? ` — thème(s) : ${r.selected.topics.map((t) => t.label).join(', ')}` : ''}`
      : 'Exercice sélectionné : aucun (demander à l’élève)',
    r.notes.length ? `Notes : ${r.notes.join(' | ')}` : '',
    '',
    "=== ÉNONCÉ OFFICIEL (déjà affiché à l'écran, français + LaTeX) ===",
    clip(statementOf(r)),
    '',
    r.correction
      ? `=== CORRIGÉ OFFICIEL — ${r.correctionScope === 'exercise' ? 'section de cet exercice' : 'document complet'} (référence ; ne pas le lire d'un bloc) ===\n${clip(r.correction)}`
      : '=== CORRIGÉ OFFICIEL : absent du dataset ===',
    '',
    '=== PROTOCOL ===',
    ...protocolLines(r),
  ]
    .filter((line) => line !== '')
    .join('\n');
}

/** functionResponse.response payload for get_examen_national. */
export function examToolResponse(r: ExamRetrieval): Record<string, unknown> {
  return {
    found: r.ok,
    displayed_on_screen: r.ok,
    exam: `Examen National ${r.request.year} — ${r.sessionLabel} — ${r.subjectLabel}`,
    selected_exercise: r.selected ? r.selected.number : null,
    source_sujet: r.sujetPath ?? null,
    source_corrige: r.corrigePath ?? null,
    result: buildExamContextText(r),
  };
}
