/**
 * Canonical bindings for the dataset repository CALCLUY/data-2bac-sma.
 * All files are read directly from GitHub (raw.githubusercontent.com is CORS-enabled),
 * so the app works as a pure static site.
 */

export type SubjectId = 'mathematiques' | 'physique-chimie' | 'svt';

export interface SubjectProfile {
  id: SubjectId;
  label: string;
  shortLabel: string;
  voiceName: 'Charon' | 'Orus' | 'Kore';
  teacherName: string;
  /** Subject directory inside ./2bac-data-sma/. */
  dir: string;
  /** Examen National years covered by the dataset. */
  examYears: string;
}

export const DATA_REPO = {
  owner: 'CALCLUY',
  repo: 'data-2bac-sma',
  branch: 'main',
  root: '2bac-data-sma',
} as const;

export const DATASET_REPOSITORY = `https://github.com/${DATA_REPO.owner}/${DATA_REPO.repo}`;

export const SUBJECT_PROFILES: Record<SubjectId, SubjectProfile> = {
  mathematiques: {
    id: 'mathematiques',
    label: 'Mathématiques',
    shortLabel: 'Maths',
    voiceName: 'Charon',
    teacherName: 'الأستاذ ديال الرياضيات',
    dir: 'mathematiques',
    examYears: '2010 → 2025',
  },
  'physique-chimie': {
    id: 'physique-chimie',
    label: 'Physique-Chimie',
    shortLabel: 'PC',
    voiceName: 'Orus',
    teacherName: 'الأستاذ ديال الفيزيك والكيمياء',
    dir: 'physique-chimie',
    examYears: '2010 → 2025',
  },
  svt: {
    id: 'svt',
    label: 'SVT',
    shortLabel: 'SVT',
    voiceName: 'Kore',
    teacherName: 'الأستاذ ديال علوم الحياة والأرض',
    dir: 'svt',
    examYears: '2016 → 2025',
  },
};

export const SUBJECT_IDS = Object.keys(SUBJECT_PROFILES) as SubjectId[];

export function isSubjectId(value: unknown): value is SubjectId {
  return value === 'mathematiques' || value === 'physique-chimie' || value === 'svt';
}

export function datasetScopeFor(subject: SubjectId): string {
  const p = SUBJECT_PROFILES[subject];
  return [
    `Repository: ${DATASET_REPOSITORY} (folder ./${DATA_REPO.root}/)`,
    `Active subject root: ./${DATA_REPO.root}/${p.dir}/`,
    `Examens nationaux (${p.examYears}): ./${DATA_REPO.root}/${p.dir}/examens-nationaux/{année}/{année}-normale-sujet.txt · {année}-normale-corrige.txt · {année}-rattrapage-sujet.txt · {année}-rattrapage-corrige.txt`,
  ].join('\n');
}
