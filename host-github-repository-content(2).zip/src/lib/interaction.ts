/**
 * Interactive lesson protocol shared by the prompt and the UI.
 *
 * The teacher ends every micro-part with exactly ONE of:
 *  a) a QCM exercise: the question is spoken, then its question/options are
 *     written as clickable chalk lines. A blocking tool response waits for
 *     the student's click, or JSON fallback pauses local output.
 *  b) a spoken yes/no question plus the [CHECK_UNDERSTANDING] tag.
 *
 * Whenever the teacher introduces a French scientific term, it also emits a
 * term card (JSON block or introduce_term tool) holding the plain Darija
 * meaning and one everyday analogy — see RULE ZERO B in prompts.ts.
 *
 * Formal written content (prose + LaTeX) goes to the virtual blackboard through
 * {"action":"blackboard_write_line"} / {"action":"blackboard_clear"}
 * blocks, or through the matching Live tools. Legacy multi-line writes are
 * accepted but split into the same sequential line queue.
 */
import { resolveIllustration } from './illustrations';

export interface ParsedQcm {
  /**
   * Optional. The teacher normally asks the question out loud, so the panel
   * shows only the choices under the spoken sentence.
   */
  question?: string;
  options: string[];
  correctIndex: number;
}

export interface ParsedTerm {
  /** The French term, e.g. "la continuité". */
  term: string;
  /** Plain Darija meaning, everyday words only. */
  meaning: string;
  /** One concrete visual / physical analogy from daily Moroccan life. */
  analogy?: string;
}

export type AnnotationType = 'underline' | 'arrow' | 'curved_arrow';

/** Coordinates are percentages of the 2:1 canvas, from 0 to 100. */
export type BoardPoint = [number, number];

export interface BoardAnnotation {
  type: AnnotationType;
  target?: string;
  from?: BoardPoint;
  to?: BoardPoint;
}

export type BoardDrawElement =
  | { type: 'line'; x1: number; y1: number; x2: number; y2: number; color?: string }
  | { type: 'circle'; cx: number; cy: number; r: number; color?: string }
  | { type: 'arrow'; from: BoardPoint; to: BoardPoint; label?: string; color?: string }
  | { type: 'curve'; points: BoardPoint[]; color?: string }
  | { type: 'underline'; target: string; color?: string }
  | {
      /** Free-hand SVG path in any unit space; it is fitted onto the board. */
      type: 'path';
      d: string;
      label?: string;
      x?: number;
      y?: number;
      scale?: number;
      rotate?: number;
      color?: string;
    }
  | {
      /** Named vector illustration from the built-in chalk library. */
      type: 'illustration';
      name: string;
      x?: number;
      y?: number;
      scale?: number;
      rotate?: number;
      label?: string;
      color?: string;
    };

export interface BoardDrawingItem {
  id: string;
  element: BoardDrawElement;
}

export type BoardActionKind = 'blackboard_write_line' | 'blackboard_write' | 'blackboard_clear' | 'blackboard_annotate' | 'blackboard_draw';

export interface ParsedBoardAction {
  action: BoardActionKind;
  /** Erase the board before writing (true) or append (false). */
  clear?: boolean;
  title?: string;
  /** Required by blackboard_write_line: exactly one spoken/written line. */
  line?: string;
  /** Optional custom chalk color: 'white', 'yellow', 'blue', 'green' or hex. */
  color?: string;
  /** Chalk lines: prose and/or LaTeX ($…$, $$…$$). */
  content?: string[];
  annotation?: BoardAnnotation;
  drawings?: BoardDrawElement[];
}

export interface ParsedModelContent {
  /** Transcript with QCM/board/term blocks and control tags removed. */
  displayText: string;
  qcms: ParsedQcm[];
  terms: ParsedTerm[];
  boardActions: ParsedBoardAction[];
  wantsCheck: boolean;
}

export const CHECK_TAG = '[CHECK_UNDERSTANDING]';
export const QCM_LETTERS = ['A', 'B', 'C', 'D', 'E', 'F'];

/* ------------------------------------------------------------------ */
/* JSON block extraction (raw or fenced)                              */
/* ------------------------------------------------------------------ */

function tryParseJson(value: string): unknown {
  try {
    return JSON.parse(value);
  } catch {
    return undefined;
  }
}

function tryParseQcm(value: unknown): ParsedQcm | null {
  if (!value || typeof value !== 'object') return null;
  const o = value as Record<string, unknown>;
  if (o.type !== 'qcm') return null;
  const question = typeof o.question === 'string' && o.question.trim().length > 0 ? o.question.trim() : undefined;
  if (!Array.isArray(o.options) || o.options.length < 2 || o.options.length > 4) return null;
  if (!o.options.every((x) => typeof x === 'string' && (x as string).trim().length > 0)) return null;
  if ((question && containsArabic(question)) || o.options.some((x) => containsArabic(x as string))) return null;
  const ci = o.correctIndex;
  if (typeof ci !== 'number' || !Number.isInteger(ci) || ci < 0 || ci >= o.options.length) return null;
  return { question, options: o.options as string[], correctIndex: ci };
}

function tryParseTerm(value: unknown): ParsedTerm | null {
  if (!value || typeof value !== 'object') return null;
  const o = value as Record<string, unknown>;
  if (o.type !== 'term') return null;
  const term = typeof o.term === 'string' ? o.term.trim() : '';
  const meaning = typeof o.meaning === 'string' ? o.meaning.trim() : (typeof o.meaning_darija === 'string' ? o.meaning_darija.trim() : '');
  const analogyRaw = typeof o.analogy === 'string' ? o.analogy.trim() : (typeof o.analogy_darija === 'string' ? o.analogy_darija.trim() : '');
  if (!term || !meaning) return null;
  return { term, meaning, analogy: analogyRaw || undefined };
}

function strArray(value: unknown): string[] | undefined {
  if (Array.isArray(value)) {
    const rows = value.filter((x): x is string => typeof x === 'string' && x.trim().length > 0).map((x) => x.trim());
    return rows.length ? rows : undefined;
  }
  if (typeof value === 'string' && value.trim()) return [value.trim()];
  return undefined;
}

function boardPoint(value: unknown): BoardPoint | undefined {
  if (!Array.isArray(value) || value.length !== 2) return undefined;
  if (!value.every((n) => typeof n === 'number' && Number.isFinite(n) && n >= 0 && n <= 100)) return undefined;
  return [value[0] as number, value[1] as number];
}

export function annotationFromArgs(value: Record<string, unknown>): BoardAnnotation | null {
  const type = value.type;
  if (type !== 'underline' && type !== 'arrow' && type !== 'curved_arrow') return null;
  const target = typeof value.target === 'string' ? value.target.trim().slice(0, 160) : '';
  const from = boardPoint(value.from);
  const to = boardPoint(value.to);
  if (!target && !(from && to)) return null;
  if ((value.from !== undefined || value.to !== undefined) && !(from && to)) return null;
  return { type, target: target || undefined, from, to };
}

const isPercent = (value: unknown): value is number =>
  typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 100;

export function optionalColor(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined;
  const c = value.trim().toLowerCase();
  if (c === 'white' || c === '#ffffff' || c === '#fff') return '#FFFFFF';
  if (c === 'yellow' || c === '#ffe600' || c === 'jaune') return '#FFE600';
  if (c === 'blue' || c === '#4fc3f7' || c === 'bleu') return '#4FC3F7';
  if (c === 'green' || c === '#81c784' || c === 'vert') return '#81C784';
  if (/^#[0-9a-f]{6}$/i.test(c)) return c;
  return undefined;
}

/** Check if text is an artificial zone header or separator divider. */
export function isSplitDividerOrHeader(text: string): boolean {
  if (!text) return false;
  const t = text.trim();
  // Headers to strip (e.g. "COURS & CALCULS", "SCHÉMAS & FIGURES", "ZONE COURS", etc.)
  if (/^(?:#{1,6}\s*)?(?:COURS\s*(&|ET)\s*CALCULS?|SCH[ÉE]MAS?\s*(&|ET)\s*FIGURES?|ZONE\s+COURS|ZONE\s+SCH[ÉE]MAS?|COURS\s*ET\s*EXERCICES|COURS|SCH[ÉE]MAS?|FIGURES?|CALCULS?)\s*:?$/i.test(t)) {
    return true;
  }
  // Pure separator line (e.g. "--------------------" or "===============" or "- - - - - - -" or "| | | |")
  if (/^[ \t\-_=*|:.]{3,}$/.test(t)) {
    return true;
  }
  return false;
}

function drawingFromElement(value: unknown): BoardDrawElement | null {
  if (!value || typeof value !== 'object') return null;
  const e = value as Record<string, unknown>;
  const type = e.type;
  const color = optionalColor(e.color);

  if (type === 'line' && isPercent(e.x1) && isPercent(e.y1) && isPercent(e.x2) && isPercent(e.y2)) {
    // Strip artificial vertical divider lines drawn down the middle of the board
    if (Math.abs(e.x1 - 50) <= 6 && Math.abs(e.x2 - 50) <= 6 && Math.abs(e.y2 - e.y1) >= 35) {
      return null;
    }
    return { type, x1: e.x1, y1: e.y1, x2: e.x2, y2: e.y2, color };
  }
  if (type === 'circle' && isPercent(e.cx) && isPercent(e.cy) && isPercent(e.r) && e.r > 0) {
    return { type, cx: e.cx, cy: e.cy, r: e.r, color };
  }
  if (type === 'arrow') {
    const from = boardPoint(e.from);
    const to = boardPoint(e.to);
    const label = typeof e.label === 'string' ? e.label.trim().slice(0, 100) : undefined;
    if (from && to && !containsArabic(label ?? '')) return { type, from, to, label, color };
  }
  if (type === 'curve' && Array.isArray(e.points) && e.points.length >= 2 && e.points.length <= 32) {
    const points = e.points.map(boardPoint);
    if (points.every((point): point is BoardPoint => !!point)) return { type, points, color };
  }
  if (type === 'underline' && typeof e.target === 'string' && e.target.trim() && !containsArabic(e.target)) {
    return { type, target: e.target.trim().slice(0, 160), color };
  }
  if (type === 'path') {
    const d = typeof e.d === 'string' ? e.d.trim() : '';
    // A path must start from a move and actually draw something.
    if (!d || d.length > 4000 || !/[Mm]/.test(d) || !/[LlCcQqTtAaHhVvSsZz]/.test(d)) return null;
    const label = optionalLabel(e.label);
    const place = placementOf(e);
    if (label === null || !place) return null;
    return { type, d, label, color, ...place };
  }
  if (type === 'illustration') {
    const name = typeof e.name === 'string' ? e.name.trim().slice(0, 40) : '';
    if (!name || containsArabic(name) || !resolveIllustration(name)) return null;
    const label = optionalLabel(e.label);
    const place = placementOf(e);
    if (label === null || !place) return null;
    return { type, name, label, color, ...place };
  }
  return null;
}

/** undefined → no label; null → rejected (e.g. Arabic script). */
function optionalLabel(value: unknown): string | undefined | null {
  if (value === undefined || value === null) return undefined;
  if (typeof value !== 'string') return null;
  const text = value.trim().slice(0, 120);
  if (!text) return undefined;
  return containsArabic(text) ? null : text;
}

function optionalPercent(value: unknown, fallback: number): number {
  if (value === undefined || value === null || value === '') return fallback;
  const n = Number(value);
  return Number.isFinite(n) && n >= 0 && n <= 100 ? n : NaN;
}

/** Shared placement for path/illustration: centre in %, scale and rotation. */
function placementOf(e: Record<string, unknown>): { x: number; y: number; scale: number; rotate: number } | null {
  const x = optionalPercent(e.x, 50);
  const y = optionalPercent(e.y, 50);
  const scale = e.scale === undefined || e.scale === null || e.scale === '' ? 1 : Number(e.scale);
  const rotate = e.rotate === undefined || e.rotate === null || e.rotate === '' ? 0 : Number(e.rotate);
  if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(scale) || !Number.isFinite(rotate)) return null;
  return { x, y, scale: Math.max(0.2, Math.min(5, scale)), rotate: Math.max(-360, Math.min(360, rotate)) };
}

/** Arabic letters are forbidden on the visual board; the spoken channel is Darija. */
export function containsArabic(text: string): boolean {
  return /[\u0600-\u06ff\u0750-\u077f\u08a0-\u08ff]/.test(text);
}

function tryParseBoardAction(value: unknown): ParsedBoardAction | null {
  if (!value || typeof value !== 'object') return null;
  const o = value as Record<string, unknown>;
  const action = typeof o.action === 'string' ? o.action.trim() : '';
  if (action === 'blackboard_annotate') {
    const annotation = annotationFromArgs(o);
    return annotation ? { action, annotation } : null;
  }
  if (action === 'blackboard_draw') {
    if (!Array.isArray(o.elements) || o.elements.length < 1 || o.elements.length > 48) return null;
    // Skip unsupported entries so one bad element cannot void a whole diagram.
    const drawings = o.elements
      .map(drawingFromElement)
      .filter((drawing): drawing is BoardDrawElement => !!drawing);
    if (!drawings.length) return null;
    return { action, drawings };
  }
  if (action !== 'blackboard_write_line' && action !== 'blackboard_write' && action !== 'blackboard_clear') return null;

  if (action === 'blackboard_clear') {
    const title = typeof o.title === 'string' ? o.title.trim() : undefined;
    return { action, title: title || undefined, content: strArray(o.content) };
  }

  if (action === 'blackboard_write_line') {
    const line = typeof o.line === 'string' ? o.line.trim() : '';
    if (!line || line.length > 320 || /[\r\n]/.test(line) || containsArabic(line)) return null;
    if (isSplitDividerOrHeader(line)) return null;
    const color = optionalColor(o.color);
    return { action, clear: o.clear === true, line, color };
  }

  const content = strArray(o.content) ?? strArray(o.lines);
  if (!content) return null;
  if (content.some(containsArabic)) return null;
  const filtered = content.filter((l) => !isSplitDividerOrHeader(l));
  if (!filtered.length) return null;
  const title = typeof o.title === 'string' && !isSplitDividerOrHeader(o.title) ? o.title.trim() : undefined;
  const color = optionalColor(o.color);
  return { action, clear: o.clear === true, title: title || undefined, content: filtered, color };
}

/** Extract a balanced {...} JSON candidate starting at `start` (string-aware). */
function extractBalancedJson(text: string, start: number): string | null {
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let i = start; i < text.length; i++) {
    const ch = text[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === '"') inString = false;
    } else {
      if (ch === '"') inString = true;
      else if (ch === '{') depth++;
      else if (ch === '}') {
        depth--;
        if (depth === 0) return text.slice(start, i + 1);
      }
    }
  }
  return null;
}

/**
 * Remove every valid JSON block containing one of `markers` and return the
 * parsed items. Invalid candidates stay untouched in the text.
 */
function extractMarked<T>(input: string, markers: string[], validate: (value: unknown) => T | null): { text: string; items: T[] } {
  let text = input;
  const items: T[] = [];

  // 1) Fenced code blocks.
  text = text.replace(/```(?:json)?\s*\n?([\s\S]*?)```/gi, (full, inner: string) => {
    const candidate = String(inner).trim();
    if (markers.some((m) => candidate.includes(m))) {
      const item = validate(tryParseJson(candidate));
      if (item) {
        items.push(item);
        return '\n';
      }
    }
    return full;
  });

  // 2) Raw JSON objects containing a marker.
  const removals: string[] = [];
  let searchFrom = 0;
  for (;;) {
    let found: { idx: number; marker: string } | null = null;
    for (const m of markers) {
      const idx = text.indexOf(m, searchFrom);
      if (idx !== -1 && (!found || idx < found.idx)) found = { idx, marker: m };
    }
    if (!found) break;
    const braceIdx = text.lastIndexOf('{', found.idx);
    if (braceIdx < searchFrom) {
      searchFrom = found.idx + found.marker.length;
      continue;
    }
    const candidate = extractBalancedJson(text, braceIdx);
    if (!candidate) {
      searchFrom = found.idx + found.marker.length;
      continue;
    }
    const item = validate(tryParseJson(candidate));
    if (item) {
      items.push(item);
      removals.push(candidate);
      searchFrom = braceIdx + candidate.length;
      continue;
    }
    searchFrom = found.idx + found.marker.length;
  }
  for (const r of removals) text = text.replace(r, '\n');

  return { text, items };
}

/* ------------------------------------------------------------------ */
/* Streaming sanitising                                                */
/* ------------------------------------------------------------------ */

/** Drop an unterminated trailing [CHEC... fragment while the tag is streaming. */
function stripPartialCheckTag(text: string): string {
  const idx = text.lastIndexOf('[');
  if (idx === -1) return text;
  if (text.indexOf(']', idx) !== -1) return text;
  const fragment = text.slice(idx + 1).toUpperCase();
  if (fragment.length > 0 && fragment.length < CHECK_TAG.length && CHECK_TAG.slice(1).toUpperCase().startsWith(fragment)) {
    return text.slice(0, idx);
  }
  return text;
}

/**
 * Drop an unterminated trailing JSON object (a QCM, a term or a board action
 * being written right now). Board blocks can be long, hence the generous limit.
 */
function stripPartialJson(text: string): string {
  const lastBrace = text.lastIndexOf('{');
  if (lastBrace === -1) return text;
  const tail = text.slice(lastBrace);
  if (tail.includes('}')) return text;
  if (tail.length > 6000) return text;
  return text.slice(0, lastBrace);
}

const CONTROL_MARKERS = ['"qcm"', '"term"', '"blackboard_draw"', '"blackboard_annotate"', '"blackboard_write_line"', '"blackboard_write"', '"blackboard_clear"', '"action"'];

/**
 * Interim transcript while the teacher is still talking: keeps the visible text
 * clean so partial JSON blocks and control tags never flash on screen.
 */
export function sanitizeStreamingText(raw: string): string {
  let text = raw;
  text = text.replace(/```[\s\S]*?```/g, '\n');
  const openFence = text.indexOf('```');
  if (openFence !== -1) text = text.slice(0, openFence);
  text = extractMarked(text, CONTROL_MARKERS, () => true).text;
  text = stripPartialCheckTag(text);
  text = stripPartialJson(text);
  return text.replace(/\n{3,}/g, '\n\n').trim();
}

/* ------------------------------------------------------------------ */
/* Finished-turn parsing                                               */
/* ------------------------------------------------------------------ */

/**
 * Detects a question that can genuinely be answered with yes / no,
 * e.g. "واش فهمتي؟", "واش هاد الشي صحيح؟", "واش متأكد؟", "Est-ce que c'est clair ?".
 * Open questions ("شنو هي…", "كيفاش…", "combien…") must NOT trigger the yes/no bar.
 */
export function looksLikeYesNoQuestion(text: string): boolean {
  const tail = text.slice(-260).toLowerCase();
  if (!tail.trim()) return false;

  const openMarkers = /(شنو|شحال|كيفاش|علاش|فين|إيمتى|امتى|أشمن|combien|comment|pourquoi|quelle|quel\b|quels|où|quand|calcule|donne|explique)/i;
  if (openMarkers.test(tail)) return false;

  const strong =
    /(واش|فهمتي|فهمتيني|متأكد|متافق|واضح|مفهوم|صافي|as-tu compris|avez-vous compris|est-ce que|c'est clair|c’est clair|d'accord|d’accord|oui ou non|understood|is this correct|are you sure)/i;
  if (strong.test(tail)) return true;

  const hasQuestionMark = /[?؟]\s*$/.test(tail.trim());
  if (!hasQuestionMark) return false;
  const lastSentence = tail.split(/[.!؟?\n]/).filter(Boolean).pop() ?? '';
  return lastSentence.trim().split(/\s+/).length <= 9;
}

/** Parse a finished teacher message. */
export function parseModelContent(raw: string): ParsedModelContent {
  const qcmPass = extractMarked(raw, ['"qcm"'], tryParseQcm);
  const termPass = extractMarked(qcmPass.text, ['"term"'], tryParseTerm);
  const boardPass = extractMarked(termPass.text, ['"blackboard_draw"', '"blackboard_annotate"', '"blackboard_write_line"', '"blackboard_write"', '"blackboard_clear"'], tryParseBoardAction);
  let text = boardPass.text;

  const hasCheckTag = text.includes(CHECK_TAG);
  if (hasCheckTag) text = text.split(CHECK_TAG).join('');
  text = stripPartialCheckTag(text);

  const displayText = text.replace(/\n{3,}/g, '\n\n').trim();

  // The yes/no bar shows only for a genuine yes/no question, and never next to a QCM.
  const wantsCheck = qcmPass.items.length === 0 && (hasCheckTag || looksLikeYesNoQuestion(displayText));

  return { displayText, qcms: qcmPass.items, terms: termPass.items, boardActions: boardPass.items, wantsCheck };
}

/** Merge tool-generated and JSON-fallback term cards, dropping duplicates. */
export function mergeTerms(...groups: ParsedTerm[][]): ParsedTerm[] {
  const seen = new Set<string>();
  const out: ParsedTerm[] = [];
  for (const group of groups) {
    for (const t of group) {
      const key = t.term.trim().toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(t);
    }
  }
  return out;
}

/** Normalise a board action coming from a tool call (names follow the tool schema). */
export function boardActionFromParts(
  action: string,
  args: { clear?: unknown; title?: unknown; line?: unknown; color?: unknown; content?: unknown; lines?: unknown; elements?: unknown; type?: unknown; target?: unknown; from?: unknown; to?: unknown },
): ParsedBoardAction | null {
  return tryParseBoardAction({ action, clear: args.clear, title: args.title, line: args.line, color: args.color, content: args.content ?? args.lines, elements: args.elements, type: args.type, target: args.target, from: args.from, to: args.to });
}

/**
 * True when the spoken transcript already carries the QCM question, in which case
 * the panel shows only the choices (continuity of the teacher's speech).
 */
export function transcriptCoversQuestion(transcript: string, question?: string): boolean {
  // A QCM without a written mirror can never be safely revealed: the UI must
  // be able to prove that the question was actually spoken.
  if (!question) return false;
  const norm = (s: string) =>
    s
      .toLowerCase()
      .replace(/\$[^$]*\$/g, ' ')
      .replace(/[^\p{L}\p{N}]+/gu, ' ')
      .trim();
  const q = norm(question);
  const t = norm(transcript);
  if (!q) return false;
  if (t.includes(q)) return true;
  const words = q.split(' ').filter((w) => w.length > 3);
  if (words.length === 0) return false;
  const hits = words.filter((w) => t.includes(w)).length;
  return hits / words.length >= 0.75;
}

/** Remove a leading "A) " style prefix since the UI renders its own letter badges. */
export function stripOptionPrefix(option: string): string {
  const stripped = option.replace(/^\s*[A-Fa-f][).\-:]\s*/, '').trim();
  return stripped.length > 0 ? stripped : option;
}

/* ---------------- Button wire signals (sent as realtimeInput text) ---------------- */

/**
 * Re-asserted on every student turn: native-audio sessions drift toward French
 * after long formal passages (exam statements, formulas), and tend to stack
 * unexplained terms. Kept short and in Darija so the model reads it naturally.
 */
export const DARIJA_REMINDER =
  '(تذكير: هضر غير بالدارجة المغربية. المصطلح العلمي كيبقى بإسمو الفرنسي (Polynôme، Suite، la dérivée) — ممنوع تعوّضو بمرادف عربي بحال «حدودية» ولا «متتالية» ولا «المشتقة»، وممنوع «... يعني» متبوعة بإسم عربي. قول المصطلح بالفرنسية، من بعد سوّل «شنو هو؟» وفسّر بالدارجة بمثال محسوس. الكتابة فالسبورة بالفرنسية/LaTeX فقط بلا حروف عربية. قول جملة وحدة، من بعدها blackboard_write_line وتسنّى animation_complete. إلا طرحتي QCM، وقف الكلام حتى يضغط التلميذ على جواب فوق السبورة؛ من بعد جاوب واش صحيح، شرح علاش، وعاد كمل. ماكاينش chat مكتوب.)';

/** Append the language + term reminder to any text sent to the teacher. */
export function withDarijaReminder(wireText: string): string {
  return `${wireText}\n\n${DARIJA_REMINDER}`;
}

export const UNDERSTOOD_DISPLAY = 'صحيح / فهمت — كمل للجزء الجاي';
export const UNDERSTOOD_SIGNAL = `[BUTTON:UNDERSTOOD] Praise briefly in Darija AUDIO, then teach the NEXT micro-part. Any new scientific concept is named with its FRENCH term first, then explained from first principles in Darija with a concrete analogy — never renamed with an Arabic synonym. Strict pacing: speak exactly ONE short sentence/formula, call blackboard_write_line with that exact visual line, and WAIT for animation_complete before speaking the next line. Never batch lines. End with one check. No chat prose.`;

export const NOT_UNDERSTOOD_DISPLAY = 'خطأ / مافهمتش — عاود الشرح';
export const NOT_UNDERSTOOD_SIGNAL = `[BUTTON:NOT_UNDERSTOOD] Do NOT advance. Re-teach the SAME micro-part in Darija with a DIFFERENT, simpler analogy. Keep the SAME French term name (repeat it, ask «شنو هو …؟» again, then re-explain what it is); do NOT replace it with an Arabic synonym to make it easier. For each visual sentence: speak it, call one blackboard_write_line with the matching line, then WAIT for animation_complete. Never batch lines. End with one new check; no chat prose.`;

export function buildQcmAnswerSignal(
  qcm: ParsedQcm,
  optionIndex: number,
): { display: string; signal: string } {
  const letter = QCM_LETTERS[optionIndex] ?? String(optionIndex + 1);
  const correctLetter = QCM_LETTERS[qcm.correctIndex] ?? String(qcm.correctIndex + 1);
  const labeled = qcm.options
    .map((o, i) => `${QCM_LETTERS[i] ?? i + 1}) ${stripOptionPrefix(o)}`)
    .join(' | ');
  const chosen = stripOptionPrefix(qcm.options[optionIndex] ?? '');
  const questionRef = qcm.question ? `"${qcm.question}"` : 'the question you just asked out loud';
  const isCorrect = optionIndex === qcm.correctIndex;

  const correctFlow = `The student is CORRECT. First acknowledge in one short Darija AUDIO sentence, then explain in simple Darija WHY option ${correctLetter} is right. Only AFTER that resume the next micro-part of the locked chapter. Write formulas one at a time on the board with blackboard_write_line and wait for animation_complete.`;

  const wrongFlow = `The student is WRONG (correct was option ${correctLetter}). Follow this recovery sequence strictly AFTER the real click:
1. Briefly acknowledge in Darija AUDIO that the answer is not correct and give the correct option.
2. Explain WHY in simple Darija, then RE-EXPLAIN the same micro-part from zero with a DIFFERENT visual analogy and a different everyday image. Keep the concept's FRENCH name unchanged and re-explain what it is; never substitute an Arabic synonym. Do not just restate the correct option.
3. Then ask a NEW SIMILAR QCM: same concept and same difficulty, but a DIFFERENT question with DIFFERENT wording, different option order, and if possible different values or a different everyday example. NEVER repeat the previous question or reuse the same options verbatim.
4. Speak the new question, then display its choices with ask_qcm (a fresh JSON block only if tools are unavailable; never read JSON aloud). Do not advance to the next micro-part until the student answers this new QCM correctly.`;

  return {
    display: `جوابي: ${letter}) ${chosen}`,
    signal: `[BUTTON:QCM_ANSWER] The student answered the QCM for ${questionRef}. Options: ${labeled}. The student chose option ${letter} ("${chosen}"). ${isCorrect ? correctFlow : wrongFlow}`,
  };
}
