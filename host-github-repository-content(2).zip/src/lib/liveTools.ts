/**
 * Function declarations exposed to the Gemini Live session.
 *
 * - get_examen_national / list_examens_nationaux: grounded retrieval from
 *   ./2bac-data-sma/{subject}/examens-nationaux/ (works for voice requests too).
 * - blackboard_write_line / blackboard_clear / blackboard_annotate / blackboard_draw: synchronized JSON
 *   commands to the sole visual teaching surface. Each tool response is held
 *   until the handwriting animation completes, providing pacing backpressure.
 * - ask_qcm: a blocking call; A–D options are clickable handwritten lines
 *   on the board. Its function response is withheld until a student clicks.
 */
import {
  boardActionFromParts,
  containsArabic,
  isSplitDividerOrHeader,
  optionalColor,
  type BoardDrawElement,
  type ParsedBoardAction,
  type ParsedQcm,
  type ParsedTerm,
} from './interaction';
import { illustrationCatalogue } from './illustrations';

export interface LiveFunctionCall {
  id?: string;
  name: string;
  args?: Record<string, unknown>;
}

export interface LiveFunctionResponse {
  id?: string;
  name: string;
  response: Record<string, unknown>;
}

const SUBJECT_PARAM = {
  type: 'STRING',
  enum: ['mathematiques', 'physique-chimie', 'svt'],
  description: 'Subject folder. Default: the active subject of the session.',
};

export const LIVE_TOOL_DECLARATIONS = [
  {
    functionDeclarations: [
      {
        name: 'get_examen_national',
        description:
          "Retrieve the exact official statement (sujet) and correction (corrigé) of a Moroccan Examen National exercise from CALCLUY/data-2bac-sma. The application writes the original statement to the 2:1 chalkboard in French and LaTeX — never to a chat card. Call whenever the student asks for a specific exam/exercise or you need a real example.",
        parameters: {
          type: 'OBJECT',
          properties: {
            subject: SUBJECT_PARAM,
            year: { type: 'INTEGER', description: 'Exam year, e.g. 2018.' },
            session: {
              type: 'STRING',
              enum: ['normale', 'rattrapage'],
              description: 'normale = Session Normale = الدورة العادية ; rattrapage = Session de Contrôle = الدورة الاستدراكية.',
            },
            exercise: { type: 'INTEGER', description: 'Exercise number named by the student (1, 2, 3…). Omit if unknown.' },
            topic: {
              type: 'STRING',
              description: 'Topic named by the student, e.g. "nombres complexes", "arithmétique", "probabilités", "dipôle RC". Omit if none.',
            },
          },
          required: ['year'],
        },
      },
      {
        name: 'list_examens_nationaux',
        description:
          'List the Examen National years and sessions available in the dataset for a subject. With a topic, also list the exam exercises detected for that topic.',
        parameters: {
          type: 'OBJECT',
          properties: {
            subject: SUBJECT_PARAM,
            topic: { type: 'STRING', description: 'Optional topic, e.g. "nombres complexes".' },
          },
        },
      },
      {
        name: 'blackboard_write_line',
        description:
          'MANDATORY synchronized visual action. Immediately AFTER speaking exactly ONE short sentence or equation, call this tool with the matching single visual line on the left side of the board. The frontend queues it, animates its chalk handwriting, and withholds the tool response until writing is complete. Do NOT speak the next sentence until the response says animation_complete:true. Never batch two sentences or equations into one line. Do not write artificial headers like "COURS & CALCULS".',
        parameters: {
          type: 'OBJECT',
          properties: {
            clear: { type: 'BOOLEAN', description: 'true only for the first line of a genuinely new step/exercise; it wipes before writing. Otherwise false.' },
            line: { type: 'STRING', description: 'Exactly ONE short French sentence OR ONE LaTeX equation matching the line just spoken. No newline characters and no array.' },
            color: {
              type: 'STRING',
              enum: ['white', 'yellow', 'blue', 'green'],
              description: 'Chalk color: "white" (regular prose, default), "yellow" (formula/title), "blue" (subhead/cue), "green" (labels/notes).',
            },
          },
          required: ['line'],
        },
      },
      {
        name: 'blackboard_clear',
        description:
          'Wipe the virtual blackboard before a new step. WAIT for animation_complete:true before speaking or sending blackboard_write_line.',
        parameters: {
          type: 'OBJECT',
          properties: {},
        },
      },
      {
        name: 'blackboard_annotate',
        description:
          'Add ONE hand-drawn chalk mark AFTER the target line has finished writing. Use type underline, arrow or curved_arrow and the exact visible target text/variable (preferred). Alternatively provide both from and to as [x,y] pairs in 0..100 percentages of the 2:1 board surface. Wait for animation_complete before speaking the next line. Do not annotate non-existent targets.',
        parameters: {
          type: 'OBJECT',
          properties: {
            type: { type: 'STRING', enum: ['underline', 'arrow', 'curved_arrow'], description: 'Chalk stroke type.' },
            target: { type: 'STRING', description: 'Exact visible word, variable or equation segment to point at or underline.' },
            from: { type: 'ARRAY', items: { type: 'NUMBER' }, description: 'Optional starting [x,y], each 0..100 percent of canvas.' },
            to: { type: 'ARRAY', items: { type: 'NUMBER' }, description: 'Optional ending [x,y], each 0..100 percent of canvas. Supply with from.' },
          },
          required: ['type'],
        },
      },
      {
        name: 'blackboard_draw',
        description: `MANDATORY VISUAL-FIRST TOOL. Draw on the 2:1 chalkboard with normalized 0–100 percentage coordinates (x left-to-right, y top-to-bottom). Element types: "line", "circle", "arrow" (with optional label), "curve" (2–32 points), "underline" (exact visible target), "path" (ANY SVG path data — cars, trees, people, organs, mechanisms) and "illustration" (named preset, animated stroke by stroke). Built-in illustration names: ${illustrationCatalogue()}. Use "path" for anything not in that list. Speak the matching short Darija narration first, then call this tool; the response waits until every chalk stroke is visible. Prefer ONE element per call so audio and chalk stay in sync; up to 4 elements are allowed only when together they form ONE composite object. Never draw Arabic labels.`,
        parameters: {
          type: 'OBJECT',
          properties: {
            elements: {
              type: 'ARRAY',
              description: 'Use a single vector element for one synchronized visual step.',
              items: {
                type: 'OBJECT',
                properties: {
                  type: { type: 'STRING', enum: ['line', 'circle', 'arrow', 'curve', 'underline', 'path', 'illustration'] },
                  x1: { type: 'NUMBER' }, y1: { type: 'NUMBER' }, x2: { type: 'NUMBER' }, y2: { type: 'NUMBER' },
                  cx: { type: 'NUMBER' }, cy: { type: 'NUMBER' }, r: { type: 'NUMBER' },
                  from: { type: 'ARRAY', items: { type: 'NUMBER' }, description: '[x,y] pair, percentages 0–100.' },
                  to: { type: 'ARRAY', items: { type: 'NUMBER' }, description: '[x,y] pair, percentages 0–100.' },
                  points: { type: 'ARRAY', items: { type: 'ARRAY', items: { type: 'NUMBER' } }, description: 'Ordered [x,y] pairs, 2–32 points.' },
                  d: {
                    type: 'STRING',
                    description:
                      'SVG path data for type "path", e.g. "M10 80 Q 52.5 10 95 80 T 180 80". Any unit space is accepted: the shape is auto-scaled onto the board. Supports M L H V C S Q T A Z, absolute or relative.',
                  },
                  name: {
                    type: 'STRING',
                    description:
                      'Preset name for type "illustration": car, tree, human_stick, pulley, battery, dna, incline, lens, cell, spring, resistor, bulb, capacitor, axes, wave.',
                  },
                  x: { type: 'NUMBER', description: 'Centre x of a path/illustration, 0–100 percent. Default 50.' },
                  y: { type: 'NUMBER', description: 'Centre y of a path/illustration, 0–100 percent. Default 50.' },
                  scale: { type: 'NUMBER', description: 'Size multiplier for a path/illustration. Default 1, allowed 0.2–5.' },
                  rotate: { type: 'NUMBER', description: 'Rotation in degrees for a path/illustration. Default 0.' },
                  color: { type: 'STRING', description: 'Chalk stroke color: "white", "yellow", "blue", "green" or hex.' },
                  label: { type: 'STRING', description: 'Optional academic French / LaTeX vector label, e.g. "$\\vec{v}$".' },
                  target: { type: 'STRING', description: 'Exact visible French/LaTeX text segment for underline.' },
                },
                required: ['type'],
              },
            },
          },
          required: ['elements'],
        },
      },
      {
        name: 'ask_qcm',
        behavior: 'BLOCKING',
        description:
          'STOP after speaking the complete QCM question in Moroccan Darija. Give this tool the semantically equivalent formal French/LaTeX board question and French/LaTeX options (never Arabic). The frontend writes each as chalk and makes option lines clickable ON the board. This BLOCKING call receives NO function response until a student clicks. Remain entirely silent and do not teach, call another tool, or continue while waiting. The eventual tool response contains the selected answer and correctness; THEN acknowledge briefly in Darija audio, explain why, and resume the lesson.',
        parameters: {
          type: 'OBJECT',
          properties: {
            question: { type: 'STRING', description: 'Formal French/LaTeX equivalent of the spoken Darija question. No Arabic characters.' },
            options: { type: 'ARRAY', items: { type: 'STRING' }, description: '2 to 4 formal French and/or LaTeX options, without "A)" prefixes and with no Arabic characters.' },
            correctIndex: { type: 'INTEGER', description: '0-based index of the correct option.' },
          },
          required: ['question', 'options', 'correctIndex'],
        },
      },
    ],
  },
];

/** Validate ask_qcm arguments (same rules as the JSON QCM block). */
export function qcmFromToolArgs(args: Record<string, unknown>): ParsedQcm | null {
  const question = typeof args.question === 'string' ? args.question.trim() : '';
  const options = Array.isArray(args.options)
    ? args.options.filter((o): o is string => typeof o === 'string' && o.trim().length > 0).map((o) => o.trim().replace(/\s*[\r\n]+\s*/g, ' '))
    : [];
  const ci = typeof args.correctIndex === 'number' ? args.correctIndex : Number(args.correctIndex);
  if (!question || containsArabic(question) || options.some(containsArabic) || options.length < 2 || options.length > 4) return null;
  if (!Number.isInteger(ci) || ci < 0 || ci >= options.length) return null;
  return { question, options, correctIndex: ci };
}

const str = (v: unknown) => (typeof v === 'string' ? v.trim() : '');

/** Validate synchronized and legacy board tool arguments. */
export function boardActionFromToolArgs(name: string, args: Record<string, unknown>): ParsedBoardAction | null {
  const title = str(args.title) || undefined;
  if (name === 'blackboard_clear') return { action: 'blackboard_clear', title };
  if (name === 'blackboard_annotate') return boardActionFromParts(name, args);
  if (name === 'blackboard_draw') {
    if (!Array.isArray(args.elements) || !args.elements.length || args.elements.length > 48) return null;
    // Unsupported entries are skipped rather than voiding the whole diagram.
    const drawings = args.elements
      .flatMap((entry) => boardActionFromParts('blackboard_draw', { elements: [entry] })?.drawings ?? [])
      .filter((drawing): drawing is BoardDrawElement => !!drawing);
    if (!drawings.length) return null;
    return { action: 'blackboard_draw', drawings };
  }
  if (name === 'blackboard_write_line') {
    const line = str(args.line);
    if (!line || line.length > 320 || /[\r\n]/.test(line) || containsArabic(line)) return null;
    if (isSplitDividerOrHeader(line)) return null;
    const color = optionalColor(args.color);
    return { action: 'blackboard_write_line', clear: args.clear === true, line, color };
  }
  if (name === 'blackboard_write') {
    const rows = Array.isArray(args.content)
      ? args.content.filter((x): x is string => typeof x === 'string' && x.trim().length > 0).map((x) => x.trim())
      : typeof args.content === 'string' && args.content.trim()
        ? [args.content.trim()]
        : [];
    const filtered = rows.filter((r) => !isSplitDividerOrHeader(r));
    if (!filtered.length) return null;
    const safeTitle = title && !isSplitDividerOrHeader(title) ? title : undefined;
    const color = optionalColor(args.color);
    return { action: 'blackboard_write', clear: args.clear === true, title: safeTitle, content: filtered, color };
  }
  if (name === 'write_on_board') {
    const content = str(args.content);
    if (!content) return null;
    // Legacy tool: one definition block, always written on a wiped board.
    return { action: 'blackboard_write', clear: true, title, content: [content] };
  }
  return null;
}

/** Validate introduce_term arguments (accepts both naming conventions). */
export function termFromToolArgs(args: Record<string, unknown>): ParsedTerm | null {
  const term = str(args.term);
  const meaning = str(args.meaning_darija) || str(args.meaning);
  const analogy = str(args.analogy_darija) || str(args.analogy);
  if (!term || !meaning) return null;
  return { term, meaning, analogy: analogy || undefined };
}
