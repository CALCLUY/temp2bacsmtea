/**
 * STRICT directory → chapter index of the dataset CALCLUY/data-2bac-sma.
 *
 * Every chapter number maps to exactly ONE repository directory and ONE topic.
 * This single table is shared by:
 *  - the system prompt (strict mapping, anti topic-drift),
 *  - the chapter loader (exact files injected into the Live session),
 *  - the Examen National classifier (topic of each exam exercise).
 */
import type { SubjectId } from './dataset';

export type Signal = [RegExp, number];

export interface ChapterDef {
  /** Stable selector key: '01'…'12' (maths), '01'…'29' / '18a' (PC), 'transfert' / 'populations' (SVT). */
  key: string;
  subject: SubjectId;
  /** Display number, e.g. '01', '18a', 'U1'. */
  number: string;
  /** Official French title. */
  title: string;
  /** Arabic title as used in Moroccan classes. */
  titleAr: string;
  /** Directory inside ./2bac-data-sma/ that holds the chapter files. */
  dir: string;
  /** PC only: file prefix inside `dir` (`${filePrefix}-cours.txt`, `${filePrefix}-exos.txt`). */
  filePrefix?: string;
  /** Names a student may use for the chapter (FR / AR / Darija). Normalised at match time. */
  aliases: string[];
  /** Weighted regex signals used to classify Examen National exercises. */
  signals: Signal[];
  /** True when discovered at runtime from the repository index. */
  discovered?: boolean;
}

const pad = (n: number) => String(n).padStart(2, '0');

function math(n: number, slug: string, title: string, titleAr: string, aliases: string[], signals: Signal[]): ChapterDef {
  return {
    key: pad(n),
    subject: 'mathematiques',
    number: pad(n),
    title,
    titleAr,
    dir: `mathematiques/chapitre-${pad(n)}-${slug}`,
    aliases,
    signals,
  };
}

/* ------------------------------------------------------------------ */
/* Mathématiques — 12 chapters (directory names verified in the repo)  */
/* ------------------------------------------------------------------ */
export const MATH_CHAPTERS: ChapterDef[] = [
  math(1, 'limites-et-continuite', 'Limites et Continuité', 'النهايات والاتصال',
    ['limites et continuité', 'limites et continuite', 'limite', 'limites', 'continuité', 'continuite', 'tvi', 'valeurs intermédiaires', 'fonction réciproque', 'arctan', 'النهايات والاتصال', 'النهايات', 'الاتصال'],
    [[/continu(?:e|it[ée])/i, 1.5], [/valeurs? interm[ée]diaires?|\bT\.?V\.?I\b/i, 3], [/bijection|r[ée]ciproque/i, 2], [/arctan/i, 3], [/\\sqrt\[|racine n-i[èe]me/i, 2.5], [/\\lim/, 0.5]]),
  math(2, 'suites-numeriques', 'Suites Numériques', 'المتتاليات العددية',
    ['suites numériques', 'suites numeriques', 'suite numérique', 'suites', 'suite', 'المتتاليات العددية', 'المتتاليات', 'متتالية'],
    [[/\bsuites?\b/i, 2.5], [/u_\{?n/, 2], [/v_\{?n|w_\{?n/, 1], [/r[ée]currence/i, 1.5], [/adjacentes/i, 3], [/converge/i, 1]]),
  math(3, 'derivation-et-etude-des-fonctions', 'Dérivation et Étude des Fonctions', 'الاشتقاق ودراسة الدوال',
    ['dérivation', 'derivation', 'dérivée', 'derivee', 'dérivabilité', 'derivabilite', 'étude des fonctions', 'etude des fonctions', 'étude de fonction', 'الاشتقاق', 'دراسة الدوال', 'المشتقة'],
    [[/d[ée]rivab/i, 2], [/d[ée]riv[ée]e/i, 1.5], [/tangente/i, 1.5], [/tableau de variations?|variations/i, 1], [/accroissements finis|\bT\.?A\.?F\b|rolle/i, 3], [/concavit[ée]|inflexion/i, 2], [/branches? infinies?|asymptote/i, 1.5]]),
  math(4, 'fonctions-logarithmiques', 'Fonctions Logarithmiques', 'الدوال اللوغاريتمية',
    ['fonctions logarithmiques', 'fonction logarithme', 'logarithmes', 'logarithme', 'ln', 'الدوال اللوغاريتمية', 'اللوغاريتم', 'لوغاريتم'],
    [[/\\ln\b/, 1.5], [/logarithm/i, 3], [/\\log/, 1.5]]),
  math(5, 'fonctions-exponentielles', 'Fonctions Exponentielles', 'الدوال الأسية',
    ['fonctions exponentielles', 'fonction exponentielle', 'exponentielles', 'exponentielle', 'exp', 'الدوال الأسية', 'الدالة الأسية', 'الأسية'],
    [[/exponentiel/i, 3], [/\\exp\b/, 2], [/\be\^\{?[-\w(\\]/, 1]]),
  math(6, 'nombres-complexes', 'Nombres Complexes', 'الأعداد العقدية',
    ['nombres complexes', 'nombre complexe', 'complexes', 'complexe', 'الأعداد العقدية', 'العقدية', 'لعداد العقدية'],
    [[/nombres? complexes?|plan complexe/i, 3], [/affixe/i, 3], [/forme exponentielle|forme trigonom[ée]trique/i, 2], [/rotation|homoth[ée]tie|similitude|translation/i, 1.5], [/cocycliques?/i, 2], [/\\overrightarrow\{u\}/, 2], [/e\^\{i/, 2], [/\\mathbb\{C\}/, 0.5], [/\bmodule\b|\bargument\b/i, 1]]),
  math(7, 'calcul-integral', 'Calcul Intégral', 'الحساب التكاملي',
    ['calcul intégral', 'calcul integral', 'intégrales', 'integrales', 'intégrale', 'integrale', 'intégration', 'primitive', 'primitives', 'التكامل', 'الحساب التكاملي'],
    [[/\\int(?![a-z])/, 3], [/int[ée]grale|int[ée]gration/i, 3], [/primitive/i, 2], [/par parties/i, 2.5], [/changement de variable/i, 2], [/\baire\b|volume/i, 1]]),
  math(8, 'equations-differentielles', 'Équations Différentielles', 'المعادلات التفاضلية',
    ['équations différentielles', 'equations differentielles', 'équation différentielle', 'equation differentielle', 'eq diff', 'eqdiff', 'المعادلات التفاضلية', 'معادلة تفاضلية'],
    [[/[ée]quations? diff[ée]rentielles?/i, 4], [/y''|y\^\{\\prime\s*\\prime\}/, 2], [/\by'\s*[+\-=]/, 1.5]]),
  math(9, 'arithmetique-dans-z', 'Arithmétique dans ℤ', 'الحسابيات في Z',
    ['arithmétique dans z', 'arithmetique dans z', 'arithmétique', 'arithmetique', 'congruence', 'congruences', 'nombres premiers', 'pgcd', 'الحسابيات', 'حسابيات'],
    [[/nombres? premiers?|premiers entre eux/i, 3], [/\\equiv/, 3], [/congru/i, 3], [/pgcd|\\wedge|ppcm/i, 2], [/b[ée]zout|gauss|fermat/i, 3], [/divis(?:e|ible|eur)/i, 1.5], [/modulo/i, 2]]),
  math(10, 'structures-algebriques', 'Structures Algébriques', 'البنيات الجبرية',
    ['structures algébriques', 'structures algebriques', 'structure algébrique', 'structures', 'groupe', 'groupes', 'anneau', 'anneaux', 'corps', 'loi de composition', 'البنيات الجبرية', 'البنيات'],
    [[/sous-groupe|\bgroupes?\b/i, 2.5], [/anneaux?\b/i, 3], [/\bcorps\b/i, 2.5], [/loi de composition/i, 3], [/homomorphisme|isomorphisme|morphisme/i, 3], [/[ée]l[ée]ment neutre|sym[ée]trique/i, 1.5], [/partie stable/i, 1.5], [/associativ|distributiv|commutati/i, 1]]),
  math(11, 'espaces-vectoriels', 'Espaces Vectoriels', 'الفضاءات المتجهية',
    ['espaces vectoriels', 'espace vectoriel', 'sous-espace vectoriel', 'الفضاءات المتجهية', 'فضاء متجهي'],
    [[/espaces? vectoriels?/i, 3], [/sous-espace/i, 2], [/\bbase\b/i, 1.5], [/famille (?:libre|li[ée]e|g[ée]n[ée]ratrice)/i, 2], [/dimension/i, 2], [/combinaison lin[ée]aire/i, 2]]),
  math(12, 'calcul-de-probabilites', 'Calcul de Probabilités', 'حساب الاحتمالات',
    ['calcul de probabilités', 'calcul de probabilites', 'probabilités', 'probabilites', 'probabilité', 'proba', 'probas', 'dénombrement', 'variable aléatoire', 'حساب الاحتمالات', 'الاحتمالات'],
    [[/probabilit/i, 3], [/urnes?|boules?|jetons?/i, 1.5], [/tirages?/i, 1.5], [/al[ée]atoire/i, 2], [/[ée]v[ée]nements?/i, 2], [/esp[ée]rance|variance|loi binomiale/i, 2.5]]),
];

/* ------------------------------------------------------------------ */
/* Physique-Chimie — semestre-1 (01–16) & semestre-2 (17–26b, + runtime) */
/* ------------------------------------------------------------------ */
function pc(sem: 1 | 2, key: string, slug: string, title: string, titleAr: string, aliases: string[], signals: Signal[]): ChapterDef {
  return {
    key,
    subject: 'physique-chimie',
    number: key,
    title,
    titleAr,
    dir: `physique-chimie/semestre-${sem}`,
    filePrefix: `${key}-${slug}`,
    aliases,
    signals,
  };
}

export const PC_CHAPTERS: ChapterDef[] = [
  pc(1, '01', 'ondes-mecaniques-progressives', 'Ondes mécaniques progressives', 'الموجات الميكانيكية المتوالية', ['ondes mécaniques progressives', 'ondes mécaniques', 'onde mécanique', 'الموجات الميكانيكية'], [[/onde m[ée]canique|c[ée]l[ée]rit[ée]|retard temporel/i, 2]]),
  pc(1, '02', 'ondes-mecaniques-progressives-periodiques', 'Ondes mécaniques progressives périodiques', 'الموجات الميكانيكية المتوالية الدورية', ['ondes périodiques', 'ondes mécaniques périodiques', 'الموجات الدورية'], [[/p[ée]riodiques?|longueur d'onde|\\lambda|stroboscop/i, 1.5]]),
  pc(1, '03', 'propagation-des-ondes-lumineuses', 'Propagation des ondes lumineuses', 'انتشار موجة ضوئية', ['ondes lumineuses', 'lumière', 'diffraction', 'الموجات الضوئية', 'الضوء'], [[/lumi[èe]re|lumineuse|laser|prisme|indice de r[ée]fraction/i, 2], [/diffraction|dispersion/i, 1.5]]),
  pc(1, '04', 'transformations-lentes-et-transformations-rapides', 'Transformations lentes et transformations rapides', 'التحولات السريعة والتحولات البطيئة', ['transformations lentes', 'transformations rapides', 'التحولات السريعة والبطيئة'], [[/transformations? (?:lentes?|rapides?)|oxydant|r[ée]ducteur|facteurs cin[ée]tiques/i, 2]]),
  pc(1, '05', 'suivi-temporel-d-une-transformation-chimique-vitesse-de-reaction', "Suivi temporel d'une transformation chimique – Vitesse de réaction", 'التتبع الزمني لتحول كيميائي - سرعة التفاعل', ['suivi temporel', 'vitesse de réaction', 'cinétique chimique', 'التتبع الزمني', 'سرعة التفاعل'], [[/vitesse volumique|suivi temporel|temps de demi-r[ée]action|t_\{1\/2\}/i, 3], [/avancement/i, 1]]),
  pc(1, '06', 'decroissance-radioactive', 'Décroissance radioactive', 'التناقص الإشعاعي', ['décroissance radioactive', 'radioactivité', 'radioactif', 'التناقص الإشعاعي', 'النشاط الإشعاعي'], [[/radioacti|d[ée]croissance|demi-vie|datation/i, 3], [/activit[ée]/i, 1]]),
  pc(1, '07', 'noyaux-masse-et-energie', 'Noyaux, masse et énergie', 'النوى، الكتلة والطاقة', ['noyaux masse et énergie', 'énergie nucléaire', 'fission', 'fusion', 'النوى', 'الكتلة والطاقة'], [[/[ée]nergie de liaison|d[ée]faut de masse|fission|fusion|MeV/i, 3]]),
  pc(1, '08', 'transformations-chimiques-s-effectuant-dans-les-2-sens', "Transformations chimiques s'effectuant dans les deux sens", 'التحولات الكيميائية التي تحدث في المنحيين', ['deux sens', 'quotient de réaction', 'taux d avancement final', 'المنحيين'], [[/deux sens|quotient de r[ée]action|taux d'avancement final/i, 3]]),
  pc(1, '09', 'etat-d-equilibre-d-un-systeme-chimique', "État d'équilibre d'un système chimique", 'حالة توازن مجموعة كيميائية', ["état d'équilibre", 'équilibre chimique', "constante d'équilibre", 'حالة التوازن'], [[/[ée]tat d'[ée]quilibre|constante d'[ée]quilibre/i, 3]]),
  pc(1, '10', 'dipole-rc', 'Dipôle RC', 'ثنائي القطب RC', ['dipôle rc', 'dipole rc', 'rc', 'condensateur', 'المكثف'], [[/condensateur|capacit[ée]|dip[oô]le RC|\bRC\b/i, 3]]),
  pc(1, '11', 'dipole-rl', 'Dipôle RL', 'ثنائي القطب RL', ['dipôle rl', 'dipole rl', 'rl', 'bobine', 'الوشيعة'], [[/bobine|inductance|dip[oô]le RL|\bRL\b/i, 3]]),
  pc(1, '12', 'oscillations-libres-d-un-circuit-rlc-serie', "Oscillations libres d'un circuit RLC série", 'التذبذبات الحرة في دارة RLC متوالية', ['oscillations libres', 'rlc libre', 'circuit rlc', 'rlc', 'التذبذبات الحرة'], [[/RLC|oscillations? libres?|p[ée]riode propre|amortissement/i, 2.5]]),
  pc(1, '13', 'circuit-rlc-serie-en-regime-sinusoidal-force-sm', 'Circuit RLC série en régime sinusoïdal forcé (SM)', 'دارة RLC متوالية في النظام الجيبي القسري', ['régime sinusoïdal forcé', 'rlc forcé', 'résonance', 'النظام الجيبي القسري'], [[/r[ée]gime sinuso[iï]dal|r[ée]sonance|imp[ée]dance/i, 3]]),
  pc(1, '14', 'ondes-electromagnetiques-et-modulation-d-amplitude', "Ondes électromagnétiques et modulation d'amplitude", 'الموجات الكهرمغنطيسية وتضمين الوسع', ["modulation d'amplitude", 'modulation', 'ondes électromagnétiques', 'التضمين'], [[/modulation|porteuse|d[ée]modulation|[ée]lectromagn[ée]tiques?/i, 3]]),
  pc(1, '15', 'transformations-liees-a-des-reactions-acide-base', 'Transformations liées à des réactions acide-base', 'التحولات المقرونة بالتفاعلات حمض-قاعدة', ['acide base', 'acide-base', 'ph', 'pka', 'حمض قاعدة'], [[/\bpH\b|pK_?\{?[aAeE]|acide|base conjugu[ée]e/i, 1.5]]),
  pc(1, '16', 'dosage-acido-basique', 'Dosage acido-basique', 'المعايرة الحمضية القاعدية', ['dosage acido-basique', 'dosage', 'titrage', 'المعايرة'], [[/dosage|titrage|[ée]quivalence|indicateur color[ée]/i, 3]]),
  pc(2, '17', 'lois-de-newton', 'Lois de Newton', 'قوانين نيوتن', ['lois de newton', 'newton', 'قوانين نيوتن'], [[/lois? de newton|r[ée]f[ée]rentiel galil[ée]en|centre d'inertie/i, 2.5]]),
  pc(2, '18a', 'chute-libre-d-un-corps-solide', "Chute libre d'un corps solide", 'السقوط الحر لجسم صلب', ['chute libre', 'السقوط الحر'], [[/chute libre/i, 3]]),
  pc(2, '18b', 'chute-verticale-avec-frottement', 'Chute verticale avec frottement', 'السقوط الرأسي بوجود الاحتكاك', ['chute verticale avec frottement', 'frottement', 'vitesse limite', 'الاحتكاك'], [[/frottements?|vitesse limite|m[ée]thode d'euler|pouss[ée]e d'archim[èe]de/i, 3]]),
  pc(2, '19a', 'mouvements-plans-projectile-dans-le-champ-de-pesanteur', 'Mouvements plans : projectile dans le champ de pesanteur', 'حركة قذيفة في مجال الثقالة', ['projectile', 'champ de pesanteur', 'mouvement parabolique', 'القذيفة'], [[/projectile|champ de pesanteur|port[ée]e|parabolique/i, 3]]),
  pc(2, '19b', 'mouvements-plans-particule-chargee-dans-un-champ-magnetique', 'Mouvements plans : particule chargée dans un champ magnétique', 'حركة دقيقة مشحونة في مجال مغنطيسي', ['champ magnétique', 'force de lorentz', 'المجال المغنطيسي'], [[/champ magn[ée]tique|force de lorentz/i, 3]]),
  pc(2, '19c', 'mouvements-plans-particule-chargee-dans-un-champ-electrique-sm', 'Mouvements plans : particule chargée dans un champ électrique (SM)', 'حركة دقيقة مشحونة في مجال كهربائي', ['champ électrique', 'particule chargée', 'المجال الكهربائي'], [[/champ [ée]lectrique (?:uniforme)?|plaques parall[èe]les|d[ée]flexion/i, 3]]),
  pc(2, '20', 'evolution-spontanee-d-un-systeme-chimique', "Évolution spontanée d'un système chimique", 'التطور التلقائي لمجموعة كيميائية', ['évolution spontanée', "critère d'évolution", 'التطور التلقائي'], [[/[ée]volution spontan[ée]e|crit[èe]re d'[ée]volution/i, 3]]),
  pc(2, '21', 'transformations-spontanees-dans-les-piles-et-production-d-energie', "Transformations spontanées dans les piles et production d'énergie", 'التحولات التلقائية في الأعمدة وتحصيل الطاقة', ['piles', 'pile', 'الأعمدة', 'العمود'], [[/\bpiles?\b|pont salin|force [ée]lectromotrice|anode|cathode/i, 3]]),
  pc(2, '22', 'mouvement-des-satellites-et-des-planetes', 'Mouvement des satellites et des planètes', 'حركة الأقمار الاصطناعية والكواكب', ['satellites', 'planètes', 'kepler', 'الأقمار الاصطناعية', 'الكواكب'], [[/satellite|plan[èe]te|kepler|gravitation/i, 3]]),
  pc(2, '23', 'mouvement-de-rotation-d-un-solide-autour-d-un-axe-fixe', "Mouvement de rotation d'un solide autour d'un axe fixe", 'حركة دوران جسم صلب حول محور ثابت', ['rotation', 'axe fixe', "moment d'inertie", 'حركة الدوران'], [[/moment d'inertie|axe fixe|acc[ée]l[ée]ration angulaire|abscisse angulaire/i, 3]]),
  pc(2, '24a', 'oscillateurs-mecaniques-pendule-elastique', 'Oscillateurs mécaniques : pendule élastique', 'المتذبذبات الميكانيكية: النواس المرن', ['pendule élastique', 'ressort', 'النواس المرن'], [[/pendule [ée]lastique|ressort|raideur/i, 3]]),
  pc(2, '24b', 'oscillateurs-mecaniques-pendule-pesant-simple-et-de-torsion', 'Oscillateurs mécaniques : pendule pesant, simple et de torsion', 'النواس الوازن والنواس البسيط ونواس اللي', ['pendule pesant', 'pendule simple', 'pendule de torsion', 'النواس الوازن', 'نواس اللي'], [[/pendule pesant|pendule simple|torsion/i, 3]]),
  pc(2, '25', 'transformations-forcees-electrolyse', 'Transformations forcées (électrolyse)', 'التحولات القسرية - التحليل الكهربائي', ['électrolyse', 'electrolyse', 'transformations forcées', 'التحليل الكهربائي'], [[/[ée]lectrolyse|transformations? forc[ée]es?/i, 3]]),
  pc(2, '26a', 'aspects-energetiques-pendule-elastique', 'Aspects énergétiques : pendule élastique', 'المظاهر الطاقية: النواس المرن', ['énergie du pendule élastique', 'aspects énergétiques', 'énergie mécanique', 'الطاقة الميكانيكية'], [[/[ée]nergie (?:m[ée]canique|potentielle [ée]lastique|cin[ée]tique)/i, 1.5]]),
  pc(2, '26b', 'aspects-energetiques-pendule-pesant-et-de-torsion', 'Aspects énergétiques : pendule pesant et de torsion', 'المظاهر الطاقية: النواس الوازن ونواس اللي', ['énergie du pendule pesant', 'énergie de torsion'], [[/[ée]nergie potentielle (?:de pesanteur|de torsion)/i, 2]]),
];

/* ------------------------------------------------------------------ */
/* SVT — two units                                                     */
/* ------------------------------------------------------------------ */
export const SVT_CHAPTERS: ChapterDef[] = [
  {
    key: 'transfert',
    subject: 'svt',
    number: 'U1',
    title: "Transfert de l'information génétique au cours de la reproduction sexuée",
    titleAr: 'نقل الخبر الوراثي عبر التوالد الجنسي',
    dir: 'svt/transfert-information-genetique-reproduction-sexuee',
    aliases: ["transfert de l'information génétique", 'reproduction sexuée', 'méiose', 'brassage', 'monohybridisme', 'dihybridisme', 'نقل الخبر الوراثي', 'التوالد الجنسي', 'الانقسام الاختزالي'],
    signals: [[/m[ée]iose/i, 3], [/f[ée]condation/i, 2], [/brassage/i, 3], [/crossing-?over|enjambement/i, 3], [/all[èe]les?/i, 1.5], [/croisements?/i, 2], [/monohybrid|dihybrid|test-cross|back-cross/i, 3], [/carte factorielle|g[èe]nes? li[ée]s/i, 3]],
  },
  {
    key: 'populations',
    subject: 'svt',
    number: 'U2',
    title: 'Variation et génétique des populations',
    titleAr: 'التغيرات وعلم وراثة الساكنة',
    dir: 'svt/variation-et-genetique-des-populations',
    aliases: ['génétique des populations', 'genetique des populations', 'population', 'hardy weinberg', 'hardy-weinberg', 'وراثة الساكنة', 'الساكنة'],
    signals: [[/populations?/i, 2], [/hardy|weinberg/i, 4], [/fr[ée]quences? (?:all[ée]liques?|g[ée]notypiques?)/i, 3], [/d[ée]rive g[ée]n[ée]tique/i, 3], [/s[ée]lection naturelle/i, 3], [/mutations?/i, 1], [/sp[ée]ciation/i, 1.5]],
  },
];

export const STATIC_CHAPTERS: Record<SubjectId, ChapterDef[]> = {
  mathematiques: MATH_CHAPTERS,
  'physique-chimie': PC_CHAPTERS,
  svt: SVT_CHAPTERS,
};

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

/** Lower-case, strip Latin accents and Arabic diacritics, unify alef / taa marbuta / digits. */
export function normalizeForMatch(input: string): string {
  return input
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
    .normalize('NFD')
    .replace(/\p{M}+/gu, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/ـ/g, '')
    .replace(/[’`]/g, "'")
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

export function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function humanizeSlug(slug: string): string {
  const s = slug
    .replace(/-/g, ' ')
    .replace(/\b([dl]) (?=[aeiouyh])/g, "$1'")
    .replace(/\s+/g, ' ')
    .trim();
  return s.charAt(0).toUpperCase() + s.slice(1);
}

/** Static chapters + chapters discovered in the repository index (PC 27–29, extra SVT units…). */
export function listChapters(subject: SubjectId, index: string[] | null): ChapterDef[] {
  const base = STATIC_CHAPTERS[subject];
  if (!index || subject === 'mathematiques') return base;

  if (subject === 'physique-chimie') {
    const known = new Set(base.map((c) => c.key));
    const extra = new Map<string, ChapterDef>();
    const re = /^physique-chimie\/semestre-([12])\/((\d{2}[a-z]?)-(.+?))-(?:cours|exos)\.txt$/;
    for (const p of index) {
      const m = re.exec(p);
      if (!m) continue;
      const key = m[3];
      if (known.has(key) || extra.has(key)) continue;
      const title = humanizeSlug(m[4]);
      extra.set(key, {
        key,
        subject,
        number: key,
        title,
        titleAr: '',
        dir: `physique-chimie/semestre-${m[1]}`,
        filePrefix: m[2],
        aliases: [title.toLowerCase()],
        signals: [],
        discovered: true,
      });
    }
    return [...base, ...extra.values()].sort((a, b) => a.key.localeCompare(b.key, 'fr', { numeric: true }));
  }

  // SVT: any extra unit directory.
  const knownDirs = new Set(base.map((c) => c.dir));
  const extra = new Map<string, ChapterDef>();
  for (const p of index) {
    const m = /^svt\/([^/]+)\/.+\.txt$/.exec(p);
    if (!m) continue;
    const dir = `svt/${m[1]}`;
    if (m[1] === 'devoirs' || m[1] === 'examens-nationaux' || knownDirs.has(dir) || extra.has(dir)) continue;
    extra.set(dir, {
      key: m[1],
      subject,
      number: `U${base.length + extra.size + 1}`,
      title: humanizeSlug(m[1]),
      titleAr: '',
      dir,
      aliases: [humanizeSlug(m[1]).toLowerCase()],
      signals: [],
      discovered: true,
    });
  }
  return [...base, ...extra.values()];
}

export function findChapter(subject: SubjectId, key: string, index: string[] | null = null): ChapterDef | undefined {
  return listChapters(subject, index).find((c) => c.key === key);
}

const aliasCache = new WeakMap<ChapterDef, string[]>();
function normalizedAliases(def: ChapterDef): string[] {
  let a = aliasCache.get(def);
  if (!a) {
    a = def.aliases.map(normalizeForMatch).filter((x) => x.length >= 2);
    aliasCache.set(def, a);
  }
  return a;
}

/** Longest alias found in the text wins (short aliases such as "rc" / "ln" need word boundaries). */
export function matchChapterByAlias(
  subject: SubjectId,
  text: string,
  chapters: ChapterDef[] = STATIC_CHAPTERS[subject],
): ChapterDef | undefined {
  const t = ` ${normalizeForMatch(text)} `;
  let best: { def: ChapterDef; len: number } | undefined;
  for (const def of chapters) {
    for (const alias of normalizedAliases(def)) {
      const found =
        alias.length <= 3
          ? new RegExp(`(^|[^\\p{L}\\p{N}])${escapeRegExp(alias)}([^\\p{L}\\p{N}]|$)`, 'u').test(t)
          : t.includes(alias);
      if (found && (!best || alias.length > best.len)) best = { def, len: alias.length };
    }
  }
  return best?.def;
}

const globalCache = new WeakMap<RegExp, RegExp>();
function countMatches(text: string, re: RegExp, cap = 12): number {
  let g = globalCache.get(re);
  if (!g) {
    g = new RegExp(re.source, re.flags.includes('g') ? re.flags : `${re.flags}g`);
    globalCache.set(re, g);
  }
  g.lastIndex = 0;
  let n = 0;
  let m: RegExpExecArray | null;
  while ((m = g.exec(text)) !== null) {
    if (m[0] === '') g.lastIndex++;
    n++;
    if (n >= cap) break;
  }
  return n;
}

/** Rank the chapters of a subject by how strongly a text (e.g. an exam exercise) matches them. */
export function scoreChapters(
  subject: SubjectId,
  text: string,
  chapters: ChapterDef[] = STATIC_CHAPTERS[subject],
): Array<{ chapter: ChapterDef; score: number }> {
  return chapters
    .map((chapter) => ({
      chapter,
      score: chapter.signals.reduce((sum, [re, w]) => sum + countMatches(text, re) * w, 0),
    }))
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score);
}
