/**
 * Chalk illustration library for the blackboard.
 *
 * Every preset is authored in a 0–100 unit square (y grows downward) and is
 * normalised onto the board by svgPath.fitTransform, so the model only has to
 * supply a name plus an optional position/scale/rotation.
 */
import { bboxOf, parseSvgPath, type ParsedSvgPath } from './svgPath';

export interface IllustrationPreset {
  paths: string[];
  /** Short French description surfaced to the model in the system prompt. */
  hint: string;
}

const r1 = (n: number) => (Math.round(n * 10) / 10).toString();

/** Sampled sinusoid, used for waves, springs and the DNA backbone. */
function sine(cx: number, amplitude: number, y0: number, y1: number, phase: number, periods: number): string {
  const steps = 40;
  const out: string[] = [];
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const y = y0 + (y1 - y0) * t;
    const x = cx + amplitude * Math.sin(2 * Math.PI * (t * periods + phase));
    out.push(`${i === 0 ? 'M' : 'L'} ${r1(x)} ${r1(y)}`);
  }
  return out.join(' ');
}

/** Anti-phase double helix with base-pair rungs. */
function dnaPaths(): string[] {
  const y0 = 6;
  const y1 = 94;
  const amplitude = 20;
  const periods = 2.5;
  const paths = [sine(50, amplitude, y0, y1, 0, periods), sine(50, amplitude, y0, y1, 0.5, periods)];
  for (let i = 1; i < 10; i++) {
    const t = i / 10;
    const y = y0 + (y1 - y0) * t;
    const x1 = 50 + amplitude * Math.sin(2 * Math.PI * (t * periods));
    const x2 = 50 + amplitude * Math.sin(2 * Math.PI * (t * periods + 0.5));
    if (Math.abs(x2 - x1) < 4) continue;
    paths.push(`M ${r1(x1)} ${r1(y)} L ${r1(x2)} ${r1(y)}`);
  }
  return paths;
}

/** Closed circle built from four cubic arcs (no SVG arc command needed). */
function circle(cx: number, cy: number, radius: number): string {
  const k = radius * 0.5523;
  return [
    `M ${r1(cx - radius)} ${r1(cy)}`,
    `C ${r1(cx - radius)} ${r1(cy - k)} ${r1(cx - k)} ${r1(cy - radius)} ${r1(cx)} ${r1(cy - radius)}`,
    `C ${r1(cx + k)} ${r1(cy - radius)} ${r1(cx + radius)} ${r1(cy - k)} ${r1(cx + radius)} ${r1(cy)}`,
    `C ${r1(cx + radius)} ${r1(cy + k)} ${r1(cx + k)} ${r1(cy + radius)} ${r1(cx)} ${r1(cy + radius)}`,
    `C ${r1(cx - k)} ${r1(cy + radius)} ${r1(cx - radius)} ${r1(cy + k)} ${r1(cx - radius)} ${r1(cy)} Z`,
  ].join(' ');
}

/** Smooth parametric curve sampled into a single cubic-spline path. */
function plot(fn: (x: number) => number, x0: number, x1: number, steps = 46, clampTo = 96): string {
  const pts: Array<[number, number]> = [];
  for (let i = 0; i <= steps; i++) {
    const x = x0 + ((x1 - x0) * i) / steps;
    const y = fn(x);
    if (!Number.isFinite(y) || y < -clampTo * 3 || y > clampTo * 3) continue;
    pts.push([x, Math.max(-clampTo, Math.min(clampTo, y))]);
  }
  return spline(pts);
}

/** Catmull-Rom → Bézier, so sampled curves read as one fluid chalk sweep. */
function spline(pts: Array<[number, number]>): string {
  if (pts.length < 2) return '';
  let d = `M ${r1(pts[0][0])} ${r1(pts[0][1])}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[Math.max(0, i - 1)];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[Math.min(pts.length - 1, i + 2)];
    const c1x = p1[0] + (p2[0] - p0[0]) / 6;
    const c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6;
    const c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += ` C ${r1(c1x)} ${r1(c1y)}, ${r1(c2x)} ${r1(c2y)}, ${r1(p2[0])} ${r1(p2[1])}`;
  }
  return d;
}

/** Reusable framed Cartesian axes (origin at 14,86) with arrow tips. */
const AXES_FRAME = [
  'M 14 6 L 14 86 L 96 86',
  'M 14 6 L 10.5 13 M 14 6 L 17.5 13',
  'M 96 86 L 89 82.5 M 96 86 L 89 89.5',
];

/** A small chalk arrowhead at (x,y) pointing along (dx,dy). */
function head(x: number, y: number, dx: number, dy: number, len = 7): string {
  const a = Math.atan2(dy, dx);
  const w = 0.5;
  return `M ${r1(x - Math.cos(a - w) * len)} ${r1(y - Math.sin(a - w) * len)} L ${r1(x)} ${r1(y)} L ${r1(x - Math.cos(a + w) * len)} ${r1(y - Math.sin(a + w) * len)}`;
}

/** Straight vector: shaft plus arrowhead, used by the physics schemas. */
function vector(x1: number, y1: number, x2: number, y2: number): string[] {
  return [`M ${r1(x1)} ${r1(y1)} L ${r1(x2)} ${r1(y2)}`, head(x2, y2, x2 - x1, y2 - y1)];
}

export const ILLUSTRATION_LIBRARY: Record<string, IllustrationPreset> = {
  car: {
    hint: 'car: body, two wheels, road',
    paths: [
      'M 8 66 L 8 54 Q 8 47 15 46 L 30 46 L 43 30 Q 47 25 54 25 L 70 25 Q 79 25 85 33 L 93 45 Q 96 50 96 56 L 96 66 Z',
      circle(31, 66, 11),
      circle(73, 66, 11),
      'M 4 80 L 96 80',
    ],
  },
  tree: {
    hint: 'tree: trunk, branches, foliage, ground',
    paths: [
      'M 44 92 L 46 66 L 54 66 L 56 92',
      'M 50 10 C 63 10 71 19 71 29 C 80 32 84 41 81 50 C 78 59 69 62 61 59 C 55 63 43 63 37 59 C 29 62 20 59 18 50 C 15 41 19 32 28 29 C 28 19 37 10 50 10 Z',
      'M 46 78 L 30 68',
      'M 54 78 L 70 68',
      'M 8 92 L 92 92',
    ],
  },
  human_stick: {
    hint: 'human stick figure: head, trunk, arms, legs',
    paths: [
      circle(50, 16, 10),
      'M 50 26 L 50 58',
      'M 30 42 L 50 34 L 70 42',
      'M 50 58 L 36 88',
      'M 50 58 L 64 88',
      'M 16 92 L 84 92',
    ],
  },
  pulley: {
    hint: 'fixed pulley: support, wheel, rope, hanging load',
    paths: [
      'M 8 12 L 92 12',
      'M 18 12 L 24 18 M 26 12 L 32 18 M 34 12 L 40 18 M 60 12 L 66 18 M 68 12 L 74 18 M 76 12 L 82 18',
      'M 50 12 L 50 32',
      circle(50, 46, 14),
      'M 36 46 L 36 74',
      'M 64 46 L 64 70',
      'M 54 70 L 74 70 L 74 86 L 54 86 Z',
    ],
  },
  battery: {
    hint: 'battery / cell symbol with wires and + pole',
    paths: [
      'M 6 50 L 32 50',
      'M 32 32 L 32 68',
      'M 46 42 L 46 58',
      'M 46 50 L 94 50',
      'M 20 22 L 20 34 M 14 28 L 26 28',
    ],
  },
  dna: { hint: 'DNA double helix with base pairs', paths: dnaPaths() },
  incline: {
    hint: 'inclined plane with a block and sliding arrow',
    paths: [
      'M 6 86 L 94 86',
      'M 12 86 L 66 40 L 66 86',
      'M 28 54 L 44 38 L 52 46 L 36 62 Z',
      'M 44 38 L 60 26',
      'M 60 26 L 52 27 M 60 26 L 56 34',
      'M 26 86 Q 28 77 35 72',
    ],
  },
  inclined_plane: {
    hint: 'inclined plane: slope angle, sliding block, and motion arrow',
    paths: [
      'M 6 86 L 94 86',
      'M 12 86 L 68 42 L 68 86',
      'M 28 55 L 44 40 L 52 48 L 36 63 Z',
      'M 44 40 L 60 28',
      'M 60 28 L 52 29 M 60 28 L 56 36',
      'M 26 86 Q 28 77 35 72',
    ],
  },
  stick_pushing: {
    hint: 'stick figure pushing a block with forward force arrow',
    paths: [
      'M 6 88 L 94 88',
      'M 58 50 L 86 50 L 86 88 L 58 88 Z',
      circle(28, 28, 8),
      'M 30 36 L 42 62',
      'M 42 62 L 32 88',
      'M 42 62 L 48 88',
      'M 34 46 L 58 56',
      ...vector(62, 40, 82, 40),
    ],
  },
  lens: {
    hint: 'converging optical lens with axis, focal points and a ray',
    paths: [
      'M 6 50 L 94 50',
      'M 50 20 C 39 34 39 66 50 80 C 61 66 61 34 50 20 Z',
      'M 28 43 L 28 57',
      'M 72 43 L 72 57',
      'M 8 30 L 50 30',
      'M 50 30 L 92 50',
      'M 92 50 L 82 49 M 92 50 L 84 56',
    ],
  },
  cell: {
    hint: 'animal cell: membrane, nucleus, mitochondria, vacuole',
    paths: [
      circle(50, 50, 44),
      circle(40, 44, 13),
      'M 66 66 C 74 62 82 68 80 76 C 78 83 70 83 66 76 C 63 71 63 68 66 66 Z',
      'M 62 26 C 70 24 76 30 74 36 C 72 43 64 43 61 37 C 59 32 59 28 62 26 Z',
    ],
  },
  spring: {
    hint: 'helical spring between two supports',
    paths: [
      'M 8 8 L 8 92',
      sine(50, 16, 14, 86, 0, 6),
      'M 92 8 L 92 92',
      'M 8 50 L 34 50',
      'M 66 50 L 92 50',
    ],
  },
  resistor: {
    hint: 'resistor: zigzag between two wires',
    paths: [
      'M 6 50 L 26 50 L 32 36 L 44 64 L 56 36 L 68 64 L 74 50 L 94 50',
    ],
  },
  bulb: {
    hint: 'lamp bulb: circle with cross, between two wires',
    paths: [
      'M 6 50 L 32 50',
      circle(50, 50, 18),
      'M 38 38 L 62 62',
      'M 62 38 L 38 62',
      'M 68 50 L 94 50',
    ],
  },
  capacitor: {
    hint: 'capacitor: two parallel plates with wires',
    paths: [
      'M 6 50 L 42 50',
      'M 42 30 L 42 70',
      'M 56 30 L 56 70',
      'M 56 50 L 94 50',
    ],
  },
  axes: {
    hint: 'Cartesian axes x and y with arrowheads',
    paths: [...AXES_FRAME],
  },
  parabola: {
    hint: 'axes + parabola y=x^2 (convex curve through the origin)',
    paths: [...AXES_FRAME, plot((x) => 86 - 0.026 * (x - 55) ** 2 * 1.9, 24, 86)],
  },
  function_curve: {
    hint: 'Cartesian axes with smooth function curve f(x), limit l, and guide coordinates',
    paths: [
      ...AXES_FRAME,
      plot((x) => 24 + 320 / (x - 6), 22, 94),
      // Horizontal asymptote y = l (dashed guide)
      'M 14 26 L 22 26 M 28 26 L 36 26 M 42 26 L 50 26 M 56 26 L 64 26 M 70 26 L 78 26 M 84 26 L 94 26',
      // Vertical guide x = x0
      'M 42 45 L 42 53 M 42 59 L 42 67 M 42 73 L 42 86',
      circle(42, 45, 2.4),
    ],
  },
  curve_limit: {
    hint: 'axes + curve approaching a horizontal limit l with dashed guides (use for limits)',
    paths: [
      ...AXES_FRAME,
      plot((x) => 26 + 340 / (x - 6), 22, 94),
      // Horizontal asymptote y = l, drawn as a dashed chalk guide.
      'M 14 26 L 22 26 M 28 26 L 36 26 M 42 26 L 50 26 M 56 26 L 64 26 M 70 26 L 78 26 M 84 26 L 94 26',
    ],
  },
  curve_point: {
    hint: 'axes + curve with dashed guides meeting at the point (x0, l) — the epsilon/alpha picture',
    paths: [
      ...AXES_FRAME,
      plot((x) => 88 - 0.9 * (x - 14) + 0.0075 * (x - 14) ** 2, 16, 92),
      'M 14 42 L 22 42 M 28 42 L 36 42 M 42 42 L 50 42',
      'M 52 42 L 52 50 M 52 56 L 52 64 M 52 70 L 52 78 M 52 84 L 52 86',
    ],
  },
  asymptote: {
    hint: 'axes + hyperbola with a vertical asymptote',
    paths: [
      ...AXES_FRAME,
      'M 52 8 L 52 16 M 52 22 L 52 30 M 52 36 L 52 44 M 52 50 L 52 58 M 52 64 L 52 72 M 52 78 L 52 86',
      plot((x) => 66 + 260 / (x - 52), 56, 94),
      plot((x) => 66 - 260 / (52 - x), 16, 48),
    ],
  },
  tangent: {
    hint: 'axes + curve with its tangent line at one point (use for la dérivée)',
    paths: [
      ...AXES_FRAME,
      plot((x) => 84 - 0.02 * (x - 20) ** 2 * 1.3, 18, 90),
      'M 26 74 L 88 34',
      circle(56, 54, 2.4),
    ],
  },
  sequence: {
    hint: 'axes + sequence terms as dots converging to a horizontal limit',
    paths: [
      ...AXES_FRAME,
      'M 14 32 L 24 32 M 30 32 L 40 32 M 46 32 L 56 32 M 62 32 L 72 32 M 78 32 L 94 32',
      ...[0, 1, 2, 3, 4, 5, 6].map((i) => {
        const x = 24 + i * 10;
        const y = 32 + 40 / (i + 1.35);
        return circle(x, y, 2.1);
      }),
    ],
  },
  argand: {
    hint: 'Argand plane: complex point M(z) with its modulus vector and angle arc',
    paths: [
      'M 14 6 L 14 86 L 96 86',
      'M 14 6 L 10.5 13 M 14 6 L 17.5 13',
      'M 96 86 L 89 82.5 M 96 86 L 89 89.5',
      ...vector(14, 86, 66, 30),
      circle(66, 30, 2.4),
      'M 66 30 L 66 86',
      'M 38 86 A 24 24 0 0 0 31 69',
    ],
  },
  forces: {
    hint: 'inclined plane with a block and the three force vectors P, R, F',
    paths: [
      'M 8 86 L 96 86',
      'M 14 86 L 74 40 L 74 86',
      'M 34 60 L 50 48 L 58 58 L 42 70 Z',
      ...vector(46, 59, 46, 88),
      ...vector(46, 59, 34, 44),
      ...vector(46, 59, 70, 41),
    ],
  },
  rc_circuit: {
    hint: 'RC series circuit: battery, resistor and capacitor in a closed loop',
    paths: [
      'M 12 22 L 88 22 M 88 22 L 88 78 M 88 78 L 12 78 M 12 78 L 12 22',
      // Battery (left branch).
      'M 6 44 L 12 44 M 6 56 L 12 56',
      'M 4 44 L 4 56 M 12 40 L 12 48 M 12 52 L 12 60',
      // Resistor (top, zigzag).
      'M 34 22 L 39 14 L 46 30 L 53 14 L 60 30 L 65 22',
      // Capacitor (right branch, two plates).
      'M 88 44 L 88 46 M 80 46 L 96 46 M 80 54 L 96 54 M 88 54 L 88 56',
    ],
  },
  rl_circuit: {
    hint: 'RL series circuit: battery, resistor and a coil (inductor)',
    paths: [
      'M 12 22 L 88 22 M 88 22 L 88 78 M 88 78 L 12 78 M 12 78 L 12 22',
      'M 6 44 L 12 44 M 6 56 L 12 56',
      'M 4 44 L 4 56 M 12 40 L 12 48 M 12 52 L 12 60',
      'M 34 22 L 39 14 L 46 30 L 53 14 L 60 30 L 65 22',
      // Coil: four half loops on the right branch.
      'M 88 38 A 6 6 0 1 1 88 50 A 6 6 0 1 1 88 62',
    ],
  },
  trajectory: {
    hint: 'projectile trajectory: parabolic arc with launch and velocity vectors',
    paths: [
      'M 8 86 L 96 86',
      plot((x) => 86 - 0.052 * (x - 14) * (92 - x) * 1.35, 14, 92, 40),
      ...vector(14, 86, 32, 62),
      ...vector(53, 36, 72, 44),
    ],
  },
  wave: {
    hint: 'transverse wave with propagation axis',
    paths: [
      'M 6 50 L 94 50',
      sine(50, 26, 20, 80, 0, 2),
      'M 76 50 L 94 50',
      'M 94 50 L 86 46 M 94 50 L 86 54',
    ],
  },
};

const ALIASES: Record<string, string> = {
  voiture: 'car',
  car: 'car',
  arbre: 'tree',
  tree: 'tree',
  bonhomme: 'human_stick',
  personne: 'human_stick',
  human: 'human_stick',
  stick: 'human_stick',
  humanstick: 'human_stick',
  poulie: 'pulley',
  pulley: 'pulley',
  pile: 'battery',
  batterie: 'battery',
  battery: 'battery',
  adn: 'dna',
  dna: 'dna',
  planincline: 'inclined_plane',
  inclinedplane: 'inclined_plane',
  inclined_plane: 'inclined_plane',
  incline: 'inclined_plane',
  functioncurve: 'function_curve',
  function_curve: 'function_curve',
  courbefonction: 'function_curve',
  courbe: 'function_curve',
  stickpushing: 'stick_pushing',
  stick_pushing: 'stick_pushing',
  lentille: 'lens',
  lens: 'lens',
  cellule: 'cell',
  cell: 'cell',
  ressort: 'spring',
  spring: 'spring',
  resistance: 'resistor',
  resistor: 'resistor',
  lampe: 'bulb',
  bulb: 'bulb',
  ampoule: 'bulb',
  condensateur: 'capacitor',
  capacitor: 'capacitor',
  axes: 'axes',
  repere: 'axes',
  onde: 'wave',
  wave: 'wave',
  parabole: 'parabola',
  parabola: 'parabola',
  courbelimite: 'curve_limit',
  curvelimit: 'curve_limit',
  limite: 'curve_limit',
  limit: 'curve_limit',
  curvepoint: 'curve_point',
  epsilonalpha: 'curve_point',
  asymptote: 'asymptote',
  hyperbole: 'asymptote',
  tangente: 'tangent',
  tangent: 'tangent',
  derivee: 'tangent',
  suite: 'sequence',
  sequence: 'sequence',
  argand: 'argand',
  complexe: 'argand',
  forces: 'forces',
  force: 'forces',
  planinclineforces: 'forces',
  rccircuit: 'rc_circuit',
  circuitrc: 'rc_circuit',
  rc: 'rc_circuit',
  rlcircuit: 'rl_circuit',
  circuitrl: 'rl_circuit',
  rl: 'rl_circuit',
  trajectoire: 'trajectory',
  trajectory: 'trajectory',
};

const normalize = (name: string) => name.toLowerCase().replace(/[^a-z]/g, '');

/** Resolve a model-supplied illustration name to a preset (tolerant matching). */
export function resolveIllustration(name: string): { key: string; preset: IllustrationPreset } | null {
  const key = normalize(name);
  if (!key) return null;
  const direct = ALIASES[key];
  if (direct && ILLUSTRATION_LIBRARY[direct]) return { key: direct, preset: ILLUSTRATION_LIBRARY[direct] };
  const prefix = Object.keys(ALIASES).find((alias) => alias.length > 3 && key.startsWith(alias));
  if (prefix && ILLUSTRATION_LIBRARY[ALIASES[prefix]]) {
    return { key: ALIASES[prefix], preset: ILLUSTRATION_LIBRARY[ALIASES[prefix]] };
  }
  return null;
}

export const ILLUSTRATION_NAMES = Object.keys(ILLUSTRATION_LIBRARY);

/** One-line catalogue injected into the Gemini system instruction. */
export function illustrationCatalogue(): string {
  return ILLUSTRATION_NAMES.map((name) => `${name} (${ILLUSTRATION_LIBRARY[name].hint})`).join('; ');
}

const cache = new Map<string, ParsedSvgPath>();

/** Parsed, bbox-merged artwork for a preset (cached across renders). */
export function parseIllustration(key: string): ParsedSvgPath | null {
  const preset = ILLUSTRATION_LIBRARY[key];
  if (!preset) return null;
  const hit = cache.get(key);
  if (hit) return hit;
  const parsed = preset.paths.map((d) => parseSvgPath(d));
  const merged: ParsedSvgPath = {
    segments: parsed.flatMap((p) => p.segments),
    bbox: bboxOf(parsed.map((p) => p.bbox)),
  };
  cache.set(key, merged);
  return merged;
}
