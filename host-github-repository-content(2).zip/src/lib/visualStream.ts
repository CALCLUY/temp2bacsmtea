import { boardActionFromParts, CHECK_TAG, type ParsedBoardAction, type ParsedQcm, type ParsedTerm } from './interaction';
import { qcmFromToolArgs, termFromToolArgs } from './liveTools';

export type VisualEvent =
  | { kind: 'board'; action: ParsedBoardAction }
  | { kind: 'qcm'; qcm: ParsedQcm }
  | { kind: 'term'; term: ParsedTerm }
  | { kind: 'check' };

/**
 * Small incremental parser for Gemini modelTurn.parts[].text.
 * A payload is dispatched as soon as its closing brace arrives — not at
 * turnComplete. Partial JSON and free-form transcript text are NEVER rendered.
 */
export class VisualJsonStream {
  private object = '';
  private depth = 0;
  private quoted = false;
  private escaped = false;
  private tail = '';
  private readonly maxObject = 100_000;

  push(chunk: string): VisualEvent[] {
    const events: VisualEvent[] = [];
    for (const ch of chunk) {
      if (this.depth === 0) {
        if (ch === '{') {
          this.object = '{';
          this.depth = 1;
          this.quoted = false;
          this.escaped = false;
          this.tail = '';
        } else {
          this.tail = (this.tail + ch).slice(-CHECK_TAG.length);
          if (this.tail === CHECK_TAG) {
            events.push({ kind: 'check' });
            this.tail = '';
          }
        }
        continue;
      }

      this.object += ch;
      if (this.object.length > this.maxObject) {
        this.reset();
        continue;
      }
      if (this.quoted) {
        if (this.escaped) this.escaped = false;
        else if (ch === '\\') this.escaped = true;
        else if (ch === '"') this.quoted = false;
      } else if (ch === '"') this.quoted = true;
      else if (ch === '{') this.depth++;
      else if (ch === '}') this.depth--;

      if (this.depth === 0) {
        try {
          const payload: unknown = JSON.parse(this.object);
          events.push(...this.decode(payload));
        } catch {
          // Malformed JSON is discarded, never printed as a chat response.
        }
        this.object = '';
      }
    }
    return events;
  }

  reset() {
    this.object = '';
    this.depth = 0;
    this.quoted = false;
    this.escaped = false;
    this.tail = '';
  }

  private decode(payload: unknown): VisualEvent[] {
    if (Array.isArray(payload)) return payload.flatMap((entry) => this.decode(entry));
    if (!payload || typeof payload !== 'object') return [];
    const obj = payload as Record<string, unknown>;
    const action = typeof obj.action === 'string' ? obj.action : '';
    const type = typeof obj.type === 'string' ? obj.type : '';

    if (action === 'blackboard_draw' || action === 'blackboard_annotate' || action === 'blackboard_write_line' || action === 'blackboard_write' || action === 'blackboard_clear') {
      const board = boardActionFromParts(action, obj);
      return board ? [{ kind: 'board', action: board }] : [];
    }
    if (type === 'qcm' || action === 'ask_qcm') {
      const qcm = qcmFromToolArgs(obj);
      return qcm ? [{ kind: 'qcm', qcm }] : [];
    }
    if (type === 'term' || action === 'introduce_term') {
      const term = termFromToolArgs(obj);
      return term ? [{ kind: 'term', term }] : [];
    }
    if (type === 'check_understanding' || action === 'check_understanding') return [{ kind: 'check' }];
    return [];
  }
}
