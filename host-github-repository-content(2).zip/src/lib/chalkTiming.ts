/** Keep the CSS animation and the Live tool-response delay in sync. */
export function chalkWritingMs(text: string): number {
  const chars = [...text].length;
  const stepped = /\$|\\|[=^_{}]|[\u0600-\u06ff]/.test(text);
  if (stepped) return Math.max(550, Math.min(2700, Math.max(12, Math.min(100, chars)) * 36));
  const interval = Math.max(14, Math.min(31, Math.floor(1600 / Math.max(chars, 1))));
  return Math.max(180, Math.min(2300, chars * interval));
}