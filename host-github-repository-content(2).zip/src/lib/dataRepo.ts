/**
 * Read-only access to github.com/CALCLUY/data-2bac-sma from the browser.
 *
 * - The exact file list comes from the GitHub git-tree API (1 request, cached 6 h),
 *   so chapter folders and exam files are resolved by their REAL names.
 * - File contents come from raw.githubusercontent.com (CORS-enabled, cached in memory).
 */
import { DATA_REPO } from './dataset';

export const RAW_BASE = `https://raw.githubusercontent.com/${DATA_REPO.owner}/${DATA_REPO.repo}/${DATA_REPO.branch}/${DATA_REPO.root}`;
export const BLOB_BASE = `https://github.com/${DATA_REPO.owner}/${DATA_REPO.repo}/blob/${DATA_REPO.branch}/${DATA_REPO.root}`;
const TREE_URL = `https://api.github.com/repos/${DATA_REPO.owner}/${DATA_REPO.repo}/git/trees/${DATA_REPO.branch}?recursive=1`;
const CACHE_KEY = 'data-2bac-sma:tree:v1';
const CACHE_TTL_MS = 6 * 60 * 60 * 1000;

let memoryIndex: string[] | null = null;
let indexPromise: Promise<string[] | null> | null = null;

function encodePath(path: string): string {
  return path.split('/').map(encodeURIComponent).join('/');
}

export const rawUrl = (path: string) => `${RAW_BASE}/${encodePath(path)}`;
export const blobUrl = (path: string) => `${BLOB_BASE}/${encodePath(path)}`;

/** Synchronous peek (null until loadRepoIndex() resolved once). */
export function peekRepoIndex(): string[] | null {
  return memoryIndex;
}

/**
 * Repository-relative paths (relative to ./2bac-data-sma/) of every file in the dataset,
 * or null when GitHub's API is unreachable (static fallbacks are used then).
 */
export function loadRepoIndex(): Promise<string[] | null> {
  if (memoryIndex) return Promise.resolve(memoryIndex);
  if (indexPromise) return indexPromise;

  indexPromise = (async () => {
    try {
      const cached = localStorage.getItem(CACHE_KEY);
      if (cached) {
        const parsed = JSON.parse(cached) as { ts?: number; files?: unknown };
        if (parsed && Array.isArray(parsed.files) && typeof parsed.ts === 'number' && Date.now() - parsed.ts < CACHE_TTL_MS) {
          memoryIndex = parsed.files as string[];
          return memoryIndex;
        }
      }
    } catch {
      /* ignore corrupted cache */
    }

    try {
      const res = await fetch(TREE_URL);
      if (!res.ok) throw new Error(`GitHub tree HTTP ${res.status}`);
      const json = (await res.json()) as { tree?: Array<{ path?: string; type?: string }> };
      const prefix = `${DATA_REPO.root}/`;
      const files = (json.tree ?? [])
        .filter((e) => e.type === 'blob' && typeof e.path === 'string' && e.path.startsWith(prefix))
        .map((e) => (e.path as string).slice(prefix.length));
      memoryIndex = files;
      try {
        localStorage.setItem(CACHE_KEY, JSON.stringify({ ts: Date.now(), files }));
      } catch {
        /* storage full / private mode */
      }
      return files;
    } catch (err) {
      console.warn('[data-2bac-sma] repository index unavailable — using static fallbacks', err);
      indexPromise = null; // allow a retry later
      return null;
    }
  })();

  return indexPromise;
}

const textCache = new Map<string, Promise<string>>();

/** Fetch a dataset file (path relative to ./2bac-data-sma/). Throws on HTTP errors. */
export function fetchDataFile(path: string): Promise<string> {
  const hit = textCache.get(path);
  if (hit) return hit;
  const p = fetch(rawUrl(path)).then(async (res) => {
    if (!res.ok) throw new Error(`HTTP ${res.status} — ${path}`);
    return res.text();
  });
  textCache.set(path, p);
  p.catch(() => textCache.delete(path));
  return p;
}

/** Split the "--- key: value ---" header used by the dataset files. */
export function parseFrontMatter(text: string): { meta: Record<string, string>; body: string } {
  const m = /^\uFEFF?---[ \t]*\r?\n([\s\S]*?)\r?\n---[ \t]*(?:\r?\n|$)/.exec(text);
  if (!m) return { meta: {}, body: text };
  const meta: Record<string, string> = {};
  for (const line of m[1].split(/\r?\n/)) {
    const i = line.indexOf(':');
    if (i > 0) meta[line.slice(0, i).trim()] = line.slice(i + 1).trim();
  }
  return { meta, body: text.slice(m[0].length) };
}

/** Run async work with a concurrency limit, preserving order. */
export async function mapLimit<T, R>(items: T[], limit: number, fn: (item: T, index: number) => Promise<R>): Promise<R[]> {
  const out = new Array<R>(items.length);
  let next = 0;
  const workers = Array.from({ length: Math.max(1, Math.min(limit, items.length)) }, async () => {
    while (next < items.length) {
      const i = next++;
      out[i] = await fn(items[i], i);
    }
  });
  await Promise.all(workers);
  return out;
}

/** Resolve with `fallback` if the promise takes longer than `ms` or rejects. */
export function withTimeout<T>(p: Promise<T>, ms: number, fallback: T): Promise<T> {
  return new Promise((resolve) => {
    const timer = setTimeout(() => resolve(fallback), ms);
    p.then(
      (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      () => {
        clearTimeout(timer);
        resolve(fallback);
      },
    );
  });
}
