/**
 * STRICT chapter lock.
 *
 * When the student selects a chapter, the app loads the chapter's REAL files from
 * ./2bac-data-sma/{dir}/ (exact names from the repository index), injects them into
 * the system instruction together with the directory → chapter mapping, the list
 * of forbidden (other) chapters and the related Examen National exercises.
 * This removes the old topic drift ("Chapitre 1" explained as geometry).
 */
import { SUBJECT_PROFILES, type SubjectId } from './dataset';
import { findChapter, STATIC_CHAPTERS, type ChapterDef } from './curriculum';
import { fetchDataFile, loadRepoIndex, mapLimit, parseFrontMatter, withTimeout } from './dataRepo';
import { findRelatedExams, SESSION_LABEL, type RelatedExam } from './examRetrieval';

export type ChapterFileKind = 'cours' | 'exercices' | 'synthese' | 'autre';

export interface ChapterFile {
  path: string;
  name: string;
  kind: ChapterFileKind;
  chars: number;
  text: string;
}

export interface LoadedChapterContext {
  subject: SubjectId;
  chapter: ChapterDef;
  files: ChapterFile[];
  missing: string[];
  source: 'index' | 'fallback';
  excerpt: string;
  totalChars: number;
  truncated: boolean;
  relatedExams: RelatedExam[];
}

/** Characters of course material injected into the Live session. */
export const CHAPTER_EXCERPT_BUDGET = 30000;

const KIND_LABEL: Record<ChapterFileKind, string> = {
  cours: 'cours',
  exercices: 'exercices',
  synthese: 'problème de synthèse',
  autre: 'document',
};

function kindOf(name: string): ChapterFileKind {
  if (/synth[eè]se|probleme/i.test(name)) return 'synthese';
  if (/cours/i.test(name)) return 'cours';
  if (/exer|exos?\b|exos\./i.test(name)) return 'exercices';
  return 'autre';
}

const natural = (a: string, b: string) => a.localeCompare(b, 'fr', { numeric: true });

/** Exact files of a chapter (repository index) or best-effort candidate names (offline fallback). */
export function chapterFilePaths(def: ChapterDef, index: string[] | null): { paths: string[]; source: 'index' | 'fallback' } {
  if (index) {
    const prefix = def.filePrefix ? `${def.dir}/${def.key}-` : `${def.dir}/`;
    const paths = index.filter((p) => p.startsWith(prefix) && p.endsWith('.txt')).sort(natural);
    if (paths.length) return { paths, source: 'index' };
  }
  if (def.subject === 'mathematiques') {
    const n = Number(def.number);
    const s = (x: string) => `${def.dir}/seance-${n}-${x}.txt`;
    return {
      paths: [
        s('1-1-cours-partie1'), s('1-2-exercices-partie1'), s('2-1-cours-partie2'), s('2-2-exercices-partie2'),
        s('3-1-cours-partie3'), s('3-2-exercices-partie3'), s('4-probleme-de-synthese'), s('3-probleme-de-synthese'),
        s('2-probleme-de-synthese'), s('1-cours'), s('2-exercices'),
      ],
      source: 'fallback',
    };
  }
  if (def.filePrefix) return { paths: [`${def.dir}/${def.filePrefix}-cours.txt`, `${def.dir}/${def.filePrefix}-exos.txt`], source: 'fallback' };
  return { paths: [], source: 'fallback' };
}

function tidy(text: string): string {
  return text.replace(/\r\n?/g, '\n').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}

function cutAtBoundary(text: string, n: number): string {
  if (text.length <= n) return text;
  const slice = text.slice(0, n);
  const cut = Math.max(slice.lastIndexOf('\n\n'), slice.lastIndexOf('\n'));
  return cut > n * 0.6 ? slice.slice(0, cut) : slice;
}

function buildExcerpt(files: ChapterFile[], budget: number): { excerpt: string; truncated: boolean } {
  const fmt = (f: ChapterFile, text: string) => `### FICHIER : ${f.path} (${KIND_LABEL[f.kind]})\n${text}`;
  const total = files.reduce((s, f) => s + f.chars, 0);
  if (total <= budget) return { excerpt: files.map((f) => fmt(f, f.text)).join('\n\n'), truncated: false };

  // Course files weigh more than exercises; every file keeps a proportional share.
  const weight = (f: ChapterFile) => (f.kind === 'cours' ? 1.6 : 1);
  const weighted = files.reduce((s, f) => s + f.chars * weight(f), 0);
  const alloc = files.map((f) => Math.min(f.chars, Math.floor((budget * f.chars * weight(f)) / weighted)));
  let leftover = budget - alloc.reduce((a, b) => a + b, 0);
  for (let i = 0; i < files.length && leftover > 0; i++) {
    const extra = Math.min(leftover, files[i].chars - alloc[i]);
    alloc[i] += extra;
    leftover -= extra;
  }
  return {
    excerpt: files
      .map((f, i) =>
        fmt(f, alloc[i] < f.chars ? `${cutAtBoundary(f.text, alloc[i])}\n[… suite de ce fichier non incluse (budget) …]` : f.text),
      )
      .join('\n\n'),
    truncated: true,
  };
}

export async function loadChapterContext(
  subject: SubjectId,
  chapterKey: string,
  onProgress?: (done: number, total: number) => void,
): Promise<LoadedChapterContext> {
  const index = await loadRepoIndex();
  const chapter = findChapter(subject, chapterKey, index);
  if (!chapter) throw new Error(`Chapitre inconnu : ${chapterKey}`);

  const { paths, source } = chapterFilePaths(chapter, index);
  const relatedPromise = withTimeout(findRelatedExams(subject, chapter), 8000, [] as RelatedExam[]);

  let done = 0;
  onProgress?.(0, paths.length);
  const results = await mapLimit(paths, 6, async (path) => {
    try {
      return { path, raw: await fetchDataFile(path) };
    } catch {
      return { path, raw: null as string | null };
    } finally {
      done++;
      onProgress?.(done, paths.length);
    }
  });

  const files: ChapterFile[] = results
    .filter((r): r is { path: string; raw: string } => r.raw !== null)
    .map((r) => {
      const text = tidy(parseFrontMatter(r.raw).body);
      const name = r.path.split('/').pop() ?? r.path;
      return { path: r.path, name, kind: kindOf(name), chars: text.length, text };
    });
  const missing = source === 'index' ? results.filter((r) => r.raw === null).map((r) => r.path) : [];
  const { excerpt, truncated } = buildExcerpt(files, CHAPTER_EXCERPT_BUDGET);

  return {
    subject,
    chapter,
    files,
    missing,
    source,
    excerpt,
    totalChars: files.reduce((s, f) => s + f.chars, 0),
    truncated,
    relatedExams: await relatedPromise,
  };
}

/** The block appended to the system instruction. Works even before/without loaded files. */
export function buildChapterLockBlock(subject: SubjectId, chapter: ChapterDef, ctx: LoadedChapterContext | null): string {
  const profile = SUBJECT_PROFILES[subject];
  const others = STATIC_CHAPTERS[subject]
    .filter((c) => c.key !== chapter.key)
    .map((c) => `${c.number} ${c.title}`)
    .join(' · ');
  const numberWord = /^\d+$/.test(chapter.number) ? String(Number(chapter.number)) : chapter.number;
  const lines: string[] = [
    '## ACTIVE CHAPTER LOCK (STRICT — set by the application, overrides any guess)',
    `- Subject: ${profile.label} (./2bac-data-sma/${profile.dir}/)`,
    `- LOCKED CHAPTER: ${chapter.number} — ${chapter.title}${chapter.titleAr ? ` (${chapter.titleAr})` : ''}`,
    `- Dataset folder: ./2bac-data-sma/${chapter.dir}/${chapter.filePrefix ? `${chapter.filePrefix}-*.txt` : ''}`,
    `- In this session "Chapitre ${numberWord}" / "chapitre-${chapter.number}" / "هاد الدرس" means «${chapter.title}» and NOTHING else.`,
    `- Every explanation, analogy, example, QCM and exercise must belong to «${chapter.title}».`,
    `- FORBIDDEN topics in this session (other chapters): ${others}.`,
    '- If the student asks for one of them: say in one Darija sentence which chapter it is and ask them to select it in the «Chapitre» selector. Only exception: an Examen National exercise explicitly requested and retrieved by the application (EXAM MODE).',
  ];

  if (ctx && ctx.files.length) {
    lines.push('', `### Loaded chapter files (${ctx.files.length}, ${ctx.source === 'index' ? 'exact repository index' : 'fallback names'}):`);
    for (const f of ctx.files) lines.push(`- ${f.path} [${KIND_LABEL[f.kind]}] (${f.chars} caractères)`);
    if (ctx.missing.length) lines.push(`- Not loaded (network): ${ctx.missing.join(', ')}`);

    if (ctx.relatedExams.length) {
      lines.push('', '### RELATED EXAMEN NATIONAL EXERCISES for this chapter (detected in the dataset — open one with get_examen_national):');
      for (const e of ctx.relatedExams) {
        lines.push(`- ${e.year} ${SESSION_LABEL[e.session]} — Exercice ${e.exercise}${e.heading ? ` («${e.heading}»)` : ''} → ${e.path}`);
      }
    } else {
      lines.push('', '### RELATED EXAMEN NATIONAL EXERCISES: none detected automatically — use list_examens_nationaux / get_examen_national if needed.');
    }

    lines.push(
      '',
      '### CHAPTER SOURCE EXCERPTS (authoritative course material — teach from it, in this order)',
      ctx.truncated ? '(Excerpts are budgeted: if a needed passage is cut, say so honestly.)' : '(Complete files.)',
      ctx.excerpt,
    );
  } else {
    lines.push(
      '',
      '### Chapter files: not available in this session (network / index). Teach strictly within the locked chapter title and the official 2BAC SM program, never switch to another chapter, and say so when a precise dataset source is unavailable.',
    );
  }
  return lines.join('\n');
}

export function systemInstructionWithChapterContext(
  baseSystemInstruction: string,
  subject: SubjectId,
  chapter: ChapterDef | undefined,
  ctx: LoadedChapterContext | null,
): string {
  if (!chapter) return baseSystemInstruction;
  const usable = ctx && ctx.chapter.key === chapter.key && ctx.subject === subject ? ctx : null;
  return `${baseSystemInstruction}

${buildChapterLockBlock(subject, chapter, usable)}

## FINAL REMINDER — BOARD-ONLY VISUAL CONTRACT
Locked chapter = ${chapter.number} — ${chapter.title}. Never explain another chapter's topic (except an explicitly retrieved Examen National exercise). Speak ONLY in Moroccan Darija, but keep every scientific term by its OFFICIAL FRENCH name: announce the French term, ask «شنو هو …؟», then explain what it is in Darija with a concrete analogy. Never substitute an Arabic synonym for a French term. ALL board lettering must be academic French/LaTeX; never put Arabic/Darija on the board. Speak one short sentence, then write one matching line and await animation_complete. Use blackboard_draw one vector element per call for diagrams/graphs/circuits, narrated and animated sequentially. blackboard_annotate may mark an already-visible target. ask_qcm is a HARD PAUSE: options are clickable chalk lines on the board; no further speech/tools until click. After click: acknowledge in Darija audio, explain why, then continue. No assistant chat transcript.`;
}
