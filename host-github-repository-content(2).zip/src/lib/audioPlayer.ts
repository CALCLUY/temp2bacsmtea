/**
 * Streams raw 16-bit little-endian PCM chunks (as returned by the Gemini Live API,
 * 24kHz) through the Web Audio API with gapless, sequential scheduling.
 *
 * Drop-free design notes:
 *  - Scheduling is SYNCHRONOUS. Decoding a chunk inside an async function let
 *    two chunks race on nextStartTime and swap order, which sounds like a
 *    stutter or a clipped syllable. Chunks that arrive before the AudioContext
 *    is unlocked are parked in `pending` and flushed in arrival order.
 *  - A jitter buffer (JITTER_S) absorbs main-thread jank. Blackboard work
 *    (KaTeX, SVG path parsing, React commits) can block the thread for tens of
 *    ms; with only a 20 ms lead the playhead overtakes the schedule and every
 *    late chunk starts in the past, producing robotic gaps.
 *  - On underrun the schedule is rebuilt with a fresh lead instead of snapping
 *    to `currentTime`, so recovery costs one small pause, not a burst of them.
 */

/** Lead time kept between the playhead and the next scheduled chunk. */
const JITTER_S = 0.16;
/** Extra lead granted after an underrun so the stream re-stabilises. */
const REBUFFER_S = 0.22;

export class PcmStreamPlayer {
  private ctx: AudioContext | null = null;
  private nextStartTime = 0;
  private sources = new Set<AudioBufferSourceNode>();
  private analyser: AnalyserNode | null = null;
  private gain: GainNode | null = null;
  private onStateChange?: (playing: boolean) => void;
  private playing = false;
  private checkTimer: number | null = null;
  /** True when audio chunks are being actively streamed from the server turn. */
  private receivingStream = false;
  /** Chunks captured before the AudioContext finished unlocking. */
  private pending: Array<{ b64: string; mimeType?: string }> = [];
  private unlocking: Promise<AudioContext> | null = null;
  /** While held, new chunks are refused but scheduled audio drains normally. */
  private held = false;
  private underruns = 0;

  constructor(private sampleRate = 24000) {}

  setReceivingStream(active: boolean) {
    this.receivingStream = active;
    if (active) {
      this.setPlaying(true);
    } else {
      this.updatePlaying();
    }
  }

  setStateListener(cb: (playing: boolean) => void) {
    this.onStateChange = cb;
  }

  /** Must be called from a user gesture at least once so the AudioContext can start. */
  async ensureContext(): Promise<AudioContext> {
    if (this.ctx && this.ctx.state === 'running') return this.ctx;
    if (this.unlocking) return this.unlocking;
    this.unlocking = (async () => {
      if (!this.ctx) {
        this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)({
          sampleRate: this.sampleRate,
          latencyHint: 'interactive',
        });
        // Persistent chain: chunk -> gain -> analyser -> speakers.
        this.gain = this.ctx.createGain();
        this.analyser = this.ctx.createAnalyser();
        this.analyser.fftSize = 256;
        this.gain.connect(this.analyser);
        this.analyser.connect(this.ctx.destination);
      }
      if (this.ctx.state === 'suspended') await this.ctx.resume();
      return this.ctx;
    })();
    try {
      const ctx = await this.unlocking;
      this.flushPending();
      return ctx;
    } finally {
      this.unlocking = null;
    }
  }

  getAnalyser() {
    return this.analyser;
  }

  isPlaying() {
    return this.playing;
  }

  /** Diagnostics: how many times the schedule fell behind the playhead. */
  getUnderrunCount() {
    return this.underruns;
  }

  /**
   * Refuse NEW audio while letting everything already scheduled finish.
   * Used for the QCM hard pause so the teacher's final sentence is never
   * truncated mid-word — unlike stop(), which cuts the speaker off.
   */
  hold() {
    this.held = true;
    this.pending = [];
  }

  release() {
    this.held = false;
  }

  isHeld() {
    return this.held;
  }

  /** Seconds of audio still scheduled ahead of the playhead. */
  bufferedSeconds(): number {
    if (!this.ctx) return 0;
    return Math.max(0, this.nextStartTime - this.ctx.currentTime);
  }

  /** Enqueue a base64-encoded PCM16 chunk. Ordering is guaranteed. */
  enqueueBase64(b64: string, mimeType?: string) {
    if (this.held || !b64) return;
    this.setPlaying(true);
    const ctx = this.ctx;
    // Queue while the context is locked AND while earlier chunks are still
    // parked: scheduling directly past a non-empty backlog would reorder
    // syllables, because the backlog is only flushed on a microtask.
    if (!ctx || ctx.state !== 'running' || this.pending.length) {
      // Park it rather than dropping it; a dropped chunk is a lost syllable.
      if (this.pending.length < 400) this.pending.push({ b64, mimeType });
      void this.ensureContext();
      return;
    }
    this.schedule(ctx, b64, mimeType);
  }

  private flushPending() {
    const ctx = this.ctx;
    if (!ctx || ctx.state !== 'running' || !this.pending.length) return;
    const queued = this.pending;
    this.pending = [];
    for (const chunk of queued) this.schedule(ctx, chunk.b64, chunk.mimeType);
  }

  private schedule(ctx: AudioContext, b64: string, mimeType?: string) {
    const rate = parseRate(mimeType) ?? this.sampleRate;
    const bytes = base64ToBytes(b64);
    const sampleCount = Math.floor(bytes.byteLength / 2);
    if (sampleCount === 0) return;

    const view = new DataView(bytes.buffer, bytes.byteOffset, sampleCount * 2);
    const float = new Float32Array(sampleCount);
    for (let i = 0; i < sampleCount; i++) {
      float[i] = view.getInt16(i * 2, true) / 32768;
    }

    const buffer = ctx.createBuffer(1, sampleCount, rate);
    buffer.copyToChannel(float, 0);

    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(this.gain ?? this.analyser ?? ctx.destination);

    const now = ctx.currentTime;
    let startAt = this.nextStartTime;
    if (startAt < now + 0.005) {
      // Underrun (first chunk, or the main thread stalled): rebuild the lead.
      if (this.nextStartTime > 0) this.underruns++;
      startAt = now + (this.nextStartTime > 0 ? REBUFFER_S : JITTER_S);
    }
    source.start(startAt);
    this.nextStartTime = startAt + buffer.duration;

    this.sources.add(source);
    source.onended = () => {
      this.sources.delete(source);
      this.updatePlaying();
    };
  }

  /**
   * Stop playback immediately and clear the queue (e.g. on interruption).
   * Also clears the hold so a reset can never leave the teacher muted; callers
   * that stop *while* a QCM is still pending must re-apply hold().
   */
  stop() {
    this.receivingStream = false;
    this.held = false;
    this.pending = [];
    for (const s of this.sources) {
      try {
        s.onended = null;
        s.stop();
      } catch {
        /* already stopped */
      }
    }
    this.sources.clear();
    this.nextStartTime = 0;
    this.setPlaying(false);
  }

  private updatePlaying() {
    // If we're still actively receiving audio chunks from the server, we are not done yet!
    if (this.sources.size === 0 && !this.pending.length && !this.receivingStream) {
      // Add a tiny buffer to prevent micro-flicker between scheduled chunks
      if (this.checkTimer) window.clearTimeout(this.checkTimer);
      this.checkTimer = window.setTimeout(() => {
        if (this.sources.size === 0 && !this.pending.length && !this.receivingStream) {
          this.setPlaying(false);
        }
        this.checkTimer = null;
      }, 100);
    }
  }

  private setPlaying(v: boolean) {
    if (this.playing !== v) {
      this.playing = v;
      this.onStateChange?.(v);
    }
    if (this.checkTimer) {
      window.clearTimeout(this.checkTimer);
      this.checkTimer = null;
    }
  }

  async close() {
    this.stop();
    this.held = false;
    if (this.ctx) {
      await this.ctx.close();
      this.ctx = null;
      this.analyser = null;
      this.gain = null;
    }
  }
}

function parseRate(mimeType?: string): number | undefined {
  if (!mimeType) return undefined;
  const m = /rate=(\d+)/.exec(mimeType);
  return m ? Number(m[1]) : undefined;
}

function base64ToBytes(b64: string): Uint8Array {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

/**
 * Captures microphone audio, downsamples/converts to 16-bit PCM little-endian at 16kHz,
 * and emits base64 chunks for the Gemini Live WebSocket.
 */
export class PcmRecorder {
  private mediaStream: MediaStream | null = null;
  private audioCtx: AudioContext | null = null;
  private processor: ScriptProcessorNode | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  private recording = false;

  constructor(private onChunk: (b64: string) => void) {}

  async start(): Promise<void> {
    if (this.recording) return;
    this.mediaStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        channelCount: 1,
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      },
    });

    this.audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({
      sampleRate: 16000,
    });
    if (this.audioCtx.state === 'suspended') {
      await this.audioCtx.resume();
    }

    this.source = this.audioCtx.createMediaStreamSource(this.mediaStream);
    // Buffer size 2048 gives ~128ms chunks at 16kHz
    this.processor = this.audioCtx.createScriptProcessor(2048, 1, 1);

    this.processor.onaudioprocess = (e) => {
      if (!this.recording) return;
      const input = e.inputBuffer.getChannelData(0);
      const pcm16 = new Int16Array(input.length);
      for (let i = 0; i < input.length; i++) {
        const s = Math.max(-1, Math.min(1, input[i]));
        pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
      }
      const bytes = new Uint8Array(pcm16.buffer, pcm16.byteOffset, pcm16.byteLength);
      const b64 = bytesToBase64(bytes);
      this.onChunk(b64);
    };

    this.source.connect(this.processor);
    this.processor.connect(this.audioCtx.destination);
    this.recording = true;
  }

  stop() {
    this.recording = false;
    if (this.processor) {
      this.processor.disconnect();
      this.processor.onaudioprocess = null;
      this.processor = null;
    }
    if (this.source) {
      this.source.disconnect();
      this.source = null;
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((t) => t.stop());
      this.mediaStream = null;
    }
    if (this.audioCtx) {
      void this.audioCtx.close();
      this.audioCtx = null;
    }
  }

  isRecording() {
    return this.recording;
  }
}
