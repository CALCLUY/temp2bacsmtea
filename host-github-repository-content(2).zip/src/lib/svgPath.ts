/**
 * Chalk stroke engine: parse SVG path data, split it into individually
 * animatable strokes, and plan their drawing timing.
 *
 * The Blackboard renders every path in its OWN unit space and wraps the
 * strokes in a single <g transform="…"> that places the shape on the board.
 * Strokes use vector-effect: non-scaling-stroke, so chalk thickness stays
 * constant in screen pixels no matter how the artwork is scaled.
 */

export interface PathSegment {
  /** A single animatable stroke, e.g. "M 0 0 L 10 10". */
  d: string;
  /** Approximate length in unit space, used to derive the animation duration. */
  length: number;
}

export interface PathBox {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface ParsedSvgPath {
  segments: PathSegment[];
  bbox: PathBox;
}

export interface StrokePlan {
  /** Per-segment start delay in ms. */
  delays: number[];
  /** Per-segment animation duration in ms. */
  durations: number[];
  /** Total time until the last stroke is fully drawn. */
  total: number;
}

type Token = { cmd: string } | { num: number };

const TOKEN_RE = /([MmLlHhVvCcSsQqTtAaZz])|(-?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?)/g;

function tokenize(d: string): Token[] {
  const tokens: Token[] = [];
  TOKEN_RE.lastIndex = 0;
  let match: RegExpExecArray | null;
  while ((match = TOKEN_RE.exec(d)) !== null) {
    tokens.push(match[1] ? { cmd: match[1] } : { num: parseFloat(match[2]) });
  }
  return tokens;
}

const isCmd = (t: Token | undefined): t is { cmd: string } => !!t && 'cmd' in t;
const isNum = (t: Token | undefined): t is { num: number } => !!t && 'num' in t;

/** Round for compact, readable path output. */
const r = (n: number) => (Math.round(n * 1000) / 1000).toString();

function cubicSamples(p0: number[], p1: number[], p2: number[], p3: number[], steps = 14): Array<[number, number]> {
  const out: Array<[number, number]> = [];
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const u = 1 - t;
    const a = u * u * u;
    const b = 3 * u * u * t;
    const c = 3 * u * t * t;
    const e = t * t * t;
    out.push([a * p0[0] + b * p1[0] + c * p2[0] + e * p3[0], a * p0[1] + b * p1[1] + c * p2[1] + e * p3[1]]);
  }
  return out;
}

function quadSamples(p0: number[], p1: number[], p2: number[], steps = 12): Array<[number, number]> {
  const out: Array<[number, number]> = [];
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const u = 1 - t;
    out.push([u * u * p0[0] + 2 * u * t * p1[0] + t * t * p2[0], u * u * p0[1] + 2 * u * t * p1[1] + t * t * p2[1]]);
  }
  return out;
}

/** Endpoint → centre arc parameterisation (SVG 1.1 implementation notes). */
function arcSamples(
  x1: number, y1: number, rxIn: number, ryIn: number, phiDeg: number,
  largeArc: boolean, sweep: boolean, x2: number, y2: number,
): Array<[number, number]> {
  let rx = Math.abs(rxIn);
  let ry = Math.abs(ryIn);
  if (rx === 0 || ry === 0) return [[x2, y2]];

  const rad = (phiDeg * Math.PI) / 180;
  const cosP = Math.cos(rad);
  const sinP = Math.sin(rad);
  const dx2 = (x1 - x2) / 2;
  const dy2 = (y1 - y2) / 2;
  const x1p = cosP * dx2 + sinP * dy2;
  const y1p = -sinP * dx2 + cosP * dy2;

  let rxs = rx * rx;
  let rys = ry * ry;
  const lambda = (x1p * x1p) / rxs + (y1p * y1p) / rys;
  if (lambda > 1) {
    const scale = Math.sqrt(lambda);
    rx *= scale;
    ry *= scale;
    rxs = rx * rx;
    rys = ry * ry;
  }

  const num = rxs * rys - rxs * y1p * y1p - rys * x1p * x1p;
  const den = rxs * y1p * y1p + rys * x1p * x1p;
  let coef = Math.sqrt(Math.max(0, num / den));
  if (largeArc === sweep) coef = -coef;
  const cxp = (coef * rx * y1p) / ry;
  const cyp = (-coef * ry * x1p) / rx;
  const cx = cosP * cxp - sinP * cyp + (x1 + x2) / 2;
  const cy = sinP * cxp + cosP * cyp + (y1 + y2) / 2;

  const angle = (ux: number, uy: number, vx: number, vy: number) => {
    const dot = ux * vx + uy * vy;
    const mag = Math.hypot(ux, uy) * Math.hypot(vx, vy);
    let a = Math.acos(Math.min(1, Math.max(-1, mag === 0 ? 1 : dot / mag)));
    if (ux * vy - uy * vx < 0) a = -a;
    return a;
  };
  const theta1 = angle(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry);
  let dTheta = angle((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry);
  if (!sweep && dTheta > 0) dTheta -= 2 * Math.PI;
  else if (sweep && dTheta < 0) dTheta += 2 * Math.PI;

  const steps = Math.max(6, Math.min(48, Math.ceil(Math.abs(dTheta) / (Math.PI / 14))));
  const out: Array<[number, number]> = [];
  for (let i = 0; i <= steps; i++) {
    const th = theta1 + (dTheta * i) / steps;
    out.push([
      cosP * rx * Math.cos(th) - sinP * ry * Math.sin(th) + cx,
      sinP * rx * Math.cos(th) + cosP * ry * Math.sin(th) + cy,
    ]);
  }
  return out;
}

const EMPTY_BOX: PathBox = { x: 0, y: 0, w: 0, h: 0 };

/**
 * Parse SVG path data into one stroke per drawing command (M/L/C/Q/T/A/Z…).
 * Smooth S/T commands are resolved into explicit C/Q, and arcs are sampled
 * into polylines so every stroke can be drawn with a dash animation.
 */
export function parseSvgPath(d: string): ParsedSvgPath {
  const tokens = tokenize(d ?? '');
  const segments: PathSegment[] = [];
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  let cx = 0;
  let cy = 0;
  let sx = 0;
  let sy = 0;
  let ctrl: [number, number] | null = null;
  let cmd = '';
  /** True right after a command letter was read, before its first argument set. */
  let pending = false;
  let i = 0;

  const grow = (x: number, y: number) => {
    if (!Number.isFinite(x) || !Number.isFinite(y)) return;
    minX = Math.min(minX, x);
    maxX = Math.max(maxX, x);
    minY = Math.min(minY, y);
    maxY = Math.max(maxY, y);
  };
  const push = (data: string, samples: Array<[number, number]>) => {
    if (samples.length < 2) return;
    let length = 0;
    for (const p of samples) grow(p[0], p[1]);
    for (let k = 1; k < samples.length; k++) {
      length += Math.hypot(samples[k][0] - samples[k - 1][0], samples[k][1] - samples[k - 1][1]);
    }
    segments.push({ d: data, length });
  };
  const readNums = (count: number): number[] | null => {
    const out: number[] = [];
    for (let k = 0; k < count; k++) {
      const t = tokens[i];
      if (!isNum(t)) return null;
      i++;
      out.push(t.num);
    }
    return out.every((n) => Number.isFinite(n)) ? out : null;
  };

  const closePath = () => {
    if (cx !== sx || cy !== sy) push(`M ${r(cx)} ${r(cy)} L ${r(sx)} ${r(sy)}`, [[cx, cy], [sx, sy]]);
    cx = sx;
    cy = sy;
    ctrl = null;
  };

  while (i < tokens.length) {
    const token = tokens[i];
    if (isCmd(token)) {
      // A closepath takes no arguments, so it runs as soon as the next command appears.
      if (pending && (cmd === 'Z' || cmd === 'z')) closePath();
      cmd = token.cmd;
      pending = true;
      i++;
      continue;
    }
    if (!cmd || cmd === 'Z' || cmd === 'z') {
      i++;
      continue;
    }
    // Only a SECOND set of coordinates repeats the previous command, turning
    // an already-executed moveto into a lineto.
    if (!pending) {
      if (cmd === 'M') cmd = 'L';
      else if (cmd === 'm') cmd = 'l';
    }
    pending = false;

    const upper = cmd.toUpperCase();
    const rel = cmd !== upper;
    const ax = (v: number) => (rel ? cx + v : v);
    const ay = (v: number) => (rel ? cy + v : v);

    if (upper === 'M') {
      const n = readNums(2);
      if (!n) break;
      cx = ax(n[0]);
      cy = ay(n[1]);
      sx = cx;
      sy = cy;
      ctrl = null;
      grow(cx, cy);
      continue;
    }
    if (upper === 'L' || upper === 'H' || upper === 'V') {
      const n = upper === 'H' ? readNums(1) : upper === 'V' ? readNums(1) : readNums(2);
      if (!n) break;
      const nx = upper === 'H' ? ax(n[0]) : upper === 'V' ? cx : ax(n[0]);
      const ny = upper === 'V' ? ay(n[0]) : upper === 'H' ? cy : ay(n[1] ?? 0);
      push(`M ${r(cx)} ${r(cy)} L ${r(nx)} ${r(ny)}`, [[cx, cy], [nx, ny]]);
      cx = nx;
      cy = ny;
      ctrl = null;
      continue;
    }
    if (upper === 'C' || upper === 'S') {
      const n = readNums(upper === 'C' ? 6 : 4);
      if (!n) break;
      let c1: [number, number];
      let c2: [number, number];
      if (upper === 'C') {
        c1 = [ax(n[0]), ay(n[1])];
        c2 = [ax(n[2]), ay(n[3])];
        var end: [number, number] = [ax(n[4]), ay(n[5])];
      } else {
        const prev = ctrl ?? [cx, cy];
        c1 = [2 * cx - prev[0], 2 * cy - prev[1]];
        c2 = [ax(n[0]), ay(n[1])];
        end = [ax(n[2]), ay(n[3])];
      }
      push(`M ${r(cx)} ${r(cy)} C ${r(c1[0])} ${r(c1[1])}, ${r(c2[0])} ${r(c2[1])}, ${r(end[0])} ${r(end[1])}`,
        cubicSamples([cx, cy], c1, c2, end));
      cx = end[0];
      cy = end[1];
      ctrl = c2;
      continue;
    }
    if (upper === 'Q' || upper === 'T') {
      const n = readNums(upper === 'Q' ? 4 : 2);
      if (!n) break;
      let c1: [number, number];
      let end: [number, number];
      if (upper === 'Q') {
        c1 = [ax(n[0]), ay(n[1])];
        end = [ax(n[2]), ay(n[3])];
      } else {
        const prev = ctrl ?? [cx, cy];
        c1 = [2 * cx - prev[0], 2 * cy - prev[1]];
        end = [ax(n[0]), ay(n[1])];
      }
      push(`M ${r(cx)} ${r(cy)} Q ${r(c1[0])} ${r(c1[1])} ${r(end[0])} ${r(end[1])}`, quadSamples([cx, cy], c1, end));
      cx = end[0];
      cy = end[1];
      ctrl = c1;
      continue;
    }
    if (upper === 'A') {
      const n = readNums(7);
      if (!n) break;
      const end: [number, number] = [ax(n[5]), ay(n[6])];
      const samples = arcSamples(cx, cy, n[0], n[1], n[2], n[3] > 0.5, n[4] > 0.5, end[0], end[1]);
      const polyline = samples.map((p, k) => `${k === 0 ? 'M' : 'L'} ${r(p[0])} ${r(p[1])}`).join(' ');
      push(polyline, samples);
      cx = end[0];
      cy = end[1];
      ctrl = null;
      continue;
    }
    if (upper === 'Z') {
      closePath();
      continue;
    }
    i++;
  }
  // A closepath at the very end of the data is consumed after the loop.
  if (pending && (cmd === 'Z' || cmd === 'z')) closePath();

  if (!Number.isFinite(minX)) return { segments, bbox: { ...EMPTY_BOX } };
  return { segments, bbox: { x: minX, y: minY, w: maxX - minX, h: maxY - minY } };
}

/**
 * Concatenating strokes keeps a single dash animation running across all of
 * them, so a very detailed path still draws in a bounded number of steps.
 */
export function limitSegments(segments: PathSegment[], max: number): PathSegment[] {
  if (segments.length <= max || max < 1) return segments;
  const total = segments.reduce((sum, s) => sum + Math.max(s.length, 1), 0);
  const target = total / max;
  const out: PathSegment[] = [];
  let bucket: PathSegment[] = [];
  let bucketLength = 0;
  const flush = () => {
    if (!bucket.length) return;
    out.push({ d: bucket.map((s) => s.d).join(' '), length: bucketLength });
    bucket = [];
    bucketLength = 0;
  };
  for (const segment of segments) {
    bucket.push(segment);
    bucketLength += Math.max(segment.length, 1);
    if (bucketLength >= target) flush();
  }
  flush();
  return out.length ? out : segments;
}

const MS_PER_UNIT = 2.8;
const MIN_SEGMENT_MS = 180;
const MAX_SEGMENT_MS = 700;

/** Backpressure timing shared by the React renderer and the Live tool response. */
export function planStrokeTiming(segments: PathSegment[], maxTotal = 5600): StrokePlan {
  if (!segments.length) return { delays: [], durations: [], total: 420 };
  const durations = segments.map((s) =>
    Math.max(MIN_SEGMENT_MS, Math.min(MAX_SEGMENT_MS, Math.max(s.length, 1) * MS_PER_UNIT)));
  const rawTotal = durations.reduce((a, b) => a + b, 0);
  const scale = rawTotal > maxTotal ? maxTotal / rawTotal : 1;
  const scaled = durations.map((d) => Math.round(d * scale));
  const delays: number[] = [];
  let acc = 0;
  for (const d of scaled) {
    delays.push(acc);
    acc += d;
  }
  return { delays, durations: scaled, total: acc };
}

export function bboxOf(boxes: PathBox[]): PathBox {
  const usable = boxes.filter((b) => b.w > 0 || b.h > 0);
  if (!usable.length) return { ...EMPTY_BOX };
  const minX = Math.min(...usable.map((b) => b.x));
  const minY = Math.min(...usable.map((b) => b.y));
  const maxX = Math.max(...usable.map((b) => b.x + b.w));
  const maxY = Math.max(...usable.map((b) => b.y + b.h));
  return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
}

export interface FitOptions {
  /** Centre of the artwork, as percentages of the board. */
  x: number;
  y: number;
  scale: number;
  rotate: number;
  /** Canvas size in pixels. */
  width: number;
  height: number;
}

/** Place a unit-space shape on the board, preserving its aspect ratio. */
export function fitTransform(bbox: PathBox, options: FitOptions): { transform: string; scale: number } {
  const { width, height, scale, rotate, x, y } = options;
  const span = 0.62 * Math.min(width, height) * Math.max(0.1, Math.min(5, scale));
  const maxDim = Math.max(bbox.w, bbox.h, 1);
  const factor = span / maxDim;
  const cx = (x / 100) * width;
  const cy = (y / 100) * height;
  const bx = bbox.x + bbox.w / 2;
  const by = bbox.y + bbox.h / 2;
  const transform = `translate(${r(cx)} ${r(cy)}) rotate(${r(rotate)}) scale(${r(factor)}) translate(${r(-bx)} ${r(-by)})`;
  return { transform, scale: factor };
}
