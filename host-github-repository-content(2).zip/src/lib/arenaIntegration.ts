import { buildLiveSetupPayload, LIVE_MODEL } from './geminiLive';
import { DATASET_REPOSITORY, SUBJECT_PROFILES, type SubjectId } from './dataset';
import { buildSystemInstruction } from './prompts';
import { LIVE_TOOL_DECLARATIONS } from './liveTools';

export const GEMINI_API_KEY_STORAGE_KEY = 'gemini_live_api_key';

export function readStoredGeminiApiKey(): string {
  try {
    return localStorage.getItem(GEMINI_API_KEY_STORAGE_KEY) ?? '';
  } catch {
    return '';
  }
}

export function persistGeminiApiKey(apiKey: string, remember: boolean): void {
  try {
    if (remember && apiKey) localStorage.setItem(GEMINI_API_KEY_STORAGE_KEY, apiKey);
    else localStorage.removeItem(GEMINI_API_KEY_STORAGE_KEY);
  } catch {
    /* storage unavailable (private mode) */
  }
}

/** Serializable description of a teacher session (useful for debugging / external hosts). */
export function createTeacherSessionConfig(apiKey: string, subject: SubjectId) {
  const profile = SUBJECT_PROFILES[subject];
  return {
    model: LIVE_MODEL,
    subject,
    voiceName: profile.voiceName,
    repository: DATASET_REPOSITORY,
    setup: buildLiveSetupPayload({
      apiKey,
      model: LIVE_MODEL,
      subject,
      voice: profile.voiceName,
      systemInstruction: buildSystemInstruction(subject),
      tools: LIVE_TOOL_DECLARATIONS,
    }),
  };
}
