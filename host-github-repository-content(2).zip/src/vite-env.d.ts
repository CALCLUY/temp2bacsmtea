/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_2BAC_DATA_BASE_URL?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}