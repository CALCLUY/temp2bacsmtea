import type { ParsedTerm } from '../lib/interaction';
import MathText from './MathText';

interface Props {
  term: ParsedTerm;
  /** 1-based rank of the term in the lesson glossary. */
  index?: number;
  compact?: boolean;
}

/**
 * 📖 Bilingual card for a French scientific term the teacher just introduced:
 * the term, its plain Darija meaning, and one concrete everyday analogy.
 * It mirrors what the voice is saying (RULE ZERO B) — it never replaces it.
 */
export default function TermCard({ term, index, compact = false }: Props) {
  return (
    <div
      dir="rtl"
      className={compact ? 'rounded-xl border border-amber-800/40 bg-amber-950/20 p-2' : 'rounded-2xl border border-amber-800/50 bg-gradient-to-br from-amber-950/40 to-zinc-900 p-3 shadow-md'}
    >
      <p className="mb-1.5 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-amber-300">
        <span>📖 مصطلح جديد</span>
        {index !== undefined && <span className="text-amber-400/60">#{index}</span>}
      </p>

      <p className="text-sm font-bold text-white">
        <span dir="ltr" lang="fr" className="font-mono text-amber-100">
          {term.term}
        </span>
      </p>

      <div className="mt-1.5 space-y-1 text-[13px] leading-relaxed text-zinc-200">
        <p className="flex gap-1.5">
          <span className="shrink-0 text-amber-400/90">المعنى:</span>
          <MathText inline text={term.meaning} />
        </p>
        {term.analogy && (
          <p className="flex gap-1.5">
            <span className="shrink-0 text-amber-400/90">مثال:</span>
            <MathText inline text={term.analogy} />
          </p>
        )}
      </div>
    </div>
  );
}
