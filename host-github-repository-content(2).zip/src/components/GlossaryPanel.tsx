import { useState } from 'react';
import type { ParsedTerm } from '../lib/interaction';
import TermCard from './TermCard';

interface Props {
  terms: ParsedTerm[];
}

/**
 * Running glossary of the session: every French term the teacher has explained,
 * with its Darija meaning and analogy. Shown in the sidebar so the student can
 * come back to a term at any time.
 */
export default function GlossaryPanel({ terms }: Props) {
  const [open, setOpen] = useState(false);

  return (
    <section className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-4">
      <button type="button" onClick={() => setOpen((o) => !o)} className="flex w-full items-center justify-between gap-2 text-left">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
          📖 مصطلحات الدرس <span className="text-zinc-500">({terms.length})</span>
        </h2>
        <span className="text-[11px] text-zinc-500">{open ? 'Masquer' : 'Voir'}</span>
      </button>

      <p className="mt-1 text-[11px] leading-relaxed text-zinc-500">
        كل مصطلح فرنسي جاوب ليه الأستاذ بالدارجة + مثال من الحياة.
      </p>

      {terms.length === 0 ? (
        <p dir="auto" className="mt-2 text-[11px] text-zinc-600">
          مازال ماكاينش مصطلح — بدا الدرس والأستاذ غادي يشرح ليك كل مصطلح.
        </p>
      ) : (
        <div className="mt-2 space-y-2">
          {(open ? terms : terms.slice(0, 1)).map((t, i) => (
            <TermCard key={`${t.term}-${i}`} term={t} index={i + 1} compact />
          ))}
          {!open && terms.length > 1 && (
            <button type="button" onClick={() => setOpen(true)} className="text-[11px] text-amber-300 hover:text-amber-200">
              +{terms.length - 1} autres…
            </button>
          )}
        </div>
      )}
    </section>
  );
}
