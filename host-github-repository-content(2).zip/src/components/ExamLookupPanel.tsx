import { useEffect, useMemo, useState } from 'react';
import type { SubjectId } from '../lib/dataset';
import type { ChapterDef } from '../lib/curriculum';
import { examAvailability, SESSION_LABEL, type ExamAvailability, type ExamRequest, type ExamSession } from '../lib/examRetrieval';

interface Props {
  subject: SubjectId;
  chapters: ChapterDef[];
  busy: boolean;
  onOpen: (req: ExamRequest) => void;
}

const FALLBACK_YEARS = Array.from({ length: 16 }, (_, i) => 2010 + i);

/** Deterministic Examen National picker: ./2bac-data-sma/{subject}/examens-nationaux/{année}/… */
export default function ExamLookupPanel({ subject, chapters, busy, onOpen }: Props) {
  const [avail, setAvail] = useState<ExamAvailability[] | null>(null);
  const [year, setYear] = useState<number>(2018);
  const [session, setSession] = useState<ExamSession>('normale');
  const [exercise, setExercise] = useState<string>('');
  const [topic, setTopic] = useState<string>('');

  useEffect(() => {
    let alive = true;
    setAvail(null);
    setTopic('');
    examAvailability(subject)
      .then((a) => {
        if (!alive) return;
        setAvail(a);
        if (a.length) setYear((y) => (a.some((x) => x.year === y) ? y : a[a.length - 1].year));
      })
      .catch(() => alive && setAvail([]));
    return () => {
      alive = false;
    };
  }, [subject]);

  const years = avail && avail.length ? avail.map((a) => a.year) : FALLBACK_YEARS;
  const entry = avail?.find((a) => a.year === year);
  const sessions = useMemo<ExamSession[]>(() => {
    if (!entry) return ['normale', 'rattrapage'];
    return (['normale', 'rattrapage'] as ExamSession[]).filter((s) => entry.sessions[s]?.sujet);
  }, [entry]);

  useEffect(() => {
    if (sessions.length && !sessions.includes(session)) setSession(sessions[0]);
  }, [sessions, session]);

  const slot = entry?.sessions[session];

  return (
    <section className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-4">
      <h2 className="mb-1 text-xs font-semibold uppercase tracking-wider text-zinc-400">📚 Examens Nationaux</h2>
      <p className="mb-3 text-[11px] leading-relaxed text-zinc-500">
        Énoncé officiel (français + LaTeX) + corrigé depuis <span className="font-mono text-zinc-400">examens-nationaux/</span>.
      </p>

      <div className="grid grid-cols-2 gap-2">
        <label className="text-[11px] text-zinc-400">
          Année
          <select
            value={year}
            onChange={(e) => setYear(Number(e.target.value))}
            className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-2 py-1.5 text-sm text-zinc-100 outline-none focus:border-sky-500"
          >
            {years.map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
        </label>
        <label className="text-[11px] text-zinc-400">
          Session
          <select
            value={session}
            onChange={(e) => setSession(e.target.value as ExamSession)}
            className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-2 py-1.5 text-sm text-zinc-100 outline-none focus:border-sky-500"
          >
            {(sessions.length ? sessions : (['normale'] as ExamSession[])).map((s) => (
              <option key={s} value={s}>
                {s === 'normale' ? 'Normale' : 'Rattrapage'}
              </option>
            ))}
          </select>
        </label>
        <label className="text-[11px] text-zinc-400">
          Exercice
          <select
            value={exercise}
            onChange={(e) => setExercise(e.target.value)}
            className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-2 py-1.5 text-sm text-zinc-100 outline-none focus:border-sky-500"
          >
            <option value="">Liste</option>
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <option key={n} value={n}>
                Exercice {n}
              </option>
            ))}
          </select>
        </label>
        <label className="text-[11px] text-zinc-400">
          Thème (option)
          <select
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-2 py-1.5 text-sm text-zinc-100 outline-none focus:border-sky-500"
          >
            <option value="">—</option>
            {chapters
              .filter((c) => c.signals.length > 0)
              .map((c) => (
                <option key={c.key} value={c.key}>
                  {c.number} {c.title}
                </option>
              ))}
          </select>
        </label>
      </div>

      <p className="mt-2 text-[10px] text-zinc-500">
        {avail === null
          ? 'Lecture de l’index du dataset…'
          : entry
            ? `${SESSION_LABEL[session]} ${year} : sujet ${slot?.sujet ? '✓' : '—'} · corrigé ${slot?.corrige ? '✓' : '—'}`
            : avail.length
              ? `${year} absent du dataset (scan illisible ou non publié).`
              : 'Index indisponible : accès direct aux chemins canoniques.'}
      </p>

      <button
        type="button"
        disabled={busy}
        onClick={() =>
          onOpen({
            subject,
            year,
            session,
            sessionExplicit: true,
            exercise: exercise ? Number(exercise) : undefined,
            topicKey: topic || undefined,
          })
        }
        className="mt-2 w-full rounded-lg bg-gradient-to-r from-sky-600 to-violet-600 px-3 py-2 text-sm font-semibold text-white shadow hover:brightness-110 disabled:cursor-wait disabled:opacity-60"
      >
        {busy ? 'Chargement…' : "Afficher l'exercice"}
      </button>
      <p dir="auto" className="mt-2 text-[10px] leading-relaxed text-zinc-500">
        Ou demande-le au prof (voix / texte) : «خدم معايا التمرين الثاني ديال Nombres Complexes فـ Examen National 2018 Session Normale».
      </p>
    </section>
  );
}
