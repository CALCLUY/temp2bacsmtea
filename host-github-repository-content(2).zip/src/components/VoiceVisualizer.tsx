import { useEffect, useRef } from 'react';

interface Props {
  analyser: AnalyserNode | null;
  active: boolean;
  className?: string;
}

const BARS = 24;

export default function VoiceVisualizer({ analyser, active, className }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const resize = () => {
      const { clientWidth, clientHeight } = canvas;
      canvas.width = clientWidth * dpr;
      canvas.height = clientHeight * dpr;
    };
    resize();

    const data = analyser ? new Uint8Array(analyser.frequencyBinCount) : null;
    let phase = 0;

    const draw = () => {
      rafRef.current = requestAnimationFrame(draw);
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      const gap = 4 * dpr;
      const barW = (w - gap * (BARS - 1)) / BARS;
      phase += 0.05;

      if (analyser && data && active) {
        analyser.getByteFrequencyData(data);
      }

      for (let i = 0; i < BARS; i++) {
        let v: number;
        if (analyser && data && active) {
          const idx = Math.floor((i / BARS) * (data.length * 0.6));
          v = data[idx] / 255;
        } else {
          v = 0.08 + Math.sin(phase + i * 0.4) * 0.03;
        }
        const barH = Math.max(3 * dpr, v * h);
        const x = i * (barW + gap);
        const y = (h - barH) / 2;

        const grad = ctx.createLinearGradient(0, y, 0, y + barH);
        grad.addColorStop(0, active ? '#a78bfa' : '#52525b');
        grad.addColorStop(1, active ? '#38bdf8' : '#3f3f46');
        ctx.fillStyle = grad;

        const r = Math.min(barW / 2, 3 * dpr);
        ctx.beginPath();
        ctx.roundRect(x, y, barW, barH, r);
        ctx.fill();
      }
    };
    draw();

    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [analyser, active]);

  return <canvas ref={canvasRef} className={className} />;
}
