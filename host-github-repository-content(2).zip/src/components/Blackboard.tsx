import { memo, useEffect, useMemo, useRef, type ReactNode } from 'react';
import { containsArabic, isSplitDividerOrHeader, type BoardAnnotation, type BoardDrawingItem } from '../lib/interaction';
import { chalkWritingMs } from '../lib/chalkTiming';
import { renderMath, tokenizeMath } from './MathText';
import BoardAnnotations from './BoardAnnotations';
import { cn } from '../utils/cn';

export interface BoardLine {
  id: string;
  text: string;
  kind?: 'title' | 'text' | 'qcm-question' | 'qcm-option';
  qcmId?: string;
  optionIndex?: number;
  color?: string;
  delayMs?: number;
}

export interface BoardMark extends BoardAnnotation {
  id: string;
}

interface BlackboardProps {
  lines: BoardLine[];
  annotations: BoardMark[];
  drawings: BoardDrawingItem[];
  activeQcmId?: string;
  selectedAnswer: number | null;
  /** Set once answered, so the board can chalk a ✓ / ✗ next to the options. */
  correctIndex?: number;
  canAnswer: boolean;
  onAnswer: (index: number) => void;
  wiping?: boolean;
  className?: string;
}

/** Hand-drawn verdict mark stroked next to an answered QCM option. */
const VerdictMark = memo(function VerdictMark({ correct }: { correct: boolean }) {
  return <svg className="bb-verdict" viewBox="0 0 24 24" aria-hidden="true">
    {correct
      ? <path className="bb-verdict-ok" pathLength="1" d="M 3 13 L 9.5 19.5 L 21 4.5" />
      : <>
          <path className="bb-verdict-no" pathLength="1" d="M 4.5 4.5 L 19.5 19.5" />
          <path className="bb-verdict-no bb-verdict-no-2" pathLength="1" d="M 19.5 4.5 L 4.5 19.5" />
        </>}
  </svg>;
});

function escapeHtml(text: string): string {
  return text.replace(/[&<>"']/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[char] ?? char);
}

/** Sample JSON may supply either $...$ or a bare LaTeX expression. */
function readyForMath(line: string): string {
  const text = line.trim().replace(/^#{1,5}\s+/, '').replace(/\*\*/g, '');
  if (/\$|\\\(|\\\[/.test(text)) return text;
  if (/^(?:\\(?:lim|frac|sqrt|int|sum|prod|sin|cos|tan|ln|exp|vec|overrightarrow|mathbb|forall|exists|alpha|beta|epsilon|gamma|lambda|mu|pi|sigma|theta|omega|partial)|[a-zA-Z]\s*(?:\(|_\{|\^\{|\s*=|\s*\\in|\s*\\le|\s*\\ge))/.test(text) &&
      (/[=^_{}]|\\/.test(text))) return `$${text}$`;
  return text;
}

const ChalkLine = memo(function ChalkLine({ line, activeQcmId, selectedAnswer, correctIndex, canAnswer, onAnswer }: {
  line: BoardLine;
  activeQcmId?: string;
  selectedAnswer: number | null;
  correctIndex?: number;
  canAnswer: boolean;
  onAnswer: (index: number) => void;
}) {
  const isOption = line.kind === 'qcm-option' && line.optionIndex !== undefined;
  // Defensive visual guards: no Arabic text and no artificial divider/zone headers
  if (containsArabic(line.text) || isSplitDividerOrHeader(line.text)) return null;

  const text = useMemo(() => readyForMath(isOption ? line.text.replace(/^[A-D]\.\s*/, '') : line.text), [isOption, line.text]);
  const tokens = useMemo(() => tokenizeMath(text), [text]);
  const hasMath = tokens.some((token) => token.t === 'math');
  const active = isOption && line.qcmId === activeQcmId;
  const selected = active && selectedAnswer === line.optionIndex;
  const enabled = active && canAnswer && selectedAnswer === null;
  const answered = active && correctIndex !== undefined;

  // 4-Color system:
  // #FFFFFF white prose, #FFE600 yellow titles/formulas, #4FC3F7 blue subheads/cues, #81C784 green labels
  const isTitle = line.kind === 'title';
  const isSubhead = !isTitle && !isOption && /^(?:•\s*|>\s*|\[\d+\]|\d+\)|\b(?:Th[ée]or[èe]me|D[ée]finition|Propri[ée]t[ée]|R[èe]gle|Formule|Remarque|Exemple|[ÉE]tape\s*\d*)\b)/i.test(text);

  // Mark the student's pick, and reveal the right answer when they miss it.
  const verdict: boolean | null = !answered
    ? null
    : selected
      ? line.optionIndex === correctIndex
      : line.optionIndex === correctIndex ? true : null;
  const delay = line.delayMs ?? 0;
  const classes = cn(
    'bb-line',
    isTitle && 'bb-line-title',
    isSubhead && 'bb-line-subhead',
    line.kind === 'qcm-question' && 'bb-qcm-question',
    isOption && 'bb-option',
    selected && 'bb-option-selected',
    answered && verdict === true && 'bb-option-correct',
    selected && verdict === false && 'bb-option-wrong',
  );

  let content: ReactNode;
  if (hasMath) {
    const html = tokens.map((token) => token.t === 'math'
      ? `<span class="bb-katex-formula">${renderMath(token.v, token.d)}</span>`
      : `<span class="bb-prose-text">${escapeHtml(token.v)}</span>`).join('');
    const steps = Math.max(12, Math.min(100, [...text].length));
    content = <span
      data-board-content
      className="bb-math-writing"
      style={{
        animationDelay: `${delay}ms`,
        animationDuration: `${chalkWritingMs(text)}ms`,
        ['--chalk-steps' as string]: String(steps),
      }}
      dangerouslySetInnerHTML={{ __html: html }}
    />;
  } else {
    const letters = [...text];
    const interval = Math.max(14, Math.min(31, Math.floor(1600 / Math.max(letters.length, 1))));
    content = <span data-board-content className="bb-prose-text">
      {letters.map((letter, i) => <span
        key={i}
        className="bb-letter"
        style={{ animationDelay: `${delay + i * interval}ms` }}
      >{letter === ' ' ? '\u00a0' : letter}</span>)}
    </span>;
  }

  const lineStyle = line.color ? { color: line.color } : undefined;

  if (isOption) return <button
    type="button"
    className={classes}
    style={lineStyle}
    dir="ltr"
    lang="fr"
    data-board-line={line.id}
    data-board-raw={line.text}
    aria-label={`Choisir ${line.text}`}
    aria-pressed={selected}
    disabled={!enabled}
    onClick={() => onAnswer(line.optionIndex!)}
  >
    <span className="bb-option-letter" aria-hidden="true">{String.fromCharCode(65 + line.optionIndex!)}.</span>
    <bdi dir="auto" className="bb-option-body">{content}</bdi>
    {verdict !== null && <VerdictMark correct={verdict} />}
  </button>;

  return (
    <div
      className={classes}
      style={lineStyle}
      dir="ltr"
      lang="fr"
      data-board-line={line.id}
      data-board-raw={line.text}
    >
      {content}
    </div>
  );
});

/** Clean 2:1 slate: fixed physical chalkboard with strict no-scrolling policy. */
function Blackboard({
  lines,
  annotations,
  drawings,
  activeQcmId,
  selectedAnswer,
  correctIndex,
  canAnswer,
  onAnswer,
  wiping = false,
  className,
}: BlackboardProps) {
  const canvasRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Focus active QCM option when ready
  useEffect(() => {
    if (activeQcmId && canAnswer) {
      containerRef.current?.querySelector<HTMLButtonElement>('.bb-option:not(:disabled)')?.focus({ preventScroll: true });
    }
  }, [activeQcmId, canAnswer]);

  const hasDrawings = drawings.length > 0;
  const isCompact = lines.length >= 6;

  return (
    <div className={cn('bb-surface', wiping && 'bb-wiping', className)} aria-label="Tableau virtuel" role="region">
      <div className="bb-dust" aria-hidden="true" />
      <div className="bb-writing" ref={containerRef}>
        <div className="bb-canvas-content" ref={canvasRef}>
          <div className={cn('bb-lines', hasDrawings && 'bb-lines-with-drawings', isCompact && 'bb-lines-compact')}>
            {lines.map((line) => <ChalkLine
              key={line.id}
              line={line}
              activeQcmId={activeQcmId}
              selectedAnswer={selectedAnswer}
              correctIndex={correctIndex}
              canAnswer={canAnswer}
              onAnswer={onAnswer}
            />)}
          </div>
          <BoardAnnotations marks={annotations} drawings={drawings} lines={lines} canvasRef={canvasRef} />
        </div>
      </div>
      {wiping && <div className="bb-eraser-sweep" aria-hidden="true" />}
    </div>
  );
}

export default memo(Blackboard);