import { useState } from 'react';
import MathText from './MathText';
import { blobUrl } from '../lib/dataRepo';
import type { ExamRetrieval } from '../lib/examRetrieval';
import { cn } from '../utils/cn';

interface Props {
  exam: ExamRetrieval;
  /** True once the exercise context was sent to the teacher. */
  sent: boolean;
  canSend: boolean;
  busy?: boolean;
  onSend: () => void;
  onSelectExercise: (n: number) => void;
  onOpenYear: (year: number) => void;
}

const KIND_LABEL: Record<ExamRetrieval['correctionKind'], string> = {
  detailed: 'solution officielle détaillée',
  bareme: 'barème / éléments de réponse',
  unknown: 'corrigé officiel',
  none: 'absent',
};

/** The raw official statement, displayed in formal French with LaTeX. */
export default function ExamCard({ exam: r, sent, canSend, busy, onSend, onSelectExercise, onOpenYear }: Props) {
  const [showCorrection, setShowCorrection] = useState(false);
  const [showPreamble, setShowPreamble] = useState(false);
  const req = r.request;

  if (!r.ok) {
    return (
      <div className="rounded-2xl border border-amber-800/60 bg-amber-950/20 p-4">
        <p className="text-[10px] font-semibold uppercase tracking-wider text-amber-300">📚 Examen National · {r.subjectLabel}</p>
        <p className="mt-1 text-sm font-semibold text-zinc-100">
          {r.sessionLabel} {req.year}
          {req.exercise ? ` · Exercice ${req.exercise}` : ''}
        </p>
        <p className="mt-2 text-sm leading-relaxed text-amber-100/90">{r.error}</p>
        {r.availableYears.length > 0 && (
          <div className="mt-3">
            <p className="mb-1.5 text-[11px] text-zinc-400">Années disponibles dans le dataset :</p>
            <div className="flex flex-wrap gap-1.5">
              {r.availableYears.map((y) => (
                <button
                  key={y}
                  type="button"
                  disabled={busy}
                  onClick={() => onOpenYear(y)}
                  className="rounded-full border border-zinc-700 bg-zinc-900 px-2.5 py-0.5 text-[11px] text-zinc-300 hover:border-sky-500 hover:text-white disabled:opacity-50"
                >
                  {y}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  const sel = r.selected;
  return (
    <div className="overflow-hidden rounded-2xl border border-sky-800/50 bg-zinc-900/80 shadow-lg shadow-sky-950/30">
      <div className="flex items-center gap-3 border-b border-zinc-800 bg-gradient-to-r from-sky-950/70 to-violet-950/40 px-4 py-2.5">
        <span className="text-xl">📚</span>
        <div className="min-w-0 flex-1">
          <p className="text-[10px] font-semibold uppercase tracking-wider text-sky-300">Examen National · {r.subjectLabel} · Sujet officiel</p>
          <p className="truncate text-sm font-semibold text-white">
            {r.sessionLabel} {req.year}
            {sel ? ` — Exercice ${sel.number}` : ''}
            {sel?.points ? ` · ${sel.points}` : ''}
          </p>
        </div>
        {r.sujetPath && (
          <a
            href={blobUrl(r.sujetPath)}
            target="_blank"
            rel="noreferrer"
            className="shrink-0 rounded-lg border border-zinc-700 bg-zinc-900/70 px-2 py-1 text-[10px] text-zinc-300 hover:border-sky-500 hover:text-white"
          >
            GitHub ↗
          </a>
        )}
      </div>

      <div className="space-y-3 p-4">
        {sel && sel.topics.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {sel.topics.slice(0, 2).map((t) => (
              <span key={t.key} className="rounded-full border border-violet-700/50 bg-violet-950/40 px-2 py-0.5 text-[10px] font-medium text-violet-200">
                {t.label}
              </span>
            ))}
          </div>
        )}

        {r.notes.length > 0 && (
          <div className="space-y-1 rounded-xl border border-amber-800/50 bg-amber-950/25 px-3 py-2 text-[11px] leading-relaxed text-amber-100/90">
            {r.notes.map((n, i) => (
              <p key={i}>⚠ {n}</p>
            ))}
          </div>
        )}

        {r.exercises.length > 0 && (
          <div>
            <p className="mb-1.5 text-[10px] font-semibold uppercase tracking-wider text-zinc-500">Exercices de ce sujet</p>
            <div className="flex flex-wrap gap-1.5">
              {r.exercises.map((e) => (
                <button
                  key={e.number}
                  type="button"
                  disabled={busy}
                  onClick={() => onSelectExercise(e.number)}
                  title={e.heading}
                  className={cn(
                    'rounded-lg border px-2 py-1 text-left text-[11px] transition-colors disabled:opacity-50',
                    sel?.number === e.number
                      ? 'border-sky-500 bg-sky-950/60 text-white'
                      : 'border-zinc-700 bg-zinc-950 text-zinc-300 hover:border-sky-500/70 hover:text-white',
                  )}
                >
                  <span className="font-semibold">Ex {e.number}</span>
                  {e.topics[0] && <span className="ml-1 text-zinc-400">· {e.topics[0].label}</span>}
                  {e.points && <span className="ml-1 text-zinc-500">({e.points})</span>}
                </button>
              ))}
            </div>
          </div>
        )}

        {sel ? (
          <div lang="fr" dir="ltr" className="rounded-xl border border-zinc-800 bg-zinc-950/70 p-3 text-[13px] leading-relaxed text-zinc-200">
            <MathText text={sel.body} dir="ltr" />
          </div>
        ) : r.exercises.length === 0 ? (
          <div lang="fr" dir="ltr" className="max-h-[28rem] overflow-y-auto rounded-xl border border-zinc-800 bg-zinc-950/70 p-3 text-[13px] leading-relaxed text-zinc-200">
            <MathText text={r.preamble} dir="ltr" />
          </div>
        ) : (
          <p dir="auto" className="rounded-xl border border-dashed border-zinc-700 px-3 py-2 text-xs text-zinc-400">
            Choisis un exercice ci-dessus — الأستاذ غادي يخدم معاك عليه خطوة بخطوة.
          </p>
        )}

        {r.preamble && r.exercises.length > 0 && (
          <div>
            <button type="button" onClick={() => setShowPreamble((s) => !s)} className="text-[11px] text-zinc-400 hover:text-zinc-200">
              {showPreamble ? '▾' : '▸'} En-tête du sujet
            </button>
            {showPreamble && (
              <div lang="fr" dir="ltr" className="mt-1 rounded-lg border border-zinc-800 bg-zinc-950/50 p-2 text-xs text-zinc-400">
                <MathText text={r.preamble} dir="ltr" />
              </div>
            )}
          </div>
        )}

        {r.correction ? (
          <div>
            <button
              type="button"
              onClick={() => setShowCorrection((s) => !s)}
              className="flex w-full items-center justify-between rounded-lg border border-emerald-900/60 bg-emerald-950/20 px-3 py-1.5 text-left text-[11px] text-emerald-200 hover:bg-emerald-950/40"
            >
              <span>
                {showCorrection ? '▾' : '▸'} Corrigé officiel — {KIND_LABEL[r.correctionKind]}
                {r.correctionScope === 'full' ? ' (document complet)' : ''}
              </span>
              <span className="text-emerald-400/70">{showCorrection ? 'masquer' : 'essaie d’abord 😉'}</span>
            </button>
            {showCorrection && (
              <div lang="fr" dir="ltr" className="mt-2 max-h-[28rem] overflow-y-auto rounded-xl border border-emerald-900/50 bg-emerald-950/10 p-3 text-[13px] leading-relaxed text-zinc-200">
                <MathText text={r.correction} dir="ltr" />
              </div>
            )}
          </div>
        ) : (
          <p className="text-[11px] text-zinc-500">Aucun corrigé officiel dans le dataset pour cette session.</p>
        )}

        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-zinc-800 pt-2">
          <p className="min-w-0 break-all font-mono text-[10px] text-zinc-500">
            Source : {r.sujetPath}
            {r.corrigePath ? ` · ${r.corrigePath.split('/').pop()}` : ''}
          </p>
          {sent ? (
            <span className="rounded-full border border-emerald-800/60 bg-emerald-950/40 px-2 py-0.5 text-[10px] text-emerald-300">
              ✓ envoyé au prof
            </span>
          ) : (
            <button
              type="button"
              onClick={onSend}
              disabled={!canSend || busy}
              title={canSend ? 'Travailler cet exercice avec le prof' : 'Connecte-toi d’abord'}
              className="rounded-lg bg-gradient-to-r from-violet-600 to-sky-500 px-3 py-1.5 text-[11px] font-semibold text-white shadow hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
            >
              🎓 Khdem m3aya had tamrin
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
