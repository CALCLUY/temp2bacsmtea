import { useState } from 'react';
import type { ChapterDef } from '../lib/curriculum';
import type { LoadedChapterContext } from '../lib/chapterContext';
import { SESSION_LABEL, type RelatedExam } from '../lib/examRetrieval';
import { blobUrl } from '../lib/dataRepo';
import { cn } from '../utils/cn';

export type ChapterStatus = 'loading' | 'ready' | 'error';

interface Props {
  chapters: ChapterDef[];
  chapterKey: string;
  onSelect: (key: string) => void;
  status: ChapterStatus;
  progress: { done: number; total: number };
  ctx: LoadedChapterContext | null;
  error: string | null;
  live: boolean;
  onOpenExam: (exam: RelatedExam) => void;
}

/** Strict chapter selector: exact folder, loaded files, related real exam exercises. */
export default function ChapterPanel({ chapters, chapterKey, onSelect, status, progress, ctx, error, live, onOpenExam }: Props) {
  const [showFiles, setShowFiles] = useState(false);
  const chapter = chapters.find((c) => c.key === chapterKey) ?? chapters[0];
  const kb = ctx ? Math.round(ctx.totalChars / 1024) : 0;

  return (
    <div className="mt-3 rounded-xl border border-zinc-800 bg-zinc-950/60 p-3">
      <div className="mb-1.5 flex items-center justify-between">
        <span className="text-xs text-zinc-400">Chapitre (verrouillé)</span>
        <span className="rounded-full border border-emerald-800/60 bg-emerald-950/40 px-2 py-0.5 text-[10px] font-semibold text-emerald-300">
          🔒 strict
        </span>
      </div>

      <select
        value={chapterKey}
        onChange={(e) => onSelect(e.target.value)}
        className="w-full rounded-lg border border-zinc-700 bg-zinc-950 px-2 py-2 text-sm text-zinc-100 outline-none focus:border-violet-500"
      >
        {chapters.map((c) => (
          <option key={c.key} value={c.key}>
            {c.number} — {c.title}
          </option>
        ))}
      </select>

      {chapter && (
        <>
          {chapter.titleAr && (
            <p dir="rtl" className="mt-1 text-[11px] text-zinc-400">
              {chapter.titleAr}
            </p>
          )}
          <p className="mt-1 break-all font-mono text-[10px] text-zinc-600">
            ./2bac-data-sma/{chapter.dir}/{chapter.filePrefix ? `${chapter.filePrefix}-*` : ''}
          </p>
        </>
      )}

      <div className="mt-2 text-[11px]">
        {status === 'loading' && (
          <p className="flex items-center gap-2 text-sky-300">
            <span className="h-2 w-2 animate-pulse rounded-full bg-sky-400" />
            Chargement des fichiers… {progress.total ? `${progress.done}/${progress.total}` : ''}
          </p>
        )}
        {status === 'ready' && ctx && (
          <p className="text-emerald-300">
            ✓ {ctx.files.length} fichier(s) · {kb} Ko{ctx.truncated ? ' (extraits budgétés)' : ''} injectés dans la session
          </p>
        )}
        {status === 'error' && <p className="text-amber-300">⚠ {error ?? 'Fichiers indisponibles — verrou actif (titre + règles).'}</p>}
      </div>

      {live && (
        <p className="mt-1 text-[10px] leading-relaxed text-amber-300/80">
          Changer de chapitre relance automatiquement la session avec les fichiers exacts du nouveau chapitre.
        </p>
      )}

      {ctx && ctx.files.length > 0 && (
        <div className="mt-2">
          <button type="button" onClick={() => setShowFiles((s) => !s)} className="text-[11px] text-zinc-400 hover:text-zinc-200">
            {showFiles ? '▾' : '▸'} Fichiers du chapitre
          </button>
          {showFiles && (
            <ul className="mt-1 space-y-0.5">
              {ctx.files.map((f) => (
                <li key={f.path} className="flex items-center justify-between gap-2 text-[10px]">
                  <a href={blobUrl(f.path)} target="_blank" rel="noreferrer" className="truncate font-mono text-sky-400/90 hover:underline">
                    {f.name}
                  </a>
                  <span className="shrink-0 text-zinc-600">{f.kind}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      {ctx && ctx.relatedExams.length > 0 && (
        <div className="mt-2 rounded-lg border border-zinc-800 bg-zinc-900/60 p-2">
          <p className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-sky-400">Examens Nationaux liés à ce chapitre</p>
          <div className="flex flex-wrap gap-1">
            {ctx.relatedExams.map((e) => (
              <button
                key={`${e.year}-${e.session}-${e.exercise}`}
                type="button"
                onClick={() => onOpenExam(e)}
                title={`${SESSION_LABEL[e.session]} ${e.year} — ${e.heading}`}
                className={cn(
                  'rounded-md border border-zinc-700 bg-zinc-950 px-1.5 py-0.5 text-[10px] text-zinc-300 transition-colors',
                  'hover:border-sky-500 hover:text-white',
                )}
              >
                {e.year} {e.session === 'normale' ? 'N' : 'R'} · Ex {e.exercise}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
