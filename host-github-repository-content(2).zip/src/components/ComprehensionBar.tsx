import { cn } from '../utils/cn';

interface Props {
  onUnderstood: () => void;
  onNotUnderstood: () => void;
  disabled?: boolean;
}

/**
 * Rendered when the teacher emits [CHECK_UNDERSTANDING].
 * Two prominent one-tap answers — no typing needed.
 */
export default function ComprehensionBar({ onUnderstood, onNotUnderstood, disabled }: Props) {
  return (
    <div className="w-full">
      <p dir="auto" className="mb-2 text-center text-xs text-zinc-400">
        واش فهمتي هاد الجزء؟ — جاوب بكليك واحد
      </p>
      <div className="flex gap-2">
        <button
          type="button"
          onClick={onUnderstood}
          disabled={disabled}
          className={cn(
            'flex flex-1 items-center justify-center gap-2 rounded-xl bg-emerald-600 px-3 py-3 text-white shadow-lg shadow-emerald-950/40 transition-colors',
            disabled ? 'cursor-not-allowed opacity-50' : 'hover:bg-emerald-500 active:scale-[0.98]',
          )}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-5 w-5 shrink-0"
          >
            <polyline points="20 6 9 17 4 12" />
          </svg>
          <span className="leading-tight">
            <span dir="auto" className="block text-sm font-bold">
              صحيح / فهمت
            </span>
            <span className="block text-[10px] font-normal opacity-80">Understood — continue</span>
          </span>
        </button>

        <button
          type="button"
          onClick={onNotUnderstood}
          disabled={disabled}
          className={cn(
            'flex flex-1 items-center justify-center gap-2 rounded-xl bg-rose-600 px-3 py-3 text-white shadow-lg shadow-rose-950/40 transition-colors',
            disabled ? 'cursor-not-allowed opacity-50' : 'hover:bg-rose-500 active:scale-[0.98]',
          )}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-5 w-5 shrink-0"
          >
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
          <span className="leading-tight">
            <span dir="auto" className="block text-sm font-bold">
              خطأ / مافهمتش
            </span>
            <span className="block text-[10px] font-normal opacity-80">Explain again</span>
          </span>
        </button>
      </div>
    </div>
  );
}
