import { memo, useMemo, type ReactNode } from 'react';
import katex from 'katex';
import { cn } from '../utils/cn';

/**
 * Renders academic French + LaTeX ($…$, $$…$$, \(…\), \[…\]) with light markdown
 * (headings, bold, bullets, quotes, tables). Used for exam statements, corrections,
 * the board and QCM options. KaTeX CSS is loaded from jsDelivr (version-matched).
 */

const UNREADABLE = '[FORMULA_IMAGE_UNREADABLE]';

(function ensureKatexCss() {
  if (typeof document === 'undefined' || document.querySelector('link[data-katex-css]')) return;
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = `https://cdn.jsdelivr.net/npm/katex@${katex.version}/dist/katex.min.css`;
  link.crossOrigin = 'anonymous';
  link.setAttribute('data-katex-css', '1');
  document.head.appendChild(link);
})();

const mathCache = new Map<string, string>();

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c] as string);
}

export function renderMath(expr: string, display: boolean): string {
  const key = `${display ? 'D' : 'I'}:${expr}`;
  const hit = mathCache.get(key);
  if (hit !== undefined) return hit;
  let html: string;
  try {
    html = katex.renderToString(expr, { displayMode: display, throwOnError: false, strict: 'ignore', output: 'html' });
  } catch {
    html = escapeHtml(expr);
  }
  if (mathCache.size > 1500) mathCache.clear();
  mathCache.set(key, html);
  return html;
}

type Tok = { t: 'text'; v: string } | { t: 'math'; v: string; d: boolean };

function findInlineClose(s: string, from: number): number {
  for (let j = from; j < s.length; j++) {
    if (s[j] === '\\') {
      j++;
      continue;
    }
    if (s[j] === '$') return j;
    if (s[j] === '\n') return -1;
  }
  return -1;
}

export function tokenizeMath(s: string): Tok[] {
  const out: Tok[] = [];
  let buf = '';
  let i = 0;
  const flush = () => {
    if (buf) out.push({ t: 'text', v: buf });
    buf = '';
  };
  while (i < s.length) {
    const ch = s[i];
    if (ch === '\\' && s[i + 1] === '$') {
      buf += '$';
      i += 2;
      continue;
    }
    if (ch === '$') {
      const display = s[i + 1] === '$';
      const open = display ? 2 : 1;
      const close = display ? s.indexOf('$$', i + 2) : findInlineClose(s, i + 1);
      if (close !== -1) {
        const expr = s.slice(i + open, close);
        if (expr.trim()) {
          flush();
          out.push({ t: 'math', v: expr, d: display });
          i = close + open;
          continue;
        }
      }
    }
    if (ch === '\\' && s[i + 1] === '(') {
      const close = s.indexOf('\\)', i + 2);
      if (close !== -1) {
        flush();
        out.push({ t: 'math', v: s.slice(i + 2, close), d: false });
        i = close + 2;
        continue;
      }
    }
    if (ch === '\\' && s[i + 1] === '[') {
      const close = s.indexOf('\\]', i + 2);
      if (close !== -1) {
        flush();
        out.push({ t: 'math', v: s.slice(i + 2, close), d: true });
        i = close + 2;
        continue;
      }
    }
    buf += ch;
    i++;
  }
  flush();
  return out;
}

function renderTokens(s: string, key: string): ReactNode[] {
  const nodes: ReactNode[] = [];
  tokenizeMath(s).forEach((tok, i) => {
    if (tok.t === 'math') {
      nodes.push(
        <span
          key={`${key}-m${i}`}
          dir="ltr"
          style={{ unicodeBidi: 'isolate' }}
          className={cn(tok.d && 'my-1 block overflow-x-auto overflow-y-hidden py-0.5 text-center')}
          dangerouslySetInnerHTML={{ __html: renderMath(tok.v, tok.d) }}
        />,
      );
      return;
    }
    const parts = tok.v.split(UNREADABLE);
    parts.forEach((p, j) => {
      if (p) nodes.push(<span key={`${key}-t${i}-${j}`}>{p}</span>);
      if (j < parts.length - 1) {
        nodes.push(
          <span
            key={`${key}-u${i}-${j}`}
            title="Formule illisible dans la source (image du PDF officiel)"
            className="mx-1 inline-flex items-center rounded border border-amber-700/50 bg-amber-950/40 px-1 align-middle text-[10px] font-medium text-amber-300"
          >
            formule illisible
          </span>,
        );
      }
    });
  });
  return nodes;
}

function renderInline(text: string, key: string): ReactNode[] {
  const parts = text.split('**');
  const balanced = parts.length % 2 === 1;
  const out: ReactNode[] = [];
  parts.forEach((part, i) => {
    if (!part) return;
    const inner = renderTokens(part, `${key}-${i}`);
    if (balanced && i % 2 === 1) {
      out.push(
        <strong key={`${key}-b${i}`} className="font-semibold text-white">
          {inner}
        </strong>,
      );
    } else {
      out.push(...inner);
    }
  });
  return out;
}

type Block =
  | { k: 'p' | 'li' | 'quote'; text: string }
  | { k: 'h'; level: number; text: string }
  | { k: 'table'; rows: string[][] }
  | { k: 'gap' }
  | { k: 'hr' };

function parseBlocks(src: string): Block[] {
  const text = src
    .replace(/\r\n?/g, '\n')
    .replace(/\\\[([\s\S]*?)\\\]/g, (_m, inner: string) => `$$${inner}$$`)
    .replace(/\$\$([\s\S]*?)\$\$/g, (_m, inner: string) => `$$${inner.replace(/\s*\n\s*/g, ' ')}$$`);
  const lines = text.split('\n');
  const blocks: Block[] = [];
  for (let i = 0; i < lines.length; i++) {
    const t = lines[i].trim();
    if (!t) {
      if (blocks.length && blocks[blocks.length - 1].k !== 'gap') blocks.push({ k: 'gap' });
      continue;
    }
    if (t.startsWith('|') && t.endsWith('|') && (t.match(/\|/g)?.length ?? 0) >= 3) {
      const rows: string[][] = [];
      let j = i;
      while (j < lines.length) {
        const r = lines[j].trim();
        if (!(r.startsWith('|') && r.endsWith('|'))) break;
        if (!/^\|[\s:|-]+\|$/.test(r)) rows.push(r.slice(1, -1).split('|').map((c) => c.trim()));
        j++;
      }
      blocks.push({ k: 'table', rows });
      i = j - 1;
      continue;
    }
    let m = /^(#{1,6})\s+(.*)$/.exec(t);
    if (m) {
      blocks.push({ k: 'h', level: m[1].length, text: m[2] });
      continue;
    }
    if (/^(?:-{3,}|\*{3,}|_{3,})$/.test(t)) {
      blocks.push({ k: 'hr' });
      continue;
    }
    m = /^>\s?(.*)$/.exec(t);
    if (m) {
      blocks.push({ k: 'quote', text: m[1] });
      continue;
    }
    m = /^[-*•]\s+(.*)$/.exec(t);
    if (m) {
      blocks.push({ k: 'li', text: m[1] });
      continue;
    }
    blocks.push({ k: 'p', text: t });
  }
  while (blocks.length && blocks[blocks.length - 1].k === 'gap') blocks.pop();
  return blocks;
}

interface Props {
  text: string;
  className?: string;
  dir?: 'auto' | 'ltr' | 'rtl';
  /** Render as a single inline <span> (for buttons / QCM options). */
  inline?: boolean;
}

function MathTextImpl({ text, className, dir = 'auto', inline = false }: Props) {
  const blocks = useMemo(() => (inline ? [] : parseBlocks(text)), [text, inline]);

  if (inline) {
    return (
      <span className={className} dir={dir}>
        {renderInline(text.replace(/\s*\n\s*/g, ' '), 'i')}
      </span>
    );
  }

  return (
    <div className={cn('space-y-1 break-words', className)}>
      {blocks.map((b, i) => {
        const key = `b${i}`;
        switch (b.k) {
          case 'gap':
            return <div key={key} className="h-1.5" />;
          case 'hr':
            return <hr key={key} className="my-2 border-zinc-700/70" />;
          case 'h':
            return (
              <p key={key} dir={dir} className={cn('pt-1 font-bold', b.level <= 2 ? 'text-[15px] text-sky-200' : 'text-sm text-sky-300')}>
                {renderInline(b.text, key)}
              </p>
            );
          case 'quote':
            return (
              <p key={key} dir={dir} className="border-l-2 border-sky-600/60 pl-3 italic text-zinc-300">
                {renderInline(b.text, key)}
              </p>
            );
          case 'li':
            return (
              <div key={key} dir={dir} className="flex gap-2">
                <span className="select-none text-sky-400">•</span>
                <div className="min-w-0 flex-1">{renderInline(b.text, key)}</div>
              </div>
            );
          case 'table':
            return (
              <div key={key} className="overflow-x-auto">
                <table className="w-full border-collapse text-xs">
                  <tbody>
                    {b.rows.map((row, r) => (
                      <tr key={r} className={r === 0 ? 'bg-zinc-800/60 font-semibold' : ''}>
                        {row.map((cell, c) => (
                          <td key={c} className="border border-zinc-700/70 px-2 py-1 align-top">
                            {renderInline(cell, `${key}-${r}-${c}`)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );
          default:
            return (
              <p key={key} dir={dir}>
                {renderInline(b.text, key)}
              </p>
            );
        }
      })}
    </div>
  );
}

const MathText = memo(MathTextImpl);
export default MathText;
