import { buildLiveSetupPayload, LIVE_MODEL } from './geminiLive';
import {
  DATASET_API_ROUTES,
  DATASET_MANIFEST_ROUTES,
  SUBJECT_PROFILES,
  type SubjectId,
} from './dataset';
import { buildSystemInstruction } from './prompts';

export const GEMINI_API_KEY_STORAGE_KEY = 'gemini_live_api_key';

export function readStoredGeminiApiKey(): string {
  return typeof window === 'undefined' ? '' : window.localStorage.getItem(GEMINI_API_KEY_STORAGE_KEY) ?? '';
}

export function persistGeminiApiKey(apiKey: string, remember: boolean): void {
  if (typeof window === 'undefined') return;
  if (remember) window.localStorage.setItem(GEMINI_API_KEY_STORAGE_KEY, apiKey.trim());
  else window.localStorage.removeItem(GEMINI_API_KEY_STORAGE_KEY);
}

/**
 * Clean integration object for the frontend or a server session factory.
 * `setup` is the exact first WebSocket envelope; `datasetRoutes` belongs to
 * the retrieval layer and is deliberately not sent as an unknown API field.
 */
export function createTeacherSessionConfig(apiKey: string, subject: SubjectId) {
  const profile = SUBJECT_PROFILES[subject];
  const systemInstruction = buildSystemInstruction(subject);

  return {
    model: LIVE_MODEL,
    subject,
    voiceName: profile.voiceName,
    systemInstruction,
    teachingMode:
      'FIRST-PRINCIPLES MICRO-STEPPING, hands-free: one micro-part (<= 2-3 min or 3 steps) + one QCM JSON block or [CHECK_UNDERSTANDING] per turn; button signals ([BUTTON:UNDERSTOOD] / [BUTTON:NOT_UNDERSTOOD] / [BUTTON:QCM_ANSWER]) continue the lesson immediately; analogies before formulas; assume zero prior knowledge',
    datasetRoutes: {
      subject: profile.routes,
      manifests: DATASET_MANIFEST_ROUTES,
      api: DATASET_API_ROUTES,
    },
    setup: buildLiveSetupPayload({
      apiKey,
      model: LIVE_MODEL,
      subject,
      voice: profile.voiceName,
      systemInstruction,
    }),
  };
}