/**
 * Minimal raw-WebSocket client for the Gemini Live API.
 * Protocol reference: https://ai.google.dev/gemini-api/docs/live-api/get-started-websocket
 */

import { buildSystemInstruction } from './prompts';
import { SUBJECT_PROFILES, type SubjectId } from './dataset';

export const LIVE_MODEL = 'gemini-3.8-live';

const WS_BASE =
  'wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent';

export type InteractionStatus = 'IDLE' | 'IN_PROGRESS';

export const VOICES = ['Puck', 'Charon', 'Kore', 'Fenrir', 'Aoede', 'Leda', 'Orus', 'Zephyr'] as const;
export type VoiceName = (typeof VOICES)[number];

export interface LiveClientOptions {
  apiKey: string;
  model?: string;
  subject?: SubjectId;
  voice?: VoiceName;
  systemInstruction?: string;
}

/**
 * The exact setup envelope sent as the first WebSocket message.
 * Native audio Live models expose their text as outputAudioTranscription;
 * they do not expose a second independent TEXT response stream.
 */
export function buildLiveSetupPayload(options: LiveClientOptions) {
  const subject = options.subject ?? 'mathematiques';
  const profile = SUBJECT_PROFILES[subject];

  return {
    setup: {
      model: `models/${options.model ?? LIVE_MODEL}`,
      generationConfig: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {
              voiceName: options.voice ?? profile.voiceName,
            },
          },
        },
        // gemini-3.8-live ignores thinkingLevel per the migration guide; omit it
        // so the payload matches what the model actually accepts.
      },
      systemInstruction: {
        parts: [
          {
            text: options.systemInstruction ?? buildSystemInstruction(subject),
          },
        ],
      },
      // Required for a voice transcript; this is a caption of the Darija audio.
      outputAudioTranscription: {},
      inputAudioTranscription: {},
    },
  };
}

export interface LiveClientEvents {
  onOpen?: () => void;
  onSetupComplete?: () => void;
  onAudioChunk?: (base64: string, mimeType: string) => void;
  onOutputTranscription?: (text: string) => void;
  onInputTranscription?: (text: string) => void;
  onModelText?: (text: string) => void;
  onThought?: (text: string) => void;
  onTurnComplete?: () => void;
  onInterrupted?: () => void;
  onInteractionStatus?: (status: InteractionStatus) => void;
  onGoAway?: (timeLeft?: string) => void;
  onError?: (message: string) => void;
  onClose?: (code: number, reason: string) => void;
  onRaw?: (msg: unknown) => void;
}

export class GeminiLiveClient {
  private ws: WebSocket | null = null;
  private ready = false;

  constructor(
    private options: LiveClientOptions,
    private events: LiveClientEvents,
  ) {}

  get isReady() {
    return this.ready && this.ws?.readyState === WebSocket.OPEN;
  }

  get isConnected() {
    return this.ws?.readyState === WebSocket.OPEN;
  }

  connect() {
    if (this.ws) this.disconnect();

    const url = `${WS_BASE}?key=${encodeURIComponent(this.options.apiKey)}`;
    const ws = new WebSocket(url);
    this.ws = ws;

    ws.onopen = () => {
      this.events.onOpen?.();
      ws.send(JSON.stringify(buildLiveSetupPayload(this.options)));
    };

    ws.onmessage = async (event: MessageEvent) => {
      let raw: string;
      if (typeof event.data === 'string') {
        raw = event.data;
      } else if (event.data instanceof Blob) {
        raw = await event.data.text();
      } else {
        raw = new TextDecoder().decode(event.data as ArrayBuffer);
      }

      let msg: any;
      try {
        msg = JSON.parse(raw);
      } catch {
        return;
      }
      this.handleMessage(msg);
    };

    ws.onerror = () => {
      this.events.onError?.('WebSocket error — check your API key and network connection.');
    };

    ws.onclose = (ev: CloseEvent) => {
      this.ready = false;
      this.events.onClose?.(ev.code, ev.reason);
      if (this.ws === ws) this.ws = null;
    };
  }

  private handleMessage(msg: any) {
    this.events.onRaw?.(msg);

    if (msg.setupComplete !== undefined) {
      this.ready = true;
      this.events.onSetupComplete?.();
    }

    if (msg.error) {
      const m = msg.error.message ?? JSON.stringify(msg.error);
      this.events.onError?.(m);
    }

    // interactionStatus may be top-level or nested in serverContent (thinking model).
    const status: InteractionStatus | undefined =
      msg.interactionStatus ?? msg.serverContent?.interactionStatus;
    if (status) this.events.onInteractionStatus?.(status);

    const sc = msg.serverContent;
    if (sc) {
      if (sc.interrupted) {
        this.events.onInterrupted?.();
      }

      if (sc.modelTurn?.parts) {
        for (const part of sc.modelTurn.parts) {
          if (part.inlineData?.data) {
            this.events.onAudioChunk?.(part.inlineData.data, part.inlineData.mimeType ?? 'audio/pcm;rate=24000');
          }
          if (typeof part.text === 'string' && part.text.length > 0) {
            if (part.thought) this.events.onThought?.(part.text);
            else this.events.onModelText?.(part.text);
          }
        }
      }

      if (sc.outputTranscription?.text) {
        this.events.onOutputTranscription?.(sc.outputTranscription.text);
      }
      if (sc.inputTranscription?.text) {
        this.events.onInputTranscription?.(sc.inputTranscription.text);
      }

      if (sc.turnComplete) {
        this.events.onTurnComplete?.();
      }
    }

    if (msg.goAway) {
      this.events.onGoAway?.(msg.goAway.timeLeft);
    }

    if (msg.toolCall) {
      // No tools are declared in this app; respond gracefully so the session doesn't stall.
      const functionResponses = (msg.toolCall.functionCalls ?? []).map((fc: any) => ({
        id: fc.id,
        name: fc.name,
        response: { error: 'No tools are available in this client.' },
      }));
      if (functionResponses.length) {
        this.send({ toolResponse: { functionResponses } });
      }
    }
  }

  /** Send a text message as realtime input (per the WebSocket getting-started guide). */
  sendText(text: string) {
    if (!this.isReady) {
      this.events.onError?.('Session is not ready yet.');
      return false;
    }
    this.send({ realtimeInput: { text } });
    return true;
  }

  private send(payload: unknown) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(payload));
    }
  }

  disconnect() {
    this.ready = false;
    if (this.ws) {
      const ws = this.ws;
      this.ws = null;
      ws.onopen = null;
      ws.onmessage = null;
      ws.onerror = null;
      ws.onclose = null;
      try {
        ws.close(1000, 'client closed');
      } catch {
        /* noop */
      }
    }
  }
}
