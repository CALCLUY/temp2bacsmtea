/**
 * Canonical bindings for the 2bac-data-sma repository.
 *
 * The default HTTP root assumes the repository's `2bac-data-sma/` directory
 * is copied into the web app's public root. A server deployment can override
 * this with VITE_2BAC_DATA_BASE_URL without changing the prompt contract.
 */

export type SubjectId = 'mathematiques' | 'physique-chimie' | 'svt';

export interface DatasetSubjectRoutes {
  subjectRoot: string;
  manifests: string[];
  sections: Record<string, string>;
}

export interface SubjectProfile {
  id: SubjectId;
  label: string;
  shortLabel: string;
  voiceName: 'Charon' | 'Orus' | 'Kore';
  teacherName: string;
  routes: DatasetSubjectRoutes;
}

const configuredRoot =
  typeof import.meta !== 'undefined' && import.meta.env?.VITE_2BAC_DATA_BASE_URL
    ? String(import.meta.env.VITE_2BAC_DATA_BASE_URL)
    : '/2bac-data-sma';

export const DATASET_ROOT = configuredRoot.replace(/\/$/, '');

// The GitHub repository keeps manifest TSV files beside the data directory.
export const DATASET_REPO_ROOT = DATASET_ROOT.endsWith('/2bac-data-sma')
  ? DATASET_ROOT.slice(0, -'/2bac-data-sma'.length) || '/'
  : DATASET_ROOT;

const repoRoute = (file: string) =>
  DATASET_REPO_ROOT === '/' ? `/${file}` : `${DATASET_REPO_ROOT}/${file}`;

export const DATASET_REPOSITORY = 'https://github.com/CALCLUY/data-2bac-sma';

/**
 * Server-side route contracts for strict grounding. A production deployment
 * should implement these routes against the checked-out repository and pass
 * retrieved excerpts to the Live session or to the French text companion.
 */
export const DATASET_API_ROUTES = {
  search: '/api/2bac-data/search',
  file: '/api/2bac-data/file',
  textCompanion: '/api/2bac-data/text-companion',
} as const;

export const DATASET_MANIFEST_ROUTES = {
  general: repoRoute('manifest.tsv'),
  physiqueChimie: repoRoute('pc-manifest.tsv'),
  svt: repoRoute('svt-manifest.tsv'),
  examens: repoRoute('examens-manifest.tsv'),
  // These are present in the repository and are useful when filtering exams.
  physiqueChimieExamens: repoRoute('pc-examens-manifest.tsv'),
  svtExamens: repoRoute('svt-examens-manifest.tsv'),
} as const;

export const SUBJECT_PROFILES: Record<SubjectId, SubjectProfile> = {
  mathematiques: {
    id: 'mathematiques',
    label: 'Mathématiques',
    shortLabel: 'Maths',
    voiceName: 'Charon',
    teacherName: 'الأستاذ ديال الرياضيات',
    routes: {
      subjectRoot: `${DATASET_ROOT}/mathematiques`,
      manifests: [DATASET_MANIFEST_ROUTES.general, DATASET_MANIFEST_ROUTES.examens],
      sections: {
        chapters: `${DATASET_ROOT}/mathematiques/chapitre-01..chapitre-12`,
        correctedHomework: `${DATASET_ROOT}/mathematiques/devoirs-corriges`,
        nationalExams: `${DATASET_ROOT}/mathematiques/examens-nationaux`,
      },
    },
  },
  'physique-chimie': {
    id: 'physique-chimie',
    label: 'Physique-Chimie',
    shortLabel: 'PC',
    voiceName: 'Orus',
    teacherName: 'الأستاذ ديال الفيزيك والكيمياء',
    routes: {
      subjectRoot: `${DATASET_ROOT}/physique-chimie`,
      manifests: [
        DATASET_MANIFEST_ROUTES.physiqueChimie,
        DATASET_MANIFEST_ROUTES.examens,
        DATASET_MANIFEST_ROUTES.physiqueChimieExamens,
      ],
      sections: {
        semester1: `${DATASET_ROOT}/physique-chimie/semestre-1/01..16`,
        semester2: `${DATASET_ROOT}/physique-chimie/semestre-2/17..29`,
        correctedHomeworkSM: `${DATASET_ROOT}/physique-chimie/devoirs-sm`,
        correctedHomeworkSPC: `${DATASET_ROOT}/physique-chimie/devoirs-spc`,
        nationalExams: `${DATASET_ROOT}/physique-chimie/examens-nationaux`,
      },
    },
  },
  svt: {
    id: 'svt',
    label: 'SVT',
    shortLabel: 'SVT',
    voiceName: 'Kore',
    teacherName: 'الأستاذ ديال علوم الحياة والأرض',
    routes: {
      subjectRoot: `${DATASET_ROOT}/svt`,
      manifests: [DATASET_MANIFEST_ROUTES.svt, DATASET_MANIFEST_ROUTES.examens, DATASET_MANIFEST_ROUTES.svtExamens],
      sections: {
        geneticInformationTransfer: `${DATASET_ROOT}/svt/transfert-information-genetique`,
        populationGenetics: `${DATASET_ROOT}/svt/variation-et-genetique-des-populations`,
        homework: `${DATASET_ROOT}/svt/devoirs`,
        nationalExams: `${DATASET_ROOT}/svt/examens-nationaux`,
      },
    },
  },
};

export function datasetScopeFor(subject: SubjectId): string {
  const profile = SUBJECT_PROFILES[subject];
  const sectionLines = Object.entries(profile.routes.sections)
    .map(([name, route]) => `- ${name}: ${route}`)
    .join('\n');

  return [
    `Repository: ${DATASET_REPOSITORY}`,
    `Active subject root: ${profile.routes.subjectRoot}`,
    `Manifest routes: ${profile.routes.manifests.join(', ')}`,
    `Retrieval search route: ${DATASET_API_ROUTES.search}`,
    `Retrieval file route: ${DATASET_API_ROUTES.file}`,
    `French text-companion route: ${DATASET_API_ROUTES.textCompanion}`,
    'Subject section routes:',
    sectionLines,
  ].join('\n');
}