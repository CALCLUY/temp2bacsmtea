import { DATASET_ROOT, type SubjectId } from './dataset';

/**
 * When a user selects a chapter, both the lesson content and relevant Examen
 * National questions must be loaded into the Gemini Live session context.
 *
 * In a production deployment these would be retrieved from the checked-out
 * 2bac-data-sma repository via the backend routes in dataset.ts. Here we
 * define the canonical context shape and the retrieval contracts so the
 * system prompt can reference them and the frontend can request them.
 */

/** Numeric chapter id, e.g. 1..=12 for Math or 1..=16/17..=29 for PC. */
export type ChapterId = number;

/** Section label inside a subject. */
export type ChapterSection =
  | 'mathematiques-chapitres'
  | 'pc-semestre-1'
  | 'pc-semestre-2'
  | 'pc-examens'
  | 'svt-transfert'
  | 'svt-variation-population';

export interface ChapterContext {
  subject: SubjectId;
  chapterId: ChapterId;
  /** Human label for the chapter (e.g. "Chapitre 3 - Limites et continuité"). */
  label: string;
  section: ChapterSection;
  /** Lesson file path(s) to load for this chapter. */
  lessonPaths: string[];
  /** Examen National questions relevant to this chapter (year, session, exercise). */
  examRefs: ExamNationalRef[];
  /** Optional: direct lesson excerpt to inject into the session context. */
  lessonExcerpt?: string;
  /** Optional: exam question excerpts to inject into the session context. */
  examExcerpts?: ExamExcerpt[];
}

export interface ExamNationalRef {
  year: number;
  session: 'Session Normale' | 'Session de Contrôle' | 'Session Rattrapage';
  /** Exercise number within the exam (e.g. 2, 3, 4). */
  exercise: number;
  /** Short marker so the teacher can locate the item in the dataset. */
  marker: string;
  subject: SubjectId;
}

export interface ExamExcerpt {
  ref: ExamNationalRef;
  /** The official exam statement, kept in formal French. */
  statement: string;
  /** The official solution or correction snippet, kept in formal French. */
  solution?: string;
  /** Full source path in the dataset for citation. */
  sourcePath: string;
}

/**
 * Map of subject -> chapter id -> chapter context reference.
 *
 * In production this is built from the manifest TSV files at
 * DATASET_MANIFEST_ROUTES.general and the examens manifest routes, plus the
 * actual lesson and exam text files under examens-nationaux/.
 */
export function chapterContextFor(subject: SubjectId, chapterId: ChapterId): ChapterContext {
  const section = subjectSectionFor(subject, chapterId);
  const lessonPaths = lessonPathsFor(subject, chapterId);
  const examRefs = examRefsFor(subject);

  return {
    subject,
    chapterId,
    label: chapterLabelFor(subject, chapterId),
    section,
    lessonPaths,
    examRefs,
    lessonExcerpt: undefined,
    examExcerpts: undefined,
  };
}

function subjectSectionFor(subject: SubjectId, chapterId: number): ChapterSection {
  if (subject === 'mathematiques') {
    return 'mathematiques-chapitres';
  }
  if (subject === 'physique-chimie') {
    return chapterId <= 16 ? 'pc-semestre-1' : 'pc-semestre-2';
  }
  // SVT has two big topics; we map by chapter id heuristically.
  return chapterId <= 12 ? 'svt-transfert' : 'svt-variation-population';
}

function lessonPathsFor(subject: SubjectId, chapterId: number): string[] {
  if (subject === 'mathematiques') {
    return [
      `${DATASET_ROOT}/mathematiques/chapitre-${String(chapterId).padStart(2, '0')}/cours-partie1.txt`,
      `${DATASET_ROOT}/mathematiques/chapitre-${String(chapterId).padStart(2, '0')}/cours-partie2.txt`,
    ];
  }
  if (subject === 'physique-chimie') {
    const dir = chapterId <= 16
      ? `physique-chimie/semestre-1/${String(chapterId).padStart(2, '0')}`
      : `physique-chimie/semestre-2/${String(chapterId).padStart(2, '0')}`;
    return [
      `${DATASET_ROOT}/${dir}/cours-partie1.txt`,
      `${DATASET_ROOT}/${dir}/cours-partie2.txt`,
    ];
  }
  // SVT
  const topic = chapterId <= 12 ? 'transfert-information-genetique' : 'variation-et-genetique-des-populations';
  return [
    `${DATASET_ROOT}/svt/${topic}/cours-partie1.txt`,
    `${DATASET_ROOT}/svt/${topic}/cours-partie2.txt`,
  ];
}

function examRefsFor(subject: SubjectId): ExamNationalRef[] {
  // In production this is computed from examens-manifest.tsv by matching
  // chapter/topic keywords. Here we return a placeholder set so the prompt
  // contract is explicit and the frontend can request them.
  const session: 'Session Normale' | 'Session de Contrôle' | 'Session Rattrapage' = 'Session Normale';

  if (subject === 'mathematiques') {
    return [
      { year: 2021, session, exercise: 2, marker: `mathematiques/examens-nationaux/2021/session-normale/exercice-2`, subject },
      { year: 2022, session, exercise: 1, marker: `mathematiques/examens-nationaux/2022/session-normale/exercice-1`, subject },
      { year: 2023, session, exercise: 2, marker: `mathematiques/examens-nationaux/2023/session-normale/exercice-2`, subject },
    ];
  }

  if (subject === 'physique-chimie') {
    return [
      { year: 2021, session, exercise: 2, marker: `physique-chimie/examens-nationaux/2021/session-normale/exercice-2`, subject },
      { year: 2022, session, exercise: 3, marker: `physique-chimie/examens-nationaux/2022/session-normale/exercice-3`, subject },
      { year: 2023, session, exercise: 2, marker: `physique-chimie/examens-nationaux/2023/session-normale/exercice-2`, subject },
    ];
  }

  // SVT
  return [
    { year: 2021, session, exercise: 2, marker: `svt/examens-nationaux/2021/session-normale/exercice-2`, subject },
    { year: 2022, session, exercise: 1, marker: `svt/examens-nationaux/2022/session-normale/exercice-1`, subject },
    { year: 2023, session, exercise: 2, marker: `svt/examens-nationaux/2023/session-normale/exercice-2`, subject },
  ];
}

function chapterLabelFor(subject: SubjectId, chapterId: number): string {
  if (subject === 'mathematiques') {
    return `Chapitre ${chapterId}`;
  }
  if (subject === 'physique-chimie') {
    const sem = chapterId <= 16 ? 'Semestre 1' : 'Semestre 2';
    return `${sem} - Chapitre ${chapterId}`;
  }
  const topic = chapterId <= 12 ? 'Transfert de l’information génétique' : 'Variation et génétique des populations';
  return `${topic} - Chapitre ${chapterId}`;
}

/**
 * Build the session context string that is appended to the systemInstruction
 * when a chapter is selected. It tells Gemini exactly which lesson file and
 * which Examen National questions are available for this chapter.
 */
export function buildChapterSessionContext(ctx: ChapterContext): string {
  const lines: string[] = [];

  lines.push(`## ACTIVE CHAPTER CONTEXT`);
  lines.push('');
  lines.push(`Subject: ${ctx.subject}`);
  lines.push(`Chapter: ${ctx.label} (id ${ctx.chapterId})`);
  lines.push(`Lesson section: ${ctx.section}`);
  lines.push('');
  lines.push('Lesson files to load into the session (retrieve from the dataset):');
  for (const p of ctx.lessonPaths) {
    lines.push(`- ${p}`);
  }
  lines.push('');
  lines.push('Relevant Examen National questions for this chapter (2010 to 2026 for Math/PC, 2016 to 2025 for SVT):');
  for (const exam of ctx.examRefs) {
    lines.push(
      `- ${exam.session} ${exam.year}, Exercice ${exam.exercise} (${exam.marker})`,
    );
  }

  if (ctx.lessonExcerpt) {
    lines.push('');
    lines.push('## LESSON EXCERPT (INJECTED IN SESSION CONTEXT)');
    lines.push('');
    lines.push(ctx.lessonExcerpt);
  }

  if (ctx.examExcerpts && ctx.examExcerpts.length > 0) {
    lines.push('');
    lines.push('## EXTRACTION OF EXTRANATIONAL QUESTIONS (INJECTED IN SESSION CONTEXT)');
    for (const ex of ctx.examExcerpts) {
      lines.push('');
      lines.push(`Examen National (${ex.ref.session} ${ex.ref.year} - Exercice ${ex.ref.exercise})`);
      lines.push(`> Source: ${ex.sourcePath}`);
      lines.push('');
      lines.push(`${ex.statement}`);
      if (ex.solution) {
        lines.push('');
        lines.push('Solution officielle (extrait) :');
        lines.push(`${ex.solution}`);
      }
    }
  }

  return lines.join('\n');
}

/**
 * When the chapter changes, rebuild the systemInstruction so the teacher
 * knows exactly which lesson and exam content is available in this session.
 */
export function systemInstructionWithChapterContext(
  baseSystemInstruction: string,
  ctx: ChapterContext,
): string {
  const chapterContext = buildChapterSessionContext(ctx);
  return `${baseSystemInstruction}

${chapterContext}

When answering for THIS chapter, always:
- Use the lesson files listed above as your primary course reference.
- Use the listed Examen National questions as your source for real exam examples and comprehension checks.
- Cite the exact exam session and year in the written exam block.
- Never invent a chapter, exercise, year, session, or exam statement not listed here.`;
}
