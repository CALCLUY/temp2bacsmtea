/**
 * Interactive lesson protocol shared by the prompt and the UI.
 *
 * The teacher ends every micro-part with exactly ONE of:
 *  a) a QCM exercise: the question is SPOKEN as the continuation of the
 *     explanation, and only the choices are emitted as a JSON block, or
 *  b) a spoken yes/no question plus the [CHECK_UNDERSTANDING] tag.
 *
 * Choices and the spoken question may be written in Moroccan Darija or in
 * French depending on the situation (French inside LaTeX for formal work).
 */

export interface ParsedQcm {
  /**
   * Optional. The teacher normally asks the question out loud, so the panel
   * shows only the choices under the spoken sentence.
   */
  question?: string;
  options: string[];
  correctIndex: number;
}

export interface ParsedModelContent {
  /** Transcript with QCM blocks and control tags removed. */
  displayText: string;
  qcms: ParsedQcm[];
  wantsCheck: boolean;
}

export const CHECK_TAG = '[CHECK_UNDERSTANDING]';
export const QCM_LETTERS = ['A', 'B', 'C', 'D', 'E', 'F'];

function tryParseQcm(value: unknown): ParsedQcm | null {
  if (!value || typeof value !== 'object') return null;
  const o = value as Record<string, unknown>;
  if (o.type !== 'qcm') return null;
  const question = typeof o.question === 'string' && o.question.trim().length > 0 ? o.question.trim() : undefined;
  if (!Array.isArray(o.options) || o.options.length < 2 || o.options.length > QCM_LETTERS.length) return null;
  if (!o.options.every((x) => typeof x === 'string' && (x as string).trim().length > 0)) return null;
  const ci = o.correctIndex;
  if (typeof ci !== 'number' || !Number.isInteger(ci) || ci < 0 || ci >= o.options.length) return null;
  return { question, options: o.options as string[], correctIndex: ci };
}

/** Extract a balanced {...} JSON candidate starting at `start` (string-aware). */
function extractBalancedJson(text: string, start: number): string | null {
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let i = start; i < text.length; i++) {
    const ch = text[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === '"') inString = false;
    } else {
      if (ch === '"') inString = true;
      else if (ch === '{') depth++;
      else if (ch === '}') {
        depth--;
        if (depth === 0) return text.slice(start, i + 1);
      }
    }
  }
  return null;
}

/** Remove complete QCM objects (raw or fenced) and collect them. */
function extractAndRemoveQcms(input: string): { text: string; qcms: ParsedQcm[] } {
  let text = input;
  const qcms: ParsedQcm[] = [];

  // 1) Fenced code blocks.
  text = text.replace(/```(?:json)?\s*\n?([\s\S]*?)```/gi, (full, inner: string) => {
    const candidate = String(inner).trim();
    if (/"type"\s*:\s*"qcm"/.test(candidate)) {
      try {
        const parsed = tryParseQcm(JSON.parse(candidate));
        if (parsed) {
          qcms.push(parsed);
          return '\n';
        }
      } catch {
        /* not valid JSON — leave the fence untouched */
      }
    }
    return full;
  });

  // 2) Raw JSON objects marked with "type": "qcm".
  const removals: string[] = [];
  let searchFrom = 0;
  for (;;) {
    const qcmIdx = text.indexOf('"qcm"', searchFrom);
    if (qcmIdx === -1) break;
    const braceIdx = text.lastIndexOf('{', qcmIdx);
    if (braceIdx < searchFrom) {
      searchFrom = qcmIdx + 5;
      continue;
    }
    const candidate = extractBalancedJson(text, braceIdx);
    if (!candidate) {
      searchFrom = qcmIdx + 5;
      continue;
    }
    try {
      const parsed = tryParseQcm(JSON.parse(candidate));
      if (parsed) {
        qcms.push(parsed);
        removals.push(candidate);
        searchFrom = braceIdx + candidate.length;
        continue;
      }
    } catch {
      /* not valid JSON — keep scanning */
    }
    searchFrom = qcmIdx + 5;
  }
  for (const r of removals) text = text.replace(r, '\n');

  return { text, qcms };
}

/** Drop an unterminated trailing [CHEC... fragment while the tag is streaming. */
function stripPartialCheckTag(text: string): string {
  const idx = text.lastIndexOf('[');
  if (idx === -1) return text;
  if (text.indexOf(']', idx) !== -1) return text;
  const fragment = text.slice(idx + 1).toUpperCase();
  if (fragment.length > 0 && fragment.length < CHECK_TAG.length && CHECK_TAG.slice(1).toUpperCase().startsWith(fragment)) {
    return text.slice(0, idx);
  }
  return text;
}

/** Drop an unterminated trailing JSON object (a QCM being written right now). */
function stripPartialJson(text: string): string {
  const lastBrace = text.lastIndexOf('{');
  if (lastBrace === -1) return text;
  const tail = text.slice(lastBrace);
  if (tail.includes('}')) return text;
  if (tail.length > 600) return text;
  return text.slice(0, lastBrace);
}

/**
 * Interim transcript while the teacher is still talking: keeps the visible text
 * clean so partial JSON blocks and control tags never flash on screen.
 */
export function sanitizeStreamingText(raw: string): string {
  let text = raw;
  text = text.replace(/```[\s\S]*?```/g, '\n');
  const openFence = text.indexOf('```');
  if (openFence !== -1) text = text.slice(0, openFence);
  text = extractAndRemoveQcms(text).text;
  text = stripPartialCheckTag(text);
  text = stripPartialJson(text);
  return text.replace(/\n{3,}/g, '\n\n').trim();
}

/**
 * Detects a question that can genuinely be answered with yes / no,
 * e.g. "واش فهمتي؟", "واش هاد الشي صحيح؟", "واش متأكد؟", "Est-ce que c'est clair ?".
 * Open questions ("شنو هي…", "كيفاش…", "combien…") must NOT trigger the yes/no bar.
 */
export function looksLikeYesNoQuestion(text: string): boolean {
  const tail = text.slice(-260).toLowerCase();
  if (!tail.trim()) return false;

  const openMarkers = /(شنو|شحال|كيفاش|علاش|فين|إيمتى|امتى|أشمن|combien|comment|pourquoi|quelle|quel\b|quels|où|quand|calcule|donne|explique)/i;
  if (openMarkers.test(tail)) return false;

  const strong =
    /(واش|فهمتي|فهمتيني|متأكد|متافق|واضح|مفهوم|صافي|as-tu compris|avez-vous compris|est-ce que|c'est clair|c’est clair|d'accord|d’accord|oui ou non|understood|is this correct|are you sure)/i;
  if (strong.test(tail)) return true;

  const hasQuestionMark = /[?؟]\s*$/.test(tail.trim());
  if (!hasQuestionMark) return false;
  const lastSentence = tail.split(/[.!\n؟?]/).filter(Boolean).pop() ?? '';
  return lastSentence.trim().split(/\s+/).length <= 9;
}

/** Parse a finished teacher message. */
export function parseModelContent(raw: string): ParsedModelContent {
  let text = raw;
  const { text: withoutQcm, qcms } = extractAndRemoveQcms(text);
  text = withoutQcm;

  const hasCheckTag = text.includes(CHECK_TAG);
  if (hasCheckTag) text = text.split(CHECK_TAG).join('');
  text = stripPartialCheckTag(text);

  const displayText = text.replace(/\n{3,}/g, '\n\n').trim();

  // The yes/no bar shows only for a genuine yes/no question, and never next to a QCM.
  const wantsCheck = qcms.length === 0 && (hasCheckTag || looksLikeYesNoQuestion(displayText));

  return { displayText, qcms, wantsCheck };
}

/**
 * True when the spoken transcript already carries the QCM question, in which case
 * the panel shows only the choices (continuity of the teacher's speech).
 */
export function transcriptCoversQuestion(transcript: string, question?: string): boolean {
  // A QCM without a written mirror can never be safely revealed: the UI must
  // be able to prove that the question was actually spoken.
  if (!question) return false;
  const norm = (s: string) =>
    s
      .toLowerCase()
      .replace(/\$[^$]*\$/g, ' ')
      .replace(/[^\p{L}\p{N}]+/gu, ' ')
      .trim();
  const q = norm(question);
  const t = norm(transcript);
  if (!q) return false;
  if (t.includes(q)) return true;
  const words = q.split(' ').filter((w) => w.length > 3);
  if (words.length === 0) return false;
  const hits = words.filter((w) => t.includes(w)).length;
  return hits / words.length >= 0.75;
}

/** Remove a leading "A) " style prefix since the UI renders its own letter badges. */
export function stripOptionPrefix(option: string): string {
  const stripped = option.replace(/^\s*[A-Fa-f][).\-:]\s*/, '').trim();
  return stripped.length > 0 ? stripped : option;
}

/* ---------------- Button wire signals (sent as realtimeInput text) ---------------- */

/**
 * Re-asserted on every student turn: native-audio sessions drift toward French
 * after long formal passages (exam statements, formulas), so the language law
 * is repeated as a short reminder appended to the wire text only.
 */
export const DARIJA_REMINDER =
  '(تذكير: جاوب بالدارجة المغربية فقط، والمصطلحات العلمية بالفرنسية داخل الجمل. متجاوبش بجمل كاملة بالفرنسية. الشرح والسؤال كيكونو كلام واحد متواصل: السؤال هو آخر جملة مسموعة، خاصو يتقال بالصوت ويتسمع قبل أي JSON.)';

/** Append the language reminder to any text sent to the teacher. */
export function withDarijaReminder(wireText: string): string {
  return `${wireText}\n\n${DARIJA_REMINDER}`;
}

export const UNDERSTOOD_DISPLAY = 'صحيح / فهمت — كمل للجزء الجاي';
export const UNDERSTOOD_SIGNAL = `[BUTTON:UNDERSTOOD] The student clicked "صحيح / فهمت" (Understood). Briefly praise them in Darija in one short sentence, then IMMEDIATELY teach the NEXT micro-part with its own visual analogy, and end it with a new QCM JSON block or a spoken "واش فهمتي هاد الجزء؟" plus ${CHECK_TAG}. Do not stall and do not ask what to do next.`;

export const NOT_UNDERSTOOD_DISPLAY = 'خطأ / مافهمتش — عاود الشرح';
export const NOT_UNDERSTOOD_SIGNAL = `[BUTTON:NOT_UNDERSTOOD] The student clicked "خطأ / مافهمتش" (Not understood). Do NOT advance to the next part. Re-teach the SAME micro-part from zero using a DIFFERENT, simpler visual analogy than before, then end with a NEW check: if you use a QCM it must be a fresh similar question (different wording, shuffled options, different values), never the same one; otherwise ask a spoken yes/no question plus ${CHECK_TAG}.`;

export function buildQcmAnswerSignal(
  qcm: ParsedQcm,
  optionIndex: number,
): { display: string; signal: string } {
  const letter = QCM_LETTERS[optionIndex] ?? String(optionIndex + 1);
  const correctLetter = QCM_LETTERS[qcm.correctIndex] ?? String(qcm.correctIndex + 1);
  const labeled = qcm.options
    .map((o, i) => `${QCM_LETTERS[i] ?? i + 1}) ${stripOptionPrefix(o)}`)
    .join(' | ');
  const chosen = stripOptionPrefix(qcm.options[optionIndex] ?? '');
  const questionRef = qcm.question ? `"${qcm.question}"` : 'the question you just asked out loud';
  const isCorrect = optionIndex === qcm.correctIndex;

  const correctFlow = `The student is CORRECT. Praise briefly in Darija, explain in one short line why option ${correctLetter} is right, then IMMEDIATELY teach the next micro-part.`;

  const wrongFlow = `The student is WRONG (correct was option ${correctLetter}). Follow this recovery sequence strictly:
1. Say in Darija that the answer is not correct and give the correct option in one short sentence.
2. RE-EXPLAIN the same micro-part from zero using a DIFFERENT, simpler visual analogy than the one you already used. Do not just restate the correct option.
3. Then ask a NEW SIMILAR QCM: same concept and same difficulty, but a DIFFERENT question with DIFFERENT wording, different option order, and if possible different values or a different everyday example. NEVER repeat the previous question or reuse the same options verbatim.
4. Emit the new QCM as a fresh JSON block. Do not advance to the next micro-part until the student answers this new QCM correctly.`;

  return {
    display: `جوابي: ${letter}) ${chosen}`,
    signal: `[BUTTON:QCM_ANSWER] The student answered the QCM for ${questionRef}. Options: ${labeled}. The student chose option ${letter} ("${chosen}"). ${isCorrect ? correctFlow : wrongFlow}`,
  };
}
