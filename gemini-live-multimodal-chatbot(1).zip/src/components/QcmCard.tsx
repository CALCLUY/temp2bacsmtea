import { QCM_LETTERS, stripOptionPrefix, type ParsedQcm } from '../lib/interaction';
import { cn } from '../utils/cn';

interface Props {
  qcm: ParsedQcm;
  /** Index the student picked, or null if unanswered. */
  selected: number | null;
  disabled?: boolean;
  onSelect: (index: number) => void;
}

export default function QcmCard({ qcm, selected, disabled, onSelect }: Props) {
  const answered = selected !== null;
  const isCorrect = answered && selected === qcm.correctIndex;

  return (
    <div className="mt-2 w-full rounded-2xl border border-sky-900/40 bg-zinc-900/80 p-3 shadow-md">
      {/* ALWAYS display the question if provided, formatted with clear visual priority */}
      {qcm.question ? (
        <div dir="auto" className="mb-3 border-b border-zinc-800/80 pb-2">
          <div className="mb-1 flex items-center gap-1.5 text-[11px] font-semibold text-sky-400">
            <span className="h-2 w-2 rounded-full bg-sky-400 animate-pulse" />
            <span>السؤال / Question :</span>
          </div>
          <p className="text-sm font-medium leading-relaxed text-zinc-100">
            {qcm.question}
          </p>
        </div>
      ) : (
        <div className="mb-2 flex items-center gap-2 text-[11px] text-sky-300/80">
          <span className="h-3 w-px bg-sky-500/50" />
          <span dir="auto">اختار الجواب — كليك واحد :</span>
        </div>
      )}

      <div className="grid gap-2">
        {qcm.options.map((opt, i) => {
          const letter = QCM_LETTERS[i] ?? `${i + 1}`;
          const isSel = selected === i;
          const isRight = qcm.correctIndex === i;
          return (
            <button
              key={i}
              type="button"
              disabled={disabled || answered}
              onClick={() => onSelect(i)}
              className={cn(
                'flex items-center gap-3 rounded-xl border px-3 py-2 text-left text-sm transition-all',
                !answered && !disabled && 'border-zinc-700 bg-zinc-900 hover:border-sky-400 hover:bg-sky-950/40 hover:text-white',
                !answered && disabled && 'cursor-not-allowed border-zinc-800 bg-zinc-900/60 opacity-60',
                answered && isSel && isRight && 'border-emerald-400 bg-emerald-950/50 text-emerald-100',
                answered && isSel && !isRight && 'border-rose-500 bg-rose-950/50 text-rose-100',
                answered && !isSel && isRight && 'border-emerald-500/60 bg-emerald-950/20',
                answered && !isSel && !isRight && 'border-zinc-800 bg-zinc-900/50 opacity-50',
              )}
            >
              <span
                className={cn(
                  'flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-xs font-bold',
                  answered && isRight ? 'bg-emerald-500 text-white' : answered && isSel ? 'bg-rose-500 text-white' : 'bg-zinc-700 text-zinc-200',
                )}
              >
                {letter}
              </span>
              <span dir="auto" className="flex-1">
                {stripOptionPrefix(opt)}
              </span>
              {answered && isRight && <span className="font-bold text-emerald-400">✓</span>}
              {answered && isSel && !isRight && <span className="font-bold text-rose-400">✗</span>}
            </button>
          );
        })}
      </div>

      {answered && (
        <p dir="auto" className={cn('mt-2 text-xs', isCorrect ? 'text-emerald-300' : 'text-rose-300')}>
          {isCorrect
            ? 'صحيح! برافو عليك — الأستاذ غادي يكمل للجزء الجاي.'
            : `الجواب الصحيح هو ${QCM_LETTERS[qcm.correctIndex]} — سمع الشرح ديال الأستاذ مزيان.`}
        </p>
      )}
    </div>
  );
}
