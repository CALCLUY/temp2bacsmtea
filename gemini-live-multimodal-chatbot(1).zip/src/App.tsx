import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { GeminiLiveClient, LIVE_MODEL, type InteractionStatus, type VoiceName } from './lib/geminiLive';
import { SUBJECT_PROFILES, type SubjectId } from './lib/dataset';
import { buildSystemInstruction, STARTER_PROMPTS } from './lib/prompts';
import { persistGeminiApiKey, readStoredGeminiApiKey } from './lib/arenaIntegration';
import { chapterContextFor, systemInstructionWithChapterContext } from './lib/chapterContext';
import { PcmStreamPlayer } from './lib/audioPlayer';
import VoiceVisualizer from './components/VoiceVisualizer';
import QcmCard from './components/QcmCard';
import ComprehensionBar from './components/ComprehensionBar';
import {
  buildQcmAnswerSignal,
  NOT_UNDERSTOOD_DISPLAY,
  NOT_UNDERSTOOD_SIGNAL,
  parseModelContent,
  sanitizeStreamingText,
  transcriptCoversQuestion,
  UNDERSTOOD_DISPLAY,
  UNDERSTOOD_SIGNAL,
  withDarijaReminder,
  type ParsedQcm,
} from './lib/interaction';
import { cn } from './utils/cn';

type ConnState = 'disconnected' | 'connecting' | 'ready' | 'error';

interface Message {
  id: string;
  role: 'user' | 'model' | 'system';
  text: string;
  /** Only the server's output-audio transcript; used to prove a QCM was spoken. */
  audioTranscript?: string;
  streaming?: boolean;
  ts: number;
}

const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

/** Micro-step protocol quick actions (sent as realtimeInput text). */
const MICRO_STEP_ACTIONS: { label: string; text: string }[] = [
  { label: "Wasel l'part li jija 👉", text: 'Bravo, wasel b l\'part li jija.' },
  { label: 'ما فهمتش — عاود بطريقة أخرى', text: 'ما فهمتش هاد l\'part، عاود ليا من الصفر بطريقة أو مثال آخر.' },
  { label: 'عطيني مثال من الحياة', text: 'عطيني مثال آخر من الحياة اليومية باش نفهم هاد l\'notion.' },
];

export default function App() {
  const [apiKey, setApiKey] = useState<string>(() => readStoredGeminiApiKey());
  const [rememberKey, setRememberKey] = useState<boolean>(() => !!readStoredGeminiApiKey());
  const [showKey, setShowKey] = useState(false);
  const [subject, setSubject] = useState<SubjectId>('mathematiques');
  const [voice, setVoice] = useState<VoiceName>(SUBJECT_PROFILES.mathematiques.voiceName);
  const [chapter, setChapter] = useState<number>(1);
  const [systemInstruction, setSystemInstruction] = useState<string>(() => buildSystemInstruction('mathematiques'));
  const [showPrompt, setShowPrompt] = useState(false);
  const [chapterLabel, setChapterLabel] = useState<string>('Chapitre 1');

  const [conn, setConn] = useState<ConnState>('disconnected');
  const [interaction, setInteraction] = useState<InteractionStatus>('IDLE');
  const [speaking, setSpeaking] = useState(false);
  const [muted, setMuted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [showTextInput, setShowTextInput] = useState(false);
  const [qcmAnswers, setQcmAnswers] = useState<Record<string, number>>({});

  const clientRef = useRef<GeminiLiveClient | null>(null);
  const playerRef = useRef<PcmStreamPlayer | null>(null);
  const currentModelMsgId = useRef<string | null>(null);
  const mutedRef = useRef(false);
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  // Prevent infinite repair loops if a model ignores the spoken-question protocol.
  const qcmRepairAttempts = useRef(new Set<string>());

  useEffect(() => {
    mutedRef.current = muted;
    if (muted) playerRef.current?.stop();
  }, [muted]);

  // Auto-scroll on new content.
  useEffect(() => {
    const el = listRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, interaction]);

  const player = useMemo(() => {
    const p = new PcmStreamPlayer(24000);
    p.setStateListener(setSpeaking);
    playerRef.current = p;
    return p;
  }, []);

  const pushSystem = useCallback((text: string) => {
    setMessages((m) => [...m, { id: uid(), role: 'system', text, ts: Date.now() }]);
  }, []);

  const appendModelText = useCallback((chunk: string, isAudioTranscript = false) => {
    setMessages((prev) => {
      const id = currentModelMsgId.current;
      if (id) {
        const idx = prev.findIndex((m) => m.id === id);
        if (idx !== -1) {
          const copy = [...prev];
          copy[idx] = {
            ...copy[idx],
            text: copy[idx].text + chunk,
            audioTranscript: isAudioTranscript ? (copy[idx].audioTranscript ?? '') + chunk : copy[idx].audioTranscript,
            streaming: true,
          };
          return copy;
        }
      }
      const newId = uid();
      currentModelMsgId.current = newId;
      return [
        ...prev,
        {
          id: newId,
          role: 'model',
          text: chunk,
          audioTranscript: isAudioTranscript ? chunk : '',
          streaming: true,
          ts: Date.now(),
        },
      ];
    });
  }, []);

  const finalizeModelMessage = useCallback(() => {
    const id = currentModelMsgId.current;
    if (!id) return;
    setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, streaming: false } : m)));
    currentModelMsgId.current = null;
  }, []);

  const disconnect = useCallback(() => {
    clientRef.current?.disconnect();
    clientRef.current = null;
    player.stop();
    finalizeModelMessage();
    setConn('disconnected');
    setInteraction('IDLE');
  }, [player, finalizeModelMessage]);

  const selectSubject = useCallback(
    (nextSubject: SubjectId) => {
      if (nextSubject === subject) return;
      const wasActive = conn === 'ready' || conn === 'connecting';
      if (wasActive) disconnect();

      const nextProfile = SUBJECT_PROFILES[nextSubject];
      setSubject(nextSubject);
      setVoice(nextProfile.voiceName);
      setChapter(1);
      setChapterLabel('');
      setSystemInstruction(buildSystemInstruction(nextSubject));
      setError(null);
      pushSystem(
        wasActive
          ? `${nextProfile.label} selected. Reconnect to start ${nextProfile.teacherName} (${nextProfile.voiceName}).`
          : `${nextProfile.label} selected. Teacher voice: ${nextProfile.voiceName}.`,
      );
    },
    [conn, disconnect, pushSystem, subject],
  );

  const selectChapter = useCallback(
    (nextChapter: number) => {
      if (nextChapter === chapter) return;
      const wasActive = conn === 'ready' || conn === 'connecting';
      const ctx = chapterContextFor(subject, nextChapter);
      setChapter(nextChapter);
      setChapterLabel(ctx.label);
      setSystemInstruction(systemInstructionWithChapterContext(buildSystemInstruction(subject), ctx));
      setError(null);
      pushSystem(
        wasActive
          ? `Chapter ${nextChapter} loaded — lesson + Examen National context mounted for ${ctx.label}. Reconnect to apply.`
          : `${ctx.label} selected. Lesson + Examen National context ready for ${subject}.`,
      );
    },
    [conn, disconnect, subject, pushSystem, chapter],
  );

  const chapterOptionsFor = useCallback((subject: SubjectId) => {
    const maxChapter =
      subject === 'mathematiques'
        ? 12
        : subject === 'physique-chimie'
          ? 29
          : 24;
    return Array.from({ length: maxChapter }, (_, i) => {
      const id = i + 1;
      const ctx = chapterContextFor(subject, id);
      return { id, label: ctx.label };
    });
  }, []);

  const connect = useCallback(async () => {
    const key = apiKey.trim();
    if (!key) {
      setError('Please enter your Gemini API key.');
      return;
    }
    setError(null);
    persistGeminiApiKey(key, rememberKey);

    // Unlock audio playback inside the user gesture.
    await player.ensureContext();

    clientRef.current?.disconnect();
    setConn('connecting');
    setInteraction('IDLE');

    const client = new GeminiLiveClient(
      { apiKey: key, model: LIVE_MODEL, subject, voice, systemInstruction },
      {
        onSetupComplete: () => {
          setConn('ready');
          pushSystem(
            `Connected to ${LIVE_MODEL} · voice ${voice} · micro-step mode: 1 micro-part + 1 question per turn`,
          );
          setTimeout(() => inputRef.current?.focus(), 50);
        },
        onAudioChunk: (b64, mime) => {
          player.setReceivingStream(true);
          if (!mutedRef.current) void player.enqueueBase64(b64, mime);
        },
        onOutputTranscription: (t) => appendModelText(t, true),
        onModelText: (t) => appendModelText(t),
        onInteractionStatus: (s) => setInteraction(s),
        onTurnComplete: () => {
          player.setReceivingStream(false);
          finalizeModelMessage();
        },
        onInterrupted: () => {
          player.stop();
          finalizeModelMessage();
        },
        onGoAway: (timeLeft) => pushSystem(`Server will close the session soon${timeLeft ? ` (${timeLeft})` : ''}.`),
        onError: (m) => {
          setError(m);
          setConn((c) => (c === 'ready' ? c : 'error'));
        },
        onClose: (code, reason) => {
          finalizeModelMessage();
          setInteraction('IDLE');
          setConn((c) => {
            if (c === 'connecting' || code !== 1000) {
              setError(
                reason
                  ? `Connection closed (${code}): ${reason}`
                  : `Connection closed (${code}). ${code === 1008 || code === 1007 ? 'Check your API key or model access.' : ''}`,
              );
              return 'error';
            }
            return 'disconnected';
          });
          if (code === 1000) pushSystem('Session ended.');
        },
      },
    );
    clientRef.current = client;
    client.connect();
  }, [apiKey, rememberKey, subject, voice, systemInstruction, player, pushSystem, appendModelText, finalizeModelMessage]);

  useEffect(() => () => {
    clientRef.current?.disconnect();
    void player.close();
  }, [player]);

  const send = useCallback(() => {
    const text = input.trim();
    if (!text || !clientRef.current?.isReady) return;
    // If the model is still speaking, cut it off so the new reply is heard cleanly.
    player.stop();
    finalizeModelMessage();
    setMessages((m) => [...m, { id: uid(), role: 'user', text, ts: Date.now() }]);
    setInput('');
    setInteraction('IN_PROGRESS');
    // Typed questions are often in French; the reminder keeps the answer in Darija.
    clientRef.current.sendText(withDarijaReminder(text));
  }, [input, player, finalizeModelMessage]);

  /**
   * Send a student signal to Gemini: `displayText` is what appears in the chat,
   * `wireText` is what is transmitted over the Live session.
   */
  const sendSignal = useCallback(
    (displayText: string, wireText: string) => {
      if (!wireText || !clientRef.current?.isReady) return;
      player.stop();
      finalizeModelMessage();
      setMessages((m) => [...m, { id: uid(), role: 'user', text: displayText, ts: Date.now() }]);
      setInteraction('IN_PROGRESS');
      // The reminder rides on the wire only; the student never sees it.
      clientRef.current.sendText(withDarijaReminder(wireText));
    },
    [player, finalizeModelMessage],
  );

  const sendQuickAction = useCallback((text: string) => sendSignal(text, text), [sendSignal]);

  const handleUnderstood = useCallback(() => sendSignal(UNDERSTOOD_DISPLAY, UNDERSTOOD_SIGNAL), [sendSignal]);

  const handleNotUnderstood = useCallback(
    () => sendSignal(NOT_UNDERSTOOD_DISPLAY, NOT_UNDERSTOOD_SIGNAL),
    [sendSignal],
  );

  const handleQcmSelect = useCallback(
    (messageId: string, qcmIndex: number, qcm: ParsedQcm, optionIndex: number) => {
      const key = `${messageId}:${qcmIndex}`;
      if (qcmAnswers[key] !== undefined) return;
      setQcmAnswers((prev) => ({ ...prev, [key]: optionIndex }));
      const { display, signal } = buildQcmAnswerSignal(qcm, optionIndex);
      sendSignal(display, signal);
    },
    [qcmAnswers, sendSignal],
  );

  const onKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  };

  const isReady = conn === 'ready';
  const busy = isReady && (interaction === 'IN_PROGRESS' || speaking);
  const lastMessage = messages.length > 0 ? messages[messages.length - 1] : null;
  const waitingForStudent = isReady && !speaking && interaction === 'IDLE' && lastMessage?.role === 'model';
  const profile = SUBJECT_PROFILES[subject];
  // Only the latest teacher message keeps live buttons, so old checks can't hijack the lesson flow.
  const lastModelId = [...messages].reverse().find((m) => m.role === 'model')?.id ?? null;

  useEffect(() => {
    const lastModel = [...messages].reverse().find((m) => m.role === 'model');
    if (!isReady || speaking || !lastModel || lastModel.streaming || !clientRef.current?.isReady) return;

    const parsed = parseModelContent(lastModel.text);
    const missingSpokenQuestion = parsed.qcms.some(
      (qcm) => !transcriptCoversQuestion(lastModel.audioTranscript ?? '', qcm.question),
    );
    if (!missingSpokenQuestion || qcmRepairAttempts.current.has(lastModel.id)) return;

    qcmRepairAttempts.current.add(lastModel.id);
    setInteraction('IN_PROGRESS');
    // Invisible protocol repair: the original choices remain withheld. Gemini's next
    // voice turn must contain the full question, then its replacement QCM is usable.
    clientRef.current.sendText(
      withDarijaReminder(
        '[PROTOCOL REPAIR] A QCM control block arrived, but the full question was NOT present in your output-audio transcript. Do not explain a new lesson. Repeat the COMPLETE original QCM question now as the final sentence of one continuous Darija voice response, then emit a fresh JSON QCM block containing the same full question field and choices. The student must hear the entire question before any choices can be displayed.',
      ),
    );
  }, [isReady, messages, speaking]);

  return (
    <div className="flex h-screen w-full flex-col bg-zinc-950 text-zinc-100">
      {/* Header */}
      <header className="border-b border-zinc-800/80 bg-zinc-950/80 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center gap-3 px-4 py-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 via-fuchsia-500 to-sky-400 shadow-lg shadow-violet-900/40">
            <SparkIcon className="h-5 w-5 text-white" />
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-sm font-semibold tracking-tight sm:text-base">
              Gemini Live · أستاذ 2ème BAC <span className="text-zinc-500">(الدارجة)</span>
            </h1>
            <p className="truncate font-mono text-[11px] text-zinc-500">{LIVE_MODEL}</p>
          </div>
          <StatusPill conn={conn} interaction={interaction} speaking={speaking} />
        </div>
      </header>

      <main className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-4 overflow-hidden px-4 py-4 lg:flex-row">
        {/* Sidebar / settings */}
        <aside className="w-full shrink-0 space-y-4 lg:w-80">
          <section className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-4">
            <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-zinc-400">Session</h2>

            <label className="mb-2 block text-xs text-zinc-400">Choose your teacher</label>
            <div className="grid grid-cols-3 gap-2">
              {(Object.values(SUBJECT_PROFILES) as Array<(typeof SUBJECT_PROFILES)[SubjectId]>).map((profile) => (
                <button
                  key={profile.id}
                  type="button"
                  onClick={() => selectSubject(profile.id)}
                  className={cn(
                    'rounded-lg border px-2 py-2 text-left transition-colors',
                    subject === profile.id
                      ? 'border-violet-500 bg-violet-950/40 text-white'
                      : 'border-zinc-700 bg-zinc-950 text-zinc-400 hover:border-zinc-500 hover:text-zinc-200',
                  )}
                >
                  <span className="block text-xs font-semibold">{profile.shortLabel}</span>
                  <span className="mt-0.5 block truncate text-[10px] text-zinc-500">{profile.voiceName}</span>
                </button>
              ))}
            </div>
            <p dir="auto" className="mt-2 text-[11px] text-zinc-500">
              {SUBJECT_PROFILES[subject].teacherName} · voix {voice}
            </p>

            <label className="mt-3 mb-1 block text-xs text-zinc-400">Lesson chapter</label>
            <div className="flex items-center gap-2">
              <select
                value={chapter}
                onChange={(e) => {
                  const v = Number(e.target.value);
                  if (!Number.isNaN(v) && v !== chapter) selectChapter(v);
                }}
                disabled={isReady || conn === 'connecting'}
                className="flex-1 rounded-lg border border-zinc-700 bg-zinc-950 px-2 py-2 text-sm outline-none focus:border-violet-500 disabled:opacity-60"
              >
                {chapterOptionsFor(subject).map(({ id, label }) => (
                  <option key={id} value={id}>
                    {label}
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={() => {
                  if (isReady || conn === 'connecting') {
                    setError('Disconnect first to change chapter.');
                    return;
                  }
                  selectChapter(chapter);
                }}
                disabled={isReady || conn === 'connecting'}
                className="rounded-lg border border-zinc-700 bg-zinc-800 px-2 py-2 text-sm font-medium text-zinc-300 hover:bg-zinc-700 disabled:opacity-50"
              >
                Load
              </button>
            </div>
            {chapterLabel && (
              <>
                <p dir="auto" className="mt-1 text-[11px] text-zinc-500">
                  {chapterLabel} · lesson + Examen National context
                </p>
                <div className="mt-1 rounded-lg border border-zinc-800 bg-zinc-900/60 p-2">
                  <p className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-sky-400">
                    Examen National files mounted
                  </p>
                  <ul className="space-y-0.5 text-[11px] text-zinc-400">
                    {chapterContextFor(subject, chapter).examRefs.map((exam) => (
                      <li key={`${exam.year}-${exam.exercise}`} className="break-all">
                        {exam.session} {exam.year} - Exercice {exam.exercise}
                      </li>
                    ))}
                  </ul>
                </div>
              </>
            )}

            <label className="mb-1 block text-xs text-zinc-400">Gemini API key</label>
            <div className="relative">
              <input
                type={showKey ? 'text' : 'password'}
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                disabled={isReady || conn === 'connecting'}
                placeholder="AIza..."
                autoComplete="off"
                spellCheck={false}
                className="w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 pr-16 font-mono text-sm text-zinc-100 outline-none placeholder:text-zinc-600 focus:border-violet-500 disabled:opacity-60"
              />
              <button
                type="button"
                onClick={() => setShowKey((s) => !s)}
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded px-2 py-0.5 text-[11px] text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200"
              >
                {showKey ? 'Hide' : 'Show'}
              </button>
            </div>
            <label className="mt-2 flex cursor-pointer items-center gap-2 text-xs text-zinc-400">
              <input
                type="checkbox"
                checked={rememberKey}
                onChange={(e) => setRememberKey(e.target.checked)}
                className="h-3.5 w-3.5 accent-violet-500"
              />
              Remember key in this browser
            </label>
            <p className="mt-1 text-[11px] text-zinc-500">
              Get a key at{' '}
              <a className="text-violet-400 hover:underline" href="https://aistudio.google.com/apikey" target="_blank" rel="noreferrer">
                aistudio.google.com/apikey
              </a>
              . The key is sent directly from your browser to Google.
            </p>

            <div className="mt-3 rounded-lg border border-zinc-800 bg-zinc-950/60 px-3 py-2 text-[11px] leading-relaxed text-zinc-500">
              <span className="text-zinc-300">Model:</span> {LIVE_MODEL}
              <span className="mx-2 text-zinc-700">·</span>
              <span className="text-zinc-300">Voice:</span> {voice}
              <span className="mx-2 text-zinc-700">·</span>
              <span>Reasoning is built into the model — no thinking knob needed.</span>
            </div>

            <div className="mt-4 rounded-xl border border-zinc-800 bg-zinc-950/60">
              <button
                type="button"
                onClick={() => setShowPrompt((s) => !s)}
                className="flex w-full items-center justify-between gap-2 px-3 py-2 text-left"
              >
                <span className="text-xs text-zinc-300">
                  🇲🇦 Teacher persona <span className="text-zinc-500">(system instruction)</span>
                </span>
                <span className="text-[11px] text-zinc-500">{showPrompt ? 'Hide' : 'Edit'}</span>
              </button>
              {showPrompt && (
                <div className="space-y-2 border-t border-zinc-800 p-3">
                  <p className="text-[11px] leading-relaxed text-zinc-500">
                    Preloaded with the 2ème BAC Darija teacher prompt. It is sent in the setup message as{' '}
                    <code className="rounded bg-zinc-800 px-1 text-zinc-300">systemInstruction</code>; applied on the next
                    Connect.
                  </p>
                  <textarea
                    value={systemInstruction}
                    onChange={(e) => setSystemInstruction(e.target.value)}
                    disabled={isReady || conn === 'connecting'}
                    spellCheck={false}
                    dir="auto"
                    className="h-56 w-full resize-y rounded-lg border border-zinc-700 bg-zinc-950 p-2 font-mono text-[11px] leading-relaxed text-zinc-300 outline-none focus:border-violet-500 disabled:opacity-60"
                  />
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] text-zinc-500">{systemInstruction.length} chars</span>
                    <button
                      type="button"
                      onClick={() => setSystemInstruction(buildSystemInstruction(subject))}
                      disabled={isReady || conn === 'connecting' || systemInstruction === buildSystemInstruction(subject)}
                      className="rounded-lg border border-zinc-700 bg-zinc-800 px-2 py-1 text-[11px] text-zinc-300 hover:bg-zinc-700 disabled:opacity-40"
                    >
                      Reset to default
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className="mt-4 flex gap-2">
              {isReady || conn === 'connecting' ? (
                <button
                  onClick={disconnect}
                  className="flex-1 rounded-lg border border-zinc-700 bg-zinc-800 px-3 py-2 text-sm font-medium hover:bg-zinc-700"
                >
                  Disconnect
                </button>
              ) : (
                <button
                  onClick={connect}
                  disabled={!apiKey.trim()}
                  className="flex-1 rounded-lg bg-gradient-to-r from-violet-600 to-sky-500 px-3 py-2 text-sm font-semibold text-white shadow-lg shadow-violet-900/30 hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  Connect
                </button>
              )}
              <button
                onClick={() => setMuted((m) => !m)}
                title={muted ? 'Unmute voice' : 'Mute voice'}
                className={cn(
                  'rounded-lg border px-3 py-2 text-sm',
                  muted ? 'border-rose-700/60 bg-rose-950/40 text-rose-300' : 'border-zinc-700 bg-zinc-800 text-zinc-200 hover:bg-zinc-700',
                )}
              >
                {muted ? <MuteIcon className="h-4 w-4" /> : <SpeakerIcon className="h-4 w-4" />}
              </button>
            </div>

            {error && (
              <div className="mt-3 rounded-lg border border-rose-900/60 bg-rose-950/40 p-2 text-xs text-rose-200">{error}</div>
            )}
          </section>

          <section className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-4">
            <h2 className="mb-2 text-xs font-semibold uppercase tracking-wider text-zinc-400">Voice output</h2>
            <VoiceVisualizer analyser={player.getAnalyser()} active={speaking && !muted} className="h-16 w-full" />
            <p dir="auto" className="mt-2 text-center text-[11px] text-zinc-500">
              {speaking
                ? 'الأستاذ كيتكلم… حضر سميعتك'
                : interaction === 'IN_PROGRESS' && isReady
                  ? 'الأستاذ كيفكر… صبر شوية'
                  : 'Wajed — دخل سؤالك'}
            </p>
          </section>

          <section className="hidden rounded-2xl border border-zinc-800 bg-zinc-900/60 p-4 text-[11px] leading-relaxed text-zinc-500 lg:block">
            <p>
              Replies stream as <span className="text-zinc-300">24 kHz PCM audio</span> and are transcribed live via{' '}
              <code className="rounded bg-zinc-800 px-1 text-zinc-300">outputAudioTranscription</code>, so you get the spoken
              caption and the voice together over one WebSocket.
            </p>
            <p className="mt-2">
              With <code className="rounded bg-zinc-800 px-1 text-zinc-300">gemini-3.8-live</code> each turn ends with{' '}
              <code className="rounded bg-zinc-800 px-1 text-zinc-300">turnComplete: true</code>, so the app flips back to
              listening as soon as the teacher finishes speaking.
            </p>
            <p className="mt-2">
              The mandatory <span className="text-zinc-300">micro-step protocol</span> limits every turn to one small part plus
              one check question. Use the quick actions («Wasel l'part li jija», «ما فهمتش», «عطيني مثال») to drive the
              lesson.
            </p>
            <p className="mt-2">
              Hands-free checks: the teacher <em>speaks</em> the question, and the A–D choices appear right under it{' '}
              <span className="text-zinc-300">once he finishes talking</span> (Darija or French, depending on the item). The
              green/red <span className="text-zinc-300">فهمت / مافهمتش</span> buttons appear only for yes/no questions («واش
              فهمتي؟», «واش متأكد؟»). One tap answers — the text box stays hidden until you need it.
            </p>
          </section>
        </aside>

        {/* Chat */}
        <section className="relative flex min-h-0 flex-1 flex-col overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900/40">
          {/* Live teacher stage: identity + voice stream visualizer */}
          <div className="border-b border-zinc-800 bg-zinc-900/70 px-4 py-2.5">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 via-fuchsia-500 to-sky-400 shadow">
                <SparkIcon className="h-5 w-5 text-white" />
              </div>
              <div className="w-32 shrink-0 sm:w-40">
                <p dir="auto" className="truncate text-xs font-semibold">
                  {profile.teacherName}
                </p>
                <p className="truncate text-[10px] text-zinc-500">
                  {profile.label} · {voice}
                </p>
              </div>
              <VoiceVisualizer analyser={player.getAnalyser()} active={speaking && !muted} className="h-9 min-w-0 flex-1" />
              <span className="hidden w-16 shrink-0 text-right text-[10px] text-zinc-500 sm:block">
                {speaking ? 'Speaking…' : interaction === 'IN_PROGRESS' && isReady ? 'Thinking…' : isReady ? 'Listening' : 'Offline'}
              </span>
            </div>
          </div>
          <div ref={listRef} className="flex-1 space-y-4 overflow-y-auto p-4">
            {messages.length === 0 && (
              <div className="flex h-full flex-col items-center justify-center text-center">
                <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-zinc-800/80">
                  <SparkIcon className="h-7 w-7 text-violet-300" />
                </div>
                <h3 className="text-lg font-semibold">أستاذ 2ème BAC · بـ micro-pas، بالدارجة</h3>
                <p className="mx-auto mt-1 max-w-md text-sm leading-relaxed text-zinc-500">
                  Enter your API key, hit <span className="text-zinc-300">Connect</span>, then ask from scratch. The teacher works
                  in <span className="text-zinc-300">micro-steps</span>: every answer is ONE small part with a visual analogy,
                  then ONE small exercise — wait for your answer before the next part.
                </p>
                <div className="mt-3 flex items-center gap-2 rounded-full border border-violet-800/40 bg-violet-950/30 px-3 py-1 text-[11px] text-violet-200">
                  <span className="h-1.5 w-1.5 rounded-full bg-violet-400" />
                  1 micro-part + QCM or check per turn · one-tap answers · zero prior knowledge assumed
                </div>
                <div className="mt-5 flex flex-wrap justify-center gap-2">
                  {STARTER_PROMPTS[subject].map((s) => (
                    <button
                      key={s}
                      onClick={() => {
                        setInput(s);
                        setShowTextInput(true);
                        setTimeout(() => inputRef.current?.focus(), 60);
                      }}
                      className="rounded-full border border-zinc-700 bg-zinc-800/60 px-3 py-1.5 text-right text-xs text-zinc-300 hover:border-violet-500/60 hover:text-white"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((m) => {
              // Controls wait for the audio to finish, so choices never appear while the teacher talks.
              const isLatestModel = m.id === lastModelId;
              const speechDrained = !isLatestModel || !speaking;
              return (
                <MessageBubble
                  key={m.id}
                  message={m}
                  showControls={!m.streaming && speechDrained}
                  interactive={isLatestModel && isReady && !m.streaming && speechDrained}
                  qcmAnswers={qcmAnswers}
                  onUnderstood={handleUnderstood}
                  onNotUnderstood={handleNotUnderstood}
                  onQcmSelect={handleQcmSelect}
                />
              );
            })}

            {busy && !currentModelMsgId.current && !speaking && (
              <div className="flex items-start gap-3">
                <Avatar role="model" />
                <div className="rounded-2xl rounded-tl-sm border border-zinc-800 bg-zinc-900 px-4 py-3">
                  <ThinkingDots />
                </div>
              </div>
            )}
          </div>

          <div className="border-t border-zinc-800 p-3">
            {isReady && (
              <div className="mb-2 flex flex-wrap items-center gap-2 pr-14">
                {waitingForStudent && (
                  <span dir="auto" className="rounded-full border border-amber-700/50 bg-amber-950/40 px-3 py-1 text-[11px] text-amber-200">
                    🎓 الأستاذ متسنا جوابك على l'exercice…
                  </span>
                )}
                {MICRO_STEP_ACTIONS.map((a) => (
                  <button
                    key={a.label}
                    type="button"
                    onClick={() => sendQuickAction(a.text)}
                    className="rounded-full border border-zinc-700 bg-zinc-800/60 px-3 py-1 text-[11px] text-zinc-300 transition-colors hover:border-violet-500/60 hover:text-white"
                  >
                    {a.label}
                  </button>
                ))}
              </div>
            )}
            {showTextInput && (
              <div
                className={cn(
                  'mr-14 flex items-end gap-2 rounded-xl border bg-zinc-950 p-2 transition-colors',
                  isReady ? 'border-zinc-700 focus-within:border-violet-500' : 'border-zinc-800 opacity-70',
                )}
              >
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={onKeyDown}
                rows={1}
                dir="auto"
                disabled={!isReady}
                placeholder={isReady ? 'كتب سؤالك هنا… (Enter للإرسال، Shift+Enter لسطر جديد)' : 'Connect to start chatting — دخل الـ API key و Connect'}
                className="max-h-40 min-h-[40px] flex-1 resize-none bg-transparent px-2 py-2 text-sm outline-none placeholder:text-zinc-600 disabled:cursor-not-allowed"
                onInput={(e) => {
                  const el = e.currentTarget;
                  el.style.height = 'auto';
                  el.style.height = Math.min(el.scrollHeight, 160) + 'px';
                }}
              />
              {speaking && (
                <button
                  onClick={() => player.stop()}
                  title="Stop speaking"
                  className="rounded-lg border border-zinc-700 bg-zinc-800 p-2 text-zinc-200 hover:bg-zinc-700"
                >
                  <StopIcon className="h-4 w-4" />
                </button>
              )}
                <button
                  onClick={send}
                  disabled={!isReady || !input.trim()}
                  className="rounded-lg bg-gradient-to-r from-violet-600 to-sky-500 p-2 text-white shadow hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
                  title="Send"
                >
                  <SendIcon className="h-4 w-4" />
                </button>
              </div>
            )}
            {!showTextInput && (
              <p className="pr-14 text-[11px] leading-relaxed text-zinc-600">
                {isReady
                  ? 'Hands-free mode — answer with the green/red buttons or the QCM options. Tap the keyboard button to type.'
                  : 'Connect from the sidebar to start the lesson.'}
              </p>
            )}
          </div>
          {/* Floating text-box toggle */}
          <button
            type="button"
            onClick={() => {
              setShowTextInput((s) => {
                if (!s) setTimeout(() => inputRef.current?.focus(), 60);
                return !s;
              });
            }}
            title={showTextInput ? 'Hide text input' : 'Show text input'}
            className={cn(
              'absolute bottom-4 right-4 z-10 flex h-11 w-11 items-center justify-center rounded-full border shadow-lg transition-colors',
              showTextInput
                ? 'border-violet-500 bg-violet-600 text-white'
                : 'border-zinc-700 bg-zinc-800 text-zinc-300 hover:border-violet-500 hover:text-white',
            )}
          >
            <KeyboardIcon className="h-5 w-5" />
          </button>
        </section>
      </main>
    </div>
  );
}

/* ---------- Small UI pieces ---------- */

interface MessageBubbleProps {
  message: Message;
  /** Controls appear only once the turn ended AND the spoken audio drained. */
  showControls: boolean;
  interactive: boolean;
  qcmAnswers: Record<string, number>;
  onUnderstood: () => void;
  onNotUnderstood: () => void;
  onQcmSelect: (messageId: string, qcmIndex: number, qcm: ParsedQcm, optionIndex: number) => void;
}

function MessageBubble({
  message,
  showControls,
  interactive,
  qcmAnswers,
  onUnderstood,
  onNotUnderstood,
  onQcmSelect,
}: MessageBubbleProps) {
  if (message.role === 'system') {
    return (
      <div className="flex justify-center">
        <span className="rounded-full border border-zinc-800 bg-zinc-900 px-3 py-1 text-[11px] text-zinc-500">{message.text}</span>
      </div>
    );
  }
  const isUser = message.role === 'user';
  // While streaming, scrub partial JSON/tags; when finished, parse the real structures.
  const parsed = !isUser && !message.streaming ? parseModelContent(message.text) : null;
  const displayText = parsed ? parsed.displayText : isUser ? message.text : sanitizeStreamingText(message.text);
  // A QCM is safe to reveal only when its full question was actually present
  // in Gemini's output-audio transcription, not merely in a control JSON block.
  const spokenQcms = parsed?.qcms.filter((qcm) => transcriptCoversQuestion(message.audioTranscript ?? '', qcm.question)) ?? [];
  const withheldQcmCount = (parsed?.qcms.length ?? 0) - spokenQcms.length;
  const hasPendingControls = !!parsed && (spokenQcms.length > 0 || parsed.wantsCheck) && !showControls;

  return (
    <div className={cn('flex items-start gap-3', isUser && 'flex-row-reverse')}>
      <Avatar role={message.role} />
      <div className="flex min-w-0 max-w-[85%] flex-col gap-2">
        {(displayText.length > 0 || message.streaming) && (
          <div
            dir="auto"
            lang={isUser ? undefined : 'ar'}
            className={cn(
              'whitespace-pre-wrap break-words rounded-2xl px-4 py-2.5 text-sm leading-relaxed',
              isUser
                ? 'rounded-tr-sm bg-gradient-to-br from-violet-600 to-indigo-600 text-white'
                : 'rounded-tl-sm border border-zinc-800 bg-zinc-900 text-zinc-100',
            )}
          >
            {displayText}
            {message.streaming && <span className="ml-0.5 inline-block h-4 w-[2px] animate-pulse bg-violet-400 align-middle" />}
          </div>
        )}
        {hasPendingControls && (
          <div className="flex items-center gap-2 rounded-full border border-zinc-800 bg-zinc-900/80 px-3 py-1 text-[11px] text-zinc-400">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-sky-400" />
            <span dir="auto">سمع لـلأستاذ — l'choix غادي يبان من بعد ما يسالي الكلام</span>
          </div>
        )}
        {showControls &&
          spokenQcms.map((qcm, i) => (
            <QcmCard
              key={`${message.id}-qcm-${i}`}
              qcm={qcm}
              selected={qcmAnswers[`${message.id}:${i}`] ?? null}
              disabled={!interactive}
              onSelect={(optionIndex) => onQcmSelect(message.id, i, qcm, optionIndex)}
            />
          ))}
        {showControls && withheldQcmCount > 0 && (
          <div dir="auto" className="rounded-xl border border-amber-900/60 bg-amber-950/30 px-3 py-2 text-xs leading-relaxed text-amber-200">
            الأستاذ كيعيد السؤال كامل بالصوت باش تسمعو مزيان قبل ما تبان الاختيارات…
          </div>
        )}
        {showControls && parsed?.wantsCheck && (
          <ComprehensionBar onUnderstood={onUnderstood} onNotUnderstood={onNotUnderstood} disabled={!interactive} />
        )}
      </div>
    </div>
  );
}

function Avatar({ role }: { role: 'user' | 'model' | 'system' }) {
  if (role === 'user') {
    return (
      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-zinc-800 text-xs font-semibold text-zinc-300">
        You
      </div>
    );
  }
  return (
    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 via-fuchsia-500 to-sky-400">
      <SparkIcon className="h-4 w-4 text-white" />
    </div>
  );
}

function StatusPill({ conn, interaction, speaking }: { conn: ConnState; interaction: InteractionStatus; speaking: boolean }) {
  let label = 'Disconnected';
  let dot = 'bg-zinc-500';
  if (conn === 'connecting') {
    label = 'Connecting…';
    dot = 'bg-amber-400 animate-pulse';
  } else if (conn === 'error') {
    label = 'Error';
    dot = 'bg-rose-500';
  } else if (conn === 'ready') {
    if (speaking) {
      label = 'Speaking';
      dot = 'bg-sky-400 animate-pulse';
    } else if (interaction === 'IN_PROGRESS') {
      label = 'Thinking';
      dot = 'bg-violet-400 animate-pulse';
    } else {
      label = 'Ready';
      dot = 'bg-emerald-400';
    }
  }
  return (
    <div className="flex items-center gap-2 rounded-full border border-zinc-800 bg-zinc-900 px-3 py-1 text-xs text-zinc-300">
      <span className={cn('h-2 w-2 rounded-full', dot)} />
      {label}
    </div>
  );
}

function ThinkingDots() {
  return (
    <div className="flex items-center gap-1.5">
      <span className="text-xs text-zinc-400" dir="auto">
        الأستاذ كيجهز l'micro-part…
      </span>
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="h-1.5 w-1.5 animate-bounce rounded-full bg-violet-400"
          style={{ animationDelay: `${i * 150}ms` }}
        />
      ))}
    </div>
  );
}

/* ---------- Icons ---------- */

function SparkIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 2c.6 4.9 4.1 8.4 10 10-5.9 1.6-9.4 5.1-10 10-.6-4.9-4.1-8.4-10-10 5.9-1.6 9.4-5.1 10-10z" />
    </svg>
  );
}
function SendIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 2 11 13" />
      <path d="M22 2 15 22l-4-9-9-4z" />
    </svg>
  );
}
function StopIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <rect x="6" y="6" width="12" height="12" rx="2" />
    </svg>
  );
}
function SpeakerIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M11 5 6 9H2v6h4l5 4z" />
      <path d="M15.5 8.5a5 5 0 0 1 0 7" />
      <path d="M19 5a9 9 0 0 1 0 14" />
    </svg>
  );
}
function MuteIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M11 5 6 9H2v6h4l5 4z" />
      <path d="m23 9-6 6" />
      <path d="m17 9 6 6" />
    </svg>
  );
}
function KeyboardIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="6" width="20" height="12" rx="2" />
      <path d="M6 10h.01" />
      <path d="M10 10h.01" />
      <path d="M14 10h.01" />
      <path d="M18 10h.01" />
      <path d="M6 14h.01" />
      <path d="M18 14h.01" />
      <path d="M9 14h6" />
    </svg>
  );
}
